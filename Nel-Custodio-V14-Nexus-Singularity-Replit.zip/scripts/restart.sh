#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# 🔄 Script de Auto-Restart para Nel-Aviso-Bot
# Mantém o bot online 24/7 com auto-restart em caso de crash
# ═══════════════════════════════════════════════════════════════

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configurações
BOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_FILE="$BOT_DIR/bot.log"
PID_FILE="$BOT_DIR/bot.pid"
MAX_RETRIES=10
RETRY_DELAY=5

echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}🤖 Nel-Aviso-Bot Auto-Restart Manager${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"

# Função para iniciar o bot
start_bot() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando bot...${NC}"
    
    cd "$BOT_DIR"
    
    # Inicia o bot em background
    nohup npm start >> "$LOG_FILE" 2>&1 &
    
    # Guarda o PID
    echo $! > "$PID_FILE"
    
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] Bot iniciado com PID: $(cat $PID_FILE)${NC}"
}

# Função para verificar se o bot está online
check_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null; then
            return 0  # Bot está online
        fi
    fi
    return 1  # Bot está offline
}

# Função para parar o bot
stop_bot() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] Parando bot (PID: $PID)...${NC}"
        kill -9 $PID 2>/dev/null
        rm -f "$PID_FILE"
        echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] Bot parado${NC}"
    fi
}

# Função para mostrar logs
show_logs() {
    if [ -f "$LOG_FILE" ]; then
        tail -f "$LOG_FILE"
    else
        echo -e "${RED}Arquivo de log não encontrado${NC}"
    fi
}

# Função principal de monitoramento
monitor_bot() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando monitoramento...${NC}"
    
    RETRY_COUNT=0
    
    while true; do
        if check_bot; then
            # Bot está online
            RETRY_COUNT=0
            echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] ✅ Bot online${NC}"
        else
            # Bot está offline
            RETRY_COUNT=$((RETRY_COUNT + 1))
            
            if [ $RETRY_COUNT -le $MAX_RETRIES ]; then
                echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ❌ Bot offline! Tentativa $RETRY_COUNT/$MAX_RETRIES${NC}"
                echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] Reiniciando em ${RETRY_DELAY}s...${NC}"
                
                sleep $RETRY_DELAY
                start_bot
            else
                echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ❌ Máximo de tentativas atingido!${NC}"
                echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] Verifique os logs: $LOG_FILE${NC}"
                exit 1
            fi
        fi
        
        # Verifica a cada 30 segundos
        sleep 30
    done
}

# Tratamento de sinais
trap 'echo -e "\n${YELLOW}Parando monitoramento...${NC}"; stop_bot; exit 0' SIGINT SIGTERM

# Menu de opções
case "${1:-start}" in
    start)
        start_bot
        monitor_bot
        ;;
    stop)
        stop_bot
        ;;
    restart)
        stop_bot
        sleep 2
        start_bot
        monitor_bot
        ;;
    status)
        if check_bot; then
            echo -e "${GREEN}✅ Bot está online (PID: $(cat $PID_FILE))${NC}"
        else
            echo -e "${RED}❌ Bot está offline${NC}"
        fi
        ;;
    logs)
        show_logs
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|status|logs}"
        echo ""
        echo "Exemplos:"
        echo "  $0 start      - Inicia o bot com monitoramento"
        echo "  $0 stop       - Para o bot"
        echo "  $0 restart    - Reinicia o bot"
        echo "  $0 status     - Verifica status do bot"
        echo "  $0 logs       - Mostra logs em tempo real"
        exit 1
        ;;
esac
