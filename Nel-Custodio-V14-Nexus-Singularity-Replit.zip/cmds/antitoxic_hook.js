import db from '#db';

const toxicRegexMap = {
  delete: /^\s*(caralho|puta|merda|foda|porra|cabrão|crl|fdp|viado|bicha|cu|desgraça|carai|porr|fod|merd|put|cabron|crl|fdp|viad|bich|krl|pqp)\s*$/i,
  contains: /(caralho|puta|merda|foda|porra|cabrão|crl|fdp|viado|bicha|cu|desgraça|carai|krl|pqp)/i
};

export async function before({ msg, sock, groupMetadata, isAdmins, isBotAdmins }) {
  if (!msg.isGroup || !msg.text) return;
  if (msg.isBot) return;
  if (isAdmins) return;
  if (!isBotAdmins) return;

  const chat = db.getChat(msg.chat) || {};
  if (!chat?.antitoxic) return;

  const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
  const primaryBotId = chat?.primaryBot;
  const isPrimary = !primaryBotId || primaryBotId === botId;
  if (!isPrimary) return;

  const text = msg.text.toLowerCase();
  const words = chat.antitoxicWords || ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu'];

  const hasToxic = words.some(word => {
    const regex = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    return regex.test(text);
  });

  if (!hasToxic) return;

  // Delete the message
  try {
    await sock.sendMessage(msg.chat, { delete: { remoteJid: msg.chat, fromMe: false, id: msg.key.id, participant: msg.key.participant }});
  } catch {}

  const mode = chat.antitoxicMode || 'delete';
  const user = db.getUser(msg.sender);
  const userName = user?.name || 'Usuário';

  if (mode === 'warn') {
    await sock.reply(msg.chat, `☡ *${userName}*, palavrões não são permitidos neste grupo! Esta é uma advertência.`, msg);
  } else if (mode === 'kick') {
    await sock.reply(msg.chat, `☡ *${userName}* foi expulso por usar palavrões.`, msg);
    await sock.groupParticipantsUpdate(msg.chat, [msg.sender], 'remove');
  }
}
