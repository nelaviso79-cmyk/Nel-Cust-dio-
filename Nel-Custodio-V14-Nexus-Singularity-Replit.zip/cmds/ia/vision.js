import fetch from 'node-fetch';
import uploadImage from '#uploadImage';

export default {
  command: ['vision', 'ver', 'analisar', 'oqé'],
  category: 'ia',
  description: 'O bot analisa e descreve o que está numa imagem.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    const q = msg.quoted || msg;
    const mime = (q.msg || q).mimetype || '';
    
    if (!/image/.test(mime)) return msg.reply(`📸 *IA VISION SUPREMA* 📸\n\n▸ Responde a uma imagem com *${usedPrefix + command}* para eu analisar.\n▸ Podes perguntar algo específico: *${usedPrefix + command} o que é este objeto?*`);

    await msg.react('👁️');
    try {
      const media = await q.download();
      const imageUrl = await uploadImage(media, mime);
      
      const query = text || 'Descreve esta imagem em detalhe e diz o que vês.';
      const res = await fetch(`https://api.vreden.web.id/api/ai/gemini-vision?url=${encodeURIComponent(imageUrl)}&text=${encodeURIComponent(query)}`);
      const json = await res.json();
      
      if (!json.status || !json.result) {
        throw new Error('IA de visão falhou.');
      }

      await msg.reply(`📸 *ANÁLISE DE VISÃO IA* 📸\n\n${json.result}\n\n> 🧠 _Nel-Brain Vision V11_`);
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao analisar imagem: ${e.message}`);
    }
  }
};
