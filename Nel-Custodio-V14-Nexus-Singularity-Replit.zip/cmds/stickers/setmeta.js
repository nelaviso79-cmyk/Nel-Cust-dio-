import db from '#db';
export default {
  command: ['setstickermeta', 'setmeta'],
  category: 'stickers',
  description: 'Definir o pack e autor por defeito para os seus stickers.',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!args || args.length === 0) {
      return msg.reply('《✧》 Por favor, insira os metadados que deseja atribuir aos seus stickers.');
    }
    try {
      const fullArgs = args.join(' ');
      const separatorIndex = fullArgs.search(/[|•\/]/);
      let metadatos01, metadatos02;
      if (separatorIndex === -1) {
        metadatos01 = fullArgs.trim();
        metadatos02 = '';
      } else {
        metadatos01 = fullArgs.slice(0, separatorIndex).trim();
        metadatos02 = fullArgs.slice(separatorIndex + 1).trim();
      }
      if (!metadatos01) {
        return msg.reply('《✧》 O nome do pacote no pode estar vazio.');
      }
      db.setUser(msg.sender, 'metadatos', metadatos01);
      db.setUser(msg.sender, 'metadatos2', metadatos02);
      await sock.sendMessage(msg.chat, { text: `✎ Os metadados dos seus stickers foram atualizados corretamente.` }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};
