import db from '#db';
export default {
  command: ['setpackprivate', 'setpackpriv', 'packprivate'],
  category: 'stickers',
  description: 'Definir um pacote de stickers como privado.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply('《✧》Deve especificar o nome do pacote de stickers.')
      }
      const packName = args.join(' ').trim()
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase())
      if (!pack) {
        return msg.reply(`《✧》Não foi encontrado o pacote de stickers \`${packName}\`.`)
      }
      if (pack.spackpublic === 0) {
        return msg.reply(`《✧》O pacote de stickers \`${pack.name}\` já é privado.`)
      }
      pack.spackpublic = 0
      pack.lastModified = Date.now().toString()
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`❀ O pacote de stickers \`${pack.name}\` foi definido como privado!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}