import db from '#db';
export default {
  command: ['addsticker', 'stickeradd'],
  category: 'stickers',
  description: 'Adicionar um sticker a um pacote.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply('《✧》Especifique o nome do pacote.')
      }
      const packName = args.join(' ').trim()
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase())
      if (!pack) {
        return msg.reply('《✧》Não foi encontrado um pacote com esse nome.')
      }
      const quoted = msg.quoted
      if (!quoted) {
        return msg.reply('《✧》Responde a um sticker.')
      }
      const mime = quoted.mimetype || quoted.msg?.mimetype || ''
      if (!/webp/i.test(mime)) {
        return msg.reply('《✧》Solo podes agregar stickers.')
      }
      if (pack.stickers.length >= 50) {
        return msg.reply('《✧》Un paquete não pode ter mais de 50 stickers.')
      }
      let buffer = await quoted.download()
      if (!buffer) {
        return msg.reply('《✧》Não foi possível baixar o sticker.')
      }
      if (!Buffer.isBuffer(buffer)) {
        buffer = Buffer.from(buffer)
      }
      if (buffer.length === 0) {
        return msg.reply('《✧》O sticker está vazio ou corrompido.')
      }
      const base64Sticker = buffer.toString('base64')
      if (pack.stickers.includes(base64Sticker)) {
        return msg.reply(`《✧》O sticker já existe no pacote de stickers \`${pack.name}\`.`)
      }
      pack.stickers.push(base64Sticker)
      pack.lastModified = Date.now().toString()
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`《✧》Sticker adicionado ao pack \`${pack.name}\` corretamente!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}