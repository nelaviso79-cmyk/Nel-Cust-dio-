import db from '#db';
export default {
  command: ['setstickerpackname', 'setpackname', 'packname'],
  category: 'stickers',
  description: 'Mudar o nome de um pacote de stickers.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      if (!args.length) {
        return msg.reply(`《✧》Especifique o nome do pacote y o novo nome.\n> Exemplo: *${usedPrefix + command} NomeActual | NovoNome*`)
      }
      const fullText = args.join(' ').trim()
      const parts = fullText.split(/\||•|\//)
      if (parts.length < 2) {
        return msg.reply(`《✧》Especifique o nome do pacote y o novo nome.\n> Exemplo: *${usedPrefix + command} NomeActual | NovoNome*`)
      }
      const packName = parts[0].trim()
      const newName = parts[1].trim()
      if (!newName || newName.length === 0) {
        return msg.reply('《✧》O novo nome não pode estar vazio.')
      }
      if (newName.length < 4 || newName.length > 64) {
        return msg.reply('《✧》O novo nome deve ter entre 4 e 64 caracteres.')
      }
      const stickerPackData = db.getStickersPack(msg.sender)
      const packs = stickerPackData.packs || []
      if (!packs || packs.length === 0) {
        return msg.reply('《✧》Não tem paquetes creados.')
      }
      if (packs.find(p => p.name.toLowerCase() === newName.toLowerCase())) {
        return msg.reply('《✧》Ya tienes um pacote com esse nome.')
      }
      const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase())
      if (!pack) {
        return msg.reply(`《✧》Não foi encontrado o pacote de stickers \`${packName}\`.`)
      }
      pack.name = newName
      pack.lastModified = Date.now().toString()
      db.setStickersPack(msg.sender, 'packs', packs);
      msg.reply(`❀ O pacote de stickers \`${packName}\` agora se chama \`${newName}\`!`)
    } catch (e) {
      msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
}
