import db from '#db';
export default {
  command: ['count', 'mensajes', 'messages', 'msgcount'],
  category: 'grupos',
  description: 'Obter a contagem de mensagens de um usuário.',
  run: async ({ msg, sock, args }) => {
    const chatId = msg.chat;
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || msg.sender;
    let user = db.getChatUser(chatId, who);
    if (!user) {
      return msg.reply(`「✎」 O usuário mencionado não está registado no bot.`);
    }    
    let userStats = user.stats;
    const now = new Date();
    const daysArg = parseInt(args[0]) || 30;
    const cutoff = new Date(now.getTime() - daysArg * 24 * 60 * 60 * 1000);
    const days = Object.entries(userStats).filter(([date]) => new Date(date) >= cutoff).sort((a, b) => new Date(b[0]) - new Date(a[0]));
    const totalMsgs = days.reduce((acc, [, d]) => acc + (d.msgs || 0), 0);
    const totalCmds = days.reduce((acc, [, d]) => acc + (d.cmds || 0), 0);
    let report = `❀ Contador de mensajes de @${who.split('@')[0]}\n`;
    report += `> Total nos últimos *${daysArg}* dias: \`${totalMsgs}\` mensajes\n\n`;
    for (const [date, d] of days) {
      const fecha = new Date(date).toLocaleDateString('pt-MZ', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Africa/Maputo' });
      report += `*❏ ${fecha}*\n`;
      report += `\t» Mensagems: \`${d.msgs || 0}\`, Comandos: \`${d.cmds || 0}\`\n`;
    }
    await sock.reply(chatId, report, msg, { mentions: [who] });
  }
};