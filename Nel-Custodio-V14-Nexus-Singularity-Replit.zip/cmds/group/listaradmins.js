export default {
  command: ['listaradmins', 'adminlist', 'admins', 'listaradm'],
  category: 'grupos',
  description: 'Listar todos os administradores do grupo 👑',
  run: async ({ msg, sock, usedPrefix, command, participants }) => {
    if (!msg.isGroup) return msg.reply('◈ Este comando só funciona em grupos!');

    const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
    const criador = participants.filter(p => p.admin === 'superadmin');
    const normais = participants.filter(p => !p.admin);

    let result = `👑 *ADMINISTRADORES DO GRUPO* 👑\n\n`;
    
    if (criador.length) {
      result += `⭐ *Criador:*\n`;
      for (const c of criador) {
        result += `▸ @${c.id?.split('@')[0]} 🌟\n`;
      }
      result += `\n`;
    }

    result += `🛡️ *Admins (${admins.length}):*\n`;
    for (const a of admins) {
      if (a.admin === 'superadmin') continue;
      const num = a.id?.split('@')[0];
      result += `▸ @${num} 🛡️\n`;
    }

    result += `\n👥 *Membros normais:* ${normais.length}\n`;
    result += `📊 *Total:* ${participants.length} participantes\n\n`;
    result += `_👑 Nel-Aviso-Bot-Moz_`;

    const mentions = admins.map(a => a.id).filter(Boolean);
    return msg.reply(result, { mentions });
  }
};
