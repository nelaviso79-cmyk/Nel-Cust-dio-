import db from '#db';
export default {
  command: ['antimidia', 'antimedia', 'antifoto', 'antivideo', 'antistickergrp'],
  category: 'moderacao',
  description: 'Bloquear tipos de mídia no grupo (fotos, vídeos, stickers, áudio, documentos). Apenas admins podem enviar.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChatSetting(msg.chat);
    const action = args[0]?.toLowerCase();
    const mediaTypes = ['image', 'video', 'sticker', 'audio', 'document', 'contact', 'location', 'poll'];

    if (!action || !['on', 'off', 'add', 'remove', 'list', 'status'].includes(action)) {
      const status = setting?.antimidia ? '✅ Ativo' : '❌ Inativo';
      const blocked = setting?.antimidiaTypes || [];
      const blockedText = blocked.length ? blocked.map(t => {
        const names = { image: '📷 Fotos', video: '🎬 Vídeos', sticker: '🌟 Stickers', audio: '🎵 Áudio', document: '📄 Documentos', contact: '👤 Contactos', location: '📍 Localização', poll: '📊 Votações' };
        return names[t] || t;
      }).join(', ') : 'Nenhum';
      return msg.reply(
        `🚫 *Sistema Anti-Mídia*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Tipos bloqueados: *${blockedText}*\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} add <tipo>* - Bloquear tipo de mídia\n` +
        `> *${usedPrefix + command} remove <tipo>* - Permitir tipo de mídia\n` +
        `> *${usedPrefix + command} list* - Ver tipos bloqueados\n\n` +
        `Tipos: *image, video, sticker, audio, document, contact, location, poll*`
      );
    }

    if (action === 'status' || action === 'list') {
      const status = setting?.antimidia ? '✅ Ativo' : '❌ Inativo';
      const blocked = setting?.antimidiaTypes || [];
      const names = { image: '📷 Fotos', video: '🎬 Vídeos', sticker: '🌟 Stickers', audio: '🎵 Áudio', document: '📄 Documentos', contact: '👤 Contactos', location: '📍 Localização', poll: '📊 Votações' };
      const blockedText = blocked.length ? blocked.map(t => names[t] || t).join(', ') : 'Nenhum';
      return msg.reply(`🚫 Anti-Mídia: ${status}\n▸ Tipos bloqueados: *${blockedText}*`);
    }

    if (action === 'on') {
      db.updateChatSetting(msg.chat, 'antimidia', true);
      if (!setting?.antimidiaTypes?.length) {
        db.updateChatSetting(msg.chat, 'antimidiaTypes', ['image', 'video', 'sticker']);
      }
      return msg.reply('🚫 *Anti-Mídia* ativado! Apenas admins podem enviar os tipos bloqueados. ✅');
    }

    if (action === 'off') {
      db.updateChatSetting(msg.chat, 'antimidia', false);
      return msg.reply('🚫 *Anti-Mídia* desativado. ❌');
    }

    if (action === 'add') {
      const type = args[1]?.toLowerCase();
      if (!type || !mediaTypes.includes(type)) {
        return msg.reply(`🚫 Especifica um tipo válido: *${mediaTypes.join(', ')}*\n✎ Exemplo: *${usedPrefix + command} add image*`);
      }
      const types = setting?.antimidiaTypes || [];
      if (types.includes(type)) return msg.reply(`🚫 O tipo *${type}* já está bloqueado.`);
      types.push(type);
      db.updateChatSetting(msg.chat, 'antimidiaTypes', types);
      db.updateChatSetting(msg.chat, 'antimidia', true);
      const names = { image: '📷 Fotos', video: '🎬 Vídeos', sticker: '🌟 Stickers', audio: '🎵 Áudio', document: '📄 Documentos', contact: '👤 Contactos', location: '📍 Localização', poll: '📊 Votações' };
      return msg.reply(`🚫 ${names[type] || type} adicionado aos tipos bloqueados. ✅`);
    }

    if (action === 'remove') {
      const type = args[1]?.toLowerCase();
      if (!type) return msg.reply(`🚫 Especifica o tipo a permitir.\n✎ Exemplo: *${usedPrefix + command} remove image*`);
      let types = setting?.antimidiaTypes || [];
      types = types.filter(t => t !== type);
      db.updateChatSetting(msg.chat, 'antimidiaTypes', types);
      const names = { image: '📷 Fotos', video: '🎬 Vídeos', sticker: '🌟 Stickers', audio: '🎵 Áudio', document: '📄 Documentos', contact: '👤 Contactos', location: '📍 Localização', poll: '📊 Votações' };
      return msg.reply(`🚫 ${names[type] || type} removido dos tipos bloqueados. Agora é permitido. ✅`);
    }
  },
};
