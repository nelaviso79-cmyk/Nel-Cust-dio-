import db from '#db';
export default {
  command: ['setwelcome'],
  category: 'grupos',
  description: 'Definir uma mensagem de boas-vindas personalizada.',
  isAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    let chat = db.getChat(chatId);
    if (!args.length) {
      return msg.reply(`ꕤ ꨩᰰ𑪐𑂺 ˳ ׄ Set Welcome ࣭𑁯ᰍ   ̊ ܃܃

*❒ Variáveis disponíveis:*
𖣣ֶㅤ֯⌗ ✤ ⬭ @user    
> → Menção do usuário que entra

𖣣ֶㅤ֯⌗ ✤ ⬭ @group   
> → Nome do grupo

𖣣ֶㅤ֯⌗ ✤ ⬭ @desc    
> → Descrição do grupo

𖣣ֶㅤ֯⌗ ✤ ⬭ @members 
> → Número de miembros actuales

𖣣ֶㅤ֯⌗ ✤ ⬭ @time    
> → Data y hora

✿ Se já tens uma mensagem configurada e queres apagá-la usa: *${usedPrefix + command} clear*`);
    }
    if (args[0] === 'clear') {
      if (!chat.sWelcome || chat.sWelcome.trim() === '') {
        return msg.reply('✎ Não tem ningún mensagem de boas-vindas definido.');
      }
      chat.sWelcome = '';
      db.setChat(chatId, 'sWelcome', '');
      return msg.reply('✐ Mensagem de boas-vindas eliminado.');
    }
    const texto = args.join(' ');
    chat.sWelcome = texto;
    db.setChat(chatId, 'sWelcome', texto);
    msg.reply(`ꕥ Definiste a mensagem de boas-vindas corretamente.`);
  }
};