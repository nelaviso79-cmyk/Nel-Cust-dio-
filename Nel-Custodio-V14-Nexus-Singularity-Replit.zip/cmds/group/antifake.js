import db from '#db';
export default {
  command: ['antifake', 'antifalso', 'antinumfake'],
  category: 'moderacao',
  description: 'Bloquear números falsos ou virtuais de entrar no grupo. Detecta números com código de país suspeito.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChatSetting(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'add', 'remove', 'list', 'status'].includes(action)) {
      const status = setting?.antifake ? '✅ Ativo' : '❌ Inactivo';
      const blocked = setting?.antifakeCodes || ['1', '44', '91', '92', '61'];
      return msg.reply(
        `❧ *Sistema Anti-Fake*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Códigos bloqueados: *${blocked.join(', ')}*\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} add +XX* - Adicionar código de país\n` +
        `> *${usedPrefix + command} remove +XX* - Remover código\n` +
        `> *${usedPrefix + command} list* - Ver códigos bloqueados\n` +
        `> *${usedPrefix + command} status* - Ver estado`
      );
    }

    if (action === 'status' || action === 'list') {
      const status = setting?.antifake ? '✅ Ativo' : '❌ Inactivo';
      const blocked = setting?.antifakeCodes || ['1', '44', '91', '92', '61'];
      return msg.reply(`❧ Anti-Fake: ${status}\n▸ Códigos bloqueados: *${blocked.join(', ')}*`);
    }

    if (action === 'on') {
      db.updateChatSetting(msg.chat, 'antifake', true);
      if (!setting?.antifakeCodes) db.updateChatSetting(msg.chat, 'antifakeCodes', ['1', '44', '91', '92', '61']);
      return msg.reply('❧ *Anti-Fake* ativado! Números com códigos bloqueados serão removidos automaticamente. ✅');
    }

    if (action === 'off') {
      db.updateChatSetting(msg.chat, 'antifake', false);
      return msg.reply('❧ *Anti-Fake* desativado. ❌');
    }

    if (action === 'add') {
      const code = args[1]?.replace(/[+]/g, '');
      if (!code) return msg.reply(`❧ Especifique o código de país.\n✎ Exemplo: *${usedPrefix + command} add +1*`);
      const codes = setting?.antifakeCodes || ['1', '44', '91', '92', '61'];
      if (codes.includes(code)) return msg.reply(`❧ O código *+${code}* já está na lista.`);
      codes.push(code);
      db.updateChatSetting(msg.chat, 'antifakeCodes', codes);
      return msg.reply(`❧ Código *+${code}* adicionado à lista de bloqueados. ✅`);
    }

    if (action === 'remove') {
      const code = args[1]?.replace(/[+]/g, '');
      if (!code) return msg.reply(`❧ Especifique o código de país.\n✎ Exemplo: *${usedPrefix + command} remove +1*`);
      let codes = setting?.antifakeCodes || ['1', '44', '91', '92', '61'];
      codes = codes.filter(c => c !== code);
      db.updateChatSetting(msg.chat, 'antifakeCodes', codes);
      return msg.reply(`❧ Código *+${code}* removido da lista de bloqueados. ✅`);
    }
  },
};
