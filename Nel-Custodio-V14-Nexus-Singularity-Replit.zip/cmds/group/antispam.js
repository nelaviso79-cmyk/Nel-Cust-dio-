import db from '#db';
export default {
  command: ['antispam', 'antiflood'],
  category: 'moderacao',
  description: 'Sistema anti-spam: limita mensagens repetidas em sequência. Adverte ou expulsa quem faz spam.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChat(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'status', 'limit'].includes(action)) {
      const status = setting?.antispam ? '✅ Ativo' : '❌ Inactivo';
      const limit = setting?.antispamLimit || 5;
      return msg.reply(
        `❧ *Sistema Anti-Spam*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Limite: *${limit} mensagens* em 10 segundos\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} limit 7* - Definir limite (3-15)\n` +
        `> *${usedPrefix + command} status* - Ver estado actual`
      );
    }

    if (action === 'status') {
      const status = setting?.antispam ? '✅ Ativo' : '❌ Inactivo';
      const limit = setting?.antispamLimit || 5;
      return msg.reply(`❧ Anti-Spam: ${status} | Limite: *${limit} mensagens/10s*`);
    }

    if (action === 'on') {
      db.setChat(msg.chat, 'antispam', 1);
      if (!setting?.antispamLimit) db.setChat(msg.chat, 'antispamLimit', 5);
      return msg.reply('❧ *Anti-Spam* ativado! Membros que enviarem mais de 5 mensagens em 10 segundos serão advertidos. ✅');
    }

    if (action === 'off') {
      db.setChat(msg.chat, 'antispam', 0);
      return msg.reply('❧ *Anti-Spam* desativado. ❌');
    }

    if (action === 'limit') {
      const num = parseInt(args[1]);
      if (!num || num < 3 || num > 15) {
        return msg.reply(`❧ O limite deve ser entre *3* e *15* mensagens.\n✎ Exemplo: *${usedPrefix + command} limit 7*`);
      }
      db.setChat(msg.chat, 'antispamLimit', num);
      db.setChat(msg.chat, 'antispam', 1);
      return msg.reply(`❧ *Anti-Spam* limite definido para *${num}* mensagens em 10 segundos. ✅`);
    }
  },
};
