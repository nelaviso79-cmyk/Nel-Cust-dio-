import db from '#db';
export default {
  command: ['antilink2', 'antelink2', 'antlink2'],
  category: 'moderacao',
  description: 'Sistema avançado anti-link: detecta WhatsApp, Telegram, YouTube e outros links. Remove automaticamente.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata, participants }) => {
    const setting = db.getChatSetting(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'delete', 'kick', 'warn', 'status'].includes(action)) {
      const status = setting?.antilink2 ? '✅ Ativo' : '❌ Inactivo';
      const mode = setting?.antilink2Action || 'delete';
      return msg.reply(
        `❧ *Sistema Anti-Link Avançado*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Modo: *${mode}*\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} delete* - Apagar link (padrão)\n` +
        `> *${usedPrefix + command} kick* - Expulsar quem enviar link\n` +
        `> *${usedPrefix + command} warn* - Advertir quem enviar link\n` +
        `> *${usedPrefix + command} status* - Ver estado actual\n\n` +
        `▸ Detecta: WhatsApp, Telegram, YouTube, TikTok, Facebook, Instagram, Twitter e mais.`
      );
    }

    if (action === 'status') {
      const status = setting?.antilink2 ? '✅ Ativo' : '❌ Inactivo';
      const mode = setting?.antilink2Action || 'delete';
      return msg.reply(`❧ Anti-Link Avançado: ${status} | Modo: *${mode}*`);
    }

    if (action === 'on') {
      db.updateChatSetting(msg.chat, 'antilink2', true);
      if (!setting?.antilink2Action) db.updateChatSetting(msg.chat, 'antilink2Action', 'delete');
      return msg.reply('❧ *Anti-Link Avançado* ativado com sucesso! ✅\n▸ Modo: *delete* (apagar mensagens com links)');
    }

    if (action === 'off') {
      db.updateChatSetting(msg.chat, 'antilink2', false);
      return msg.reply('❧ *Anti-Link Avançado* desativado. ❌');
    }

    if (['delete', 'kick', 'warn'].includes(action)) {
      db.updateChatSetting(msg.chat, 'antilink2Action', action);
      db.updateChatSetting(msg.chat, 'antilink2', true);
      const modeNames = { delete: 'Apagar mensagem', kick: 'Expulsar membro', warn: 'Advertir membro' };
      return msg.reply(`❧ *Anti-Link Avançado* modo definido para: *${modeNames[action]}* ✅`);
    }
  },
};
