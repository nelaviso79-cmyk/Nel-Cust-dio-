import db from '#db';
export default {
  command: ['antiarabe', 'antiestrangeiro', 'antiforeign', 'antintruso'],
  category: 'moderacao',
  description: 'Bloquear números de países estrangeiros específicos de entrar no grupo. Ideal para grupos apenas de Moçambique.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChat(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'add', 'remove', 'list', 'onlymz', 'status'].includes(action)) {
      const status = setting?.antiarabe ? '✅ Ativo' : '❌ Inativo';
      const mode = setting?.antiarabeMode || 'block';
      const blocked = setting?.antiarabeCodes || [];
      return msg.reply(
        `🛡 *Sistema Anti-Estrangeiro*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Modo: *${mode === 'onlymz' ? 'Apenas Moçambique (+258)' : 'Bloquear códigos específicos'}*\n` +
        `▸ Códigos bloqueados: *${blocked.length ? blocked.map(c => '+' + c).join(', ') : 'Nenhum'}*\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} onlymz* - Permitir apenas +258\n` +
        `> *${usedPrefix + command} add +XX* - Bloquear código de país\n` +
        `> *${usedPrefix + command} remove +XX* - Remover código bloqueado\n` +
        `> *${usedPrefix + command} list* - Ver códigos bloqueados`
      );
    }

    if (action === 'status' || action === 'list') {
      const status = setting?.antiarabe ? '✅ Ativo' : '❌ Inativo';
      const blocked = setting?.antiarabeCodes || [];
      return msg.reply(`🛡 Anti-Estrangeiro: ${status}\n▸ Códigos bloqueados: *${blocked.length ? blocked.map(c => '+' + c).join(', ') : 'Nenhum'}*`);
    }

    if (action === 'on') {
      db.setChat(msg.chat, 'antiarabe', 1);
      if (!setting?.antiarabeCodes) db.setChat(msg.chat, 'antiarabeCodes', []);
      if (!setting?.antiarabeMode) db.setChat(msg.chat, 'antiarabeMode', 'block');
      return msg.reply('🛡 *Anti-Estrangeiro* ativado! Números com códigos bloqueados serão removidos. ✅');
    }

    if (action === 'off') {
      db.setChat(msg.chat, 'antiarabe', 0);
      return msg.reply('🛡 *Anti-Estrangeiro* desativado. ❌');
    }

    if (action === 'onlymz') {
      db.setChat(msg.chat, 'antiarabe', 1);
      db.setChat(msg.chat, 'antiarabeMode', 'onlymz');
      return msg.reply('🛡 Modo *Apenas Moçambique* ativado! Apenas números com +258 poderão entrar no grupo. 🇲🇿 ✅');
    }

    if (action === 'add') {
      const code = args[1]?.replace(/[+]/g, '');
      if (!code) return msg.reply(`🛡 Especifica o código de país.\n✎ Exemplo: *${usedPrefix + command} add +1*`);
      const codes = setting?.antiarabeCodes || [];
      if (codes.includes(code)) return msg.reply(`🛡 O código *+${code}* já está bloqueado.`);
      codes.push(code);
      db.setChat(msg.chat, 'antiarabeCodes', codes);
      db.setChat(msg.chat, 'antiarabeMode', 'block');
      return msg.reply(`🛡 Código *+${code}* adicionado à lista de bloqueados. ✅`);
    }

    if (action === 'remove') {
      const code = args[1]?.replace(/[+]/g, '');
      if (!code) return msg.reply(`🛡 Especifica o código de país.\n✎ Exemplo: *${usedPrefix + command} remove +1*`);
      let codes = setting?.antiarabeCodes || [];
      codes = codes.filter(c => c !== code);
      db.setChat(msg.chat, 'antiarabeCodes', codes);
      return msg.reply(`🛡 Código *+${code}* removido da lista de bloqueados. ✅`);
    }
  },
};
