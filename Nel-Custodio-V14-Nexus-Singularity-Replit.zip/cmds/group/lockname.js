import db from '#db';
export default {
  command: ['lockname', 'travarnome', 'bloquearnome'],
  category: 'moderacao',
  description: 'Travar o nome do grupo para que ninguém besides admins possa alterar.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata }) => {
    const setting = db.getChatSetting(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'status'].includes(action)) {
      const status = setting?.lockname ? '🔒 Travado' : '🔓 Destravado';
      const currentName = groupMetadata?.subject || 'Desconhecido';
      return msg.reply(
        `❧ *Travar Nome do Grupo*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Nome actual: *${currentName}*\n\n` +
        `✎ *Opções:*\n` +
        `> *${usedPrefix + command} on* - Travar nome\n` +
        `> *${usedPrefix + command} off* - Destravar nome\n` +
        `> *${usedPrefix + command} status* - Ver estado`
      );
    }

    if (action === 'status') {
      const status = setting?.lockname ? '🔒 Travado' : '🔓 Destravado';
      const currentName = groupMetadata?.subject || 'Desconhecido';
      return msg.reply(`❧ Nome do grupo: ${status}\n▸ Nome: *${currentName}*`);
    }

    if (action === 'on') {
      const currentName = groupMetadata?.subject || 'Sem nome';
      db.updateChatSetting(msg.chat, 'lockname', true);
      db.updateChatSetting(msg.chat, 'lockedname', currentName);
      return msg.reply(`❧ Nome do grupo *travado* com sucesso! 🔒\n▸ Nome protegido: *${currentName}*`);
    }

    if (action === 'off') {
      db.updateChatSetting(msg.chat, 'lockname', false);
      return msg.reply('❧ Nome do grupo *destravado*. 🔓');
    }
  },
};
