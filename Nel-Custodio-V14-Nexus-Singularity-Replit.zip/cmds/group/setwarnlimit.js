import db from '#db';
export default {
  command: ['setwarnlimit'],
  category: 'grupos',
  description: 'Definir o limite de advertências do grupo.',
  isAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    db.setCreate('chats', msg.chat, 'expulsar', 0);
    db.setCreate('chats', msg.chat, 'warnLimit', 0);
    let chat = db.getChat(msg.chat);
    const raw = args[0];
    const limit = parseInt(raw);
    if (isNaN(limit) || limit < 0 || limit > 10) {
      return msg.reply(`✐ O limite de advertências deve ser um número entre \`1\` y \`10\`, o \`0\` para desactivar.\n> Exemplo 1 › *${usedPrefix + command} 5*\n> Exemplo 2 › *${usedPrefix + command} 0*\n\n> Si usas \`0\`, se desactivará a função de remover usuários ao atingir o limite de advertências.\n❖ Estado actual: ${chat.expulsar ? `\`${chat.warnLimit}\` advertências` : '`Desativado`'}`);
    }
    if (limit === 0) {
      chat.warnLimit = 0;
      chat.expulsar = 0;
      db.setChat(msg.chat, 'warnLimit', 0);
      db.setChat(msg.chat, 'expulsar', 0);
      return msg.reply(`✐ Has desativado a função de remover usuários ao atingir o limite de advertências.`);
    }
    chat.warnLimit = limit;
    chat.expulsar = 1;
    db.setChat(msg.chat, 'warnLimit', limit);
    db.setChat(msg.chat, 'expulsar', 1);
    await msg.reply(`✐ Limite de advertências definido em \`${limit}\` para este grupo.\n> ❖ Os usuários serão expulsos automaticamente ao atingir este límite.`);
  },
};
