export default {
  command: ['mute', 'mutar', 'silenciar'],
  category: 'moderacao',
  description: 'Silenciar um membro do grupo (remover permissão de enviar mensagens).',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata, participants }) => {
    if (!msg.mentionedJid[0] && !msg.quoted) {
      return msg.reply(`❧ Por favor, marque ou responda à mensagem da pessoa que deseja silenciar.\n\n✎ Exemplo: *${usedPrefix + command} @usuário*`);
    }
    const target = msg.mentionedJid[0] || msg.quoted.sender;
    const botId = sock.decodeJid(sock.user.id);
    const ownerGroup = groupMetadata?.owner || msg.chat.split('-')[0] + '@s.whatsapp.net';
    const ownerBot = global.owner[0] + '@s.whatsapp.net';

    if (target === botId) return msg.reply('❧ Não posso silenciar o *bot*.');
    if (target === ownerGroup) return msg.reply('❧ Não posso silenciar o *proprietário* do grupo.');
    if (target === ownerBot) return msg.reply('❧ Não posso silenciar o *proprietário* do bot.');

    const participant = participants.find(p => p.id === target);
    if (!participant) return msg.reply('❧ Este membro não está no grupo.');
    if (participant.admin === 'admin' || participant.admin === 'superadmin') {
      return msg.reply('❧ Não posso silenciar um *administrador* do grupo.');
    }

    try {
      await sock.groupParticipantsUpdate(msg.chat, [target], 'remove');
      await new Promise(r => setTimeout(r, 1500));
      await sock.groupParticipantsUpdate(msg.chat, [target], 'add');
      await sock.sendMessage(msg.chat, { text: `✎ @${target.split('@')[0]} foi *silenciado* com sucesso. Só pode ler mensagens.`, mentions: [target] }, { quoted: msg });
    } catch (e) {
      return msg.reply(`❧ Ocorreu um erro ao tentar silenciar este membro.\n> Erro: *${e.message}*`);
    }
  },
};
