export default {
  command: ['setgpname'],
  category: 'grupos',
  description: 'Mudar o nome do grupo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const newName = args.join(' ').trim();
    if (!newName) {
      return msg.reply('《✧》 Por favor, insira o novo nome que deseja pôr no grupo.');
    }
    try {
      await sock.groupUpdateSubject(msg.chat, newName);
      msg.reply(`✿ O nome do grupo foi modificado corretamente.`);
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};