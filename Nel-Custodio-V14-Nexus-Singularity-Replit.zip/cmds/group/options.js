import db from '#db';
export default {
  command: ['welcome', 'boas-vindas', 'goodbye', 'bye', 'despedida', 'alerts', 'alertas', 'nsfw', 'antilink', 'antilinks', 'antistatus', 'antiestados', 'rpg', 'economy', 'economia', 'gacha', 'adminonly', 'onlyadmin'],
  category: 'grupos',
  description: 'Configurar opções do grupo.',
  isAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let chatData = db.getChat(msg.chat);
    const botId = sock.user.id.split(':')[0] + "@s.whatsapp.net";
    const botSettings = db.getSettings(botId) || {};
    const botname = botSettings.botname || 'Bot';
    const stateArg = args[0]?.toLowerCase();
    const validStates = ['on', 'off', 'enable', 'disable'];
    const mapTerms = {
      antilinks: 'antilinks',
      antilinks: 'antilinks',
      antilink: 'antilinks',
      antistatus: 'antistatus',
      antiestados: 'antistatus',
      welcome: 'welcome',
      'boas-vindas': 'welcome',
      goodbye: 'goodbye',
      despedida: 'goodbye',
      alerts: 'alerts',
      alertas: 'alerts',
      economy: 'economy',
      economia: 'economy',
      adminonly: 'adminonly',
      onlyadmin: 'adminonly',
      nsfw: 'nsfw',
      rpg: 'gacha',
      gacha: 'gacha'
    };
    const featureNames = {
      antilinks: 'o *AntiLink*',
      antistatus: 'o *AntiEstado*',
      welcome: 'a mensagem de *Boas-Vindas*',
      goodbye: 'a mensagem de *Despedida*',
      alerts: 'os *Alertas*',
      economy: 'os comandos de *Economia*',
      gacha: 'os comandos de *Gacha*',
      adminonly: 'o modo *Só Admin*',
      nsfw: 'os comandos *NSFW*'
    };
    const featureTitles = {
      antilinks: 'AntiLink',
      antistatus: 'AntiEstado',
      welcome: 'Boas-Vindas',
      goodbye: 'Despedida',
      alerts: 'Alertas',
      economy: 'Economia',
      gacha: 'Gacha',
      adminonly: 'AdminOnly',
      nsfw: 'NSFW'
    };
    const messages = {
      antilinks: `> Se o *anti-link* está ativado, o *${botname}* removerá todos os usuários que enviem links de outros grupos.`,
      antistatus: `> Se o *anti-estado* está ativado, o *${botname}* removerá todos os usuários que mencionem o grupo nos seus estados.`,
      welcome: `> Se a mensagem de boas-vindas está ativada, o *${botname}* enviará uma saudação aos novos membros do grupo.`,
      goodbye: `> Se a mensagem de despedida está ativada, o *${botname}* enviará uma mensagem quando um utilizador sair do grupo.`,
      alerts: `> Se os alertas estão ativados, o *${botname}* avisará os administradores quando houver mudanças na administração.`,
      adminonly: `> Se o modo *Só Admin* está ativado, apenas os administradores poderão utilizar os comandos do bot.`
    };
    const normalizedKey = mapTerms[command] || command;
    const current = chatData[normalizedKey] === true || chatData[normalizedKey] === 1;
    const estado = current ? '✓ Ativado' : '✗ Desativado';
    const nombreBonito = featureNames[normalizedKey] || `a função *${normalizedKey}*`;
    const titulo = featureTitles[normalizedKey] || normalizedKey;
    const types = messages[normalizedKey] || "";
    if (!stateArg) {
      return sock.reply(msg.chat, `*✩ ${titulo} (✿❛◡❛)*\n\nꕥ Um administrador pode ativar ou desativar ${nombreBonito} utilizando:\n\n● _Habilitar ›_ *${usedPrefix + normalizedKey} on*\n● _Desabilitar ›_ *${usedPrefix + normalizedKey} off*\n\n❒ *Estado atual ›* ${estado}\n${types}`, msg);
    }
    if (!validStates.includes(stateArg)) {
      return msg.reply(`✎ Estado inválido. Usa *on*, *off*, *enable* ou *disable*\n\nExemplo:\n${usedPrefix}${normalizedKey} on`);
    }
    const enabled = ['on', 'enable'].includes(stateArg);
    const newValue = enabled ? 1 : 0;
    if ((chatData[normalizedKey] === 1 && enabled) || (chatData[normalizedKey] === 0 && !enabled) || (chatData[normalizedKey] === true && enabled) || (chatData[normalizedKey] === false && !enabled)) {
      return msg.reply(`✎ *${titulo}* já estava *${enabled ? 'ativado' : 'desativado'}*.`);
    }
    chatData[normalizedKey] = newValue;
    db.setChat(msg.chat, normalizedKey, newValue);
    return msg.reply(`✎ Você *${enabled ? 'ativou' : 'desativou'}* ${nombreBonito}.`);
  }
};
