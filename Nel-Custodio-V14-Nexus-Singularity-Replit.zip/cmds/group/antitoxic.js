import db from '#db';
export default {
  command: ['antitoxic', 'antipalavrão', 'antipalavrao', 'badword'],
  category: 'moderacao',
  description: 'Sistema anti-palavrões. Detecta palavrões e toma ação automática (apagar, avisar ou expulsar).',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const setting = db.getChat(msg.chat);
    const action = args[0]?.toLowerCase();

    if (!action || !['on', 'off', 'add', 'remove', 'list', 'mode', 'status'].includes(action)) {
      const status = setting?.antitoxic ? '✅ Ativo' : '❌ Inativo';
      const mode = setting?.antitoxicMode || 'delete';
      const modeText = mode === 'delete' ? 'Apagar mensagem' : mode === 'warn' ? 'Avisar + Apagar' : 'Expulsar + Apagar';
      const words = setting?.antitoxicWords || ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu'];
      return msg.reply(
        `☡ *Sistema Anti-Tóxico*\n\n` +
        `▸ Estado: ${status}\n` +
        `▸ Modo: *${modeText}*\n` +
        `▸ Palavrões bloqueados: *${words.length} palavras*\n\n` +
        `✎ *Opções disponíveis:*\n` +
        `> *${usedPrefix + command} on* - Ativar\n` +
        `> *${usedPrefix + command} off* - Desativar\n` +
        `> *${usedPrefix + command} mode delete|warn|kick* - Mudar modo\n` +
        `> *${usedPrefix + command} add <palavra>* - Adicionar palavrão\n` +
        `> *${usedPrefix + command} remove <palavra>* - Remover palavrão\n` +
        `> *${usedPrefix + command} list* - Ver lista de palavrões\n` +
        `> *${usedPrefix + command} status* - Ver estado`
      );
    }

    if (action === 'status' || action === 'list') {
      const status = setting?.antitoxic ? '✅ Ativo' : '❌ Inativo';
      const words = setting?.antitoxicWords || ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu'];
      return msg.reply(`☡ Anti-Tóxico: ${status}\n▸ Palavrões: *${words.join(', ')}*`);
    }

    if (action === 'on') {
      db.setChat(msg.chat, 'antitoxic', 1);
      if (!setting?.antitoxicMode) db.setChat(msg.chat, 'antitoxicMode', 'delete');
      if (!setting?.antitoxicWords) db.setChat(msg.chat, 'antitoxicWords', ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu']);
      return msg.reply('☡ *Anti-Tóxico* ativado! Mensagens com palavrões serão tratadas automaticamente. ✅');
    }

    if (action === 'off') {
      db.setChat(msg.chat, 'antitoxic', 0);
      return msg.reply('☡ *Anti-Tóxico* desativado. ❌');
    }

    if (action === 'mode') {
      const mode = args[1]?.toLowerCase();
      if (!mode || !['delete', 'warn', 'kick'].includes(mode)) {
        return msg.reply(`☡ Especifica o modo: *delete*, *warn* ou *kick*\n✎ Exemplo: *${usedPrefix + command} mode warn*`);
      }
      db.setChat(msg.chat, 'antitoxicMode', mode);
      const modeText = mode === 'delete' ? 'Apagar mensagem' : mode === 'warn' ? 'Avisar + Apagar' : 'Expulsar + Apagar';
      return msg.reply(`☡ Modo anti-tóxico alterado para: *${modeText}* ✅`);
    }

    if (action === 'add') {
      const word = args[1]?.toLowerCase();
      if (!word) return msg.reply(`☡ Especifica o palavrão.\n✎ Exemplo: *${usedPrefix + command} add desgraça*`);
      const words = setting?.antitoxicWords || ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu'];
      if (words.includes(word)) return msg.reply(`☡ A palavra *${word}* já está na lista.`);
      words.push(word);
      db.setChat(msg.chat, 'antitoxicWords', words);
      return msg.reply(`☡ Palavra *${word}* adicionada à lista de palavrões. ✅`);
    }

    if (action === 'remove') {
      const word = args[1]?.toLowerCase();
      if (!word) return msg.reply(`☡ Especifica o palavrão.\n✎ Exemplo: *${usedPrefix + command} remove desgraça*`);
      let words = setting?.antitoxicWords || ['caralho', 'puta', 'merda', 'foda', 'porra', 'cabrão', 'crl', 'fdp', 'viado', 'bicha', 'cu'];
      words = words.filter(w => w !== word);
      db.setChat(msg.chat, 'antitoxicWords', words);
      return msg.reply(`☡ Palavra *${word}* removida da lista de palavrões. ✅`);
    }
  },
};
