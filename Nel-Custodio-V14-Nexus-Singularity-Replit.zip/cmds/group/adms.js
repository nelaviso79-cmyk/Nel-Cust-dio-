export default {
  command: ['adms', 'adminlist2', 'listaradm2', 'quemadm'],
  category: 'grupos',
  description: 'Ver lista rápida de administradores do grupo 👑',
  run: async ({ msg, sock }) => {
    if (!msg.key.remoteJid.endsWith('@g.us')) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ Apenas em grupos!' }, { quoted: msg });

    try {
      const meta = await sock.groupMetadata(msg.key.remoteJid);
      const admins = meta.participants.filter(p => p.admin);
      const owner = meta.participants.find(p => p.admin === 'superadmin');

      let result = `👑 *ADMINISTRADORES DE ${meta.subject}*\n\n`;
      if (owner) {
        result += `🌟 Criador: @${owner.id.split('@')[0]}\n\n`;
      }
      result += `🛡️ Admins (${admins.length}):\n`;
      admins.forEach((p, i) => {
        if (p.admin === 'superadmin') return;
        result += `${i + 1}. @${p.id.split('@')[0]}\n`;
      });
      result += `\n📊 Total: *${meta.participants.length}* membros`;

      await sock.sendMessage(msg.key.remoteJid, {
        text: result,
        mentions: admins.map(p => p.id)
      }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ Erro ao obter dados do grupo.' }, { quoted: msg });
    }
  }
};
