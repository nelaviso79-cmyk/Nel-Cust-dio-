import db from '#db';
export default {
  command: ['kick', 'ban', 'bang'],
  category: 'grupos',
  description: 'Expulsar um usuário do grupo.',
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata, participants }) => {
    const ownerGroup = groupMetadata?.owner || msg.chat.split('-')[0] + '@s.whatsapp.net';
    const ownerBot = global.owner + '@s.whatsapp.net';
    const botId = sock.decodeJid(sock.user.id);
    if (args[0] === 'num' || args[0] === 'listnum') {
      if (!args[1]) return msg.reply(`《✧》 Insira algún prefixo de um país\n> ✎ Exemplo: *${usedPrefix + command} num +54*`);
      const prefix = args[1].replace(/[+]/g, '');
      const allUsersWithPrefix = participants.map(p => p.id).filter(jid => jid && jid !== botId && jid.split('@')[0].startsWith(prefix));
      if (allUsersWithPrefix.length === 0) return msg.reply(`《✧》 Aqui não há nenhum número com o prefixo +${prefix}`);
      if (args[0] === 'listnum') {
        const numeros = allUsersWithPrefix.map(v => '⭔ @' + v.replace(/@.+/, ''));
        return sock.reply(msg.chat, `《✧》 *Lista de usuários com prefixo +${prefix}* (${allUsersWithPrefix.length})\n\n${numeros.join('\n')}`, msg, { mentions: allUsersWithPrefix });
      }
      const usersToKick = allUsersWithPrefix.filter(jid => {
        const p = participants.find(x => x.id === jid);
        if (!p) return false;
        if (p.admin === 'admin' || p.admin === 'superadmin') return false;
        if (jid === ownerGroup || jid === ownerBot) return false;
        return true;
      });
      if (usersToKick.length === 0) return msg.reply(`《✧》 Há usuários com prefixo +${prefix} mas todos são admins o proprietários.`);
      await msg.reply(`《✧》 *A remover usuários com prefixo +${prefix}* (${usersToKick.length} de ${allUsersWithPrefix.length})\n> O processo tomará alguns segundos...`);
      let eliminados = 0, errores = [], noEliminados = allUsersWithPrefix.length - usersToKick.length;
      for (const jid of usersToKick) {
        try { await sock.groupParticipantsUpdate(msg.chat, [jid], 'remove'); eliminados++; await new Promise(r => setTimeout(r, 3000)); }
        catch (e) { errores.push(`@${jid.split('@')[0]}: ${e.message}`); }
      }
      let res = `《✧》 Processo concluído.\n> Usuários removidos: *${eliminados}*`;
      if (noEliminados > 0) res += `\n> Usuários omitidos (admins/owners): *${noEliminados}*`;
      if (errores.length > 0) res += `\n> Erros: *${errores.length}*\n${errores.join('\n')}`;
      return msg.reply(res);
    }
    if (args[0] === 'all') {
      const usersToKick = participants.filter(p => p.id && p.id !== botId && p.id !== ownerGroup && p.id !== ownerBot && p.admin !== 'admin' && p.admin !== 'superadmin').map(p => p.id);
      if (usersToKick.length === 0) return msg.reply('《✧》 Não há usuários para remover (todos são admins ou proprietários).');
      await msg.reply(`《✧》 *A remover todos os usuários* (${usersToKick.length})\n> O processo tomará alguns segundos...`);
      let eliminados = 0, errores = [], noEliminados = participants.length - usersToKick.length;
      for (const jid of usersToKick) {
        try { await sock.groupParticipantsUpdate(msg.chat, [jid], 'remove'); eliminados++; await new Promise(r => setTimeout(r, 3000)); }
        catch (e) { errores.push(`@${jid.split('@')[0]}: ${e.message}`); }
      }
      let res = `《✧》 Processo concluído.\n> Usuários removidos: *${eliminados}*`;
      if (noEliminados > 0) res += `\n> Usuários omitidos (admins/owners): *${noEliminados}*`;
      if (errores.length > 0) res += `\n> Erros: *${errores.length}*\n${errores.join('\n')}`;
      return msg.reply(res);
    }
    if (args[0] === 'inactive' || args[0] === 'listinactive') {
      const allChatUsers = db.getChatUser(msg.chat);
      const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      let sider = [];
      for (const participant of participants) {
        const jid = participant.id;
        if (!jid || jid === botId || jid === ownerGroup || jid === ownerBot) continue;
        if (participant.admin === 'admin' || participant.admin === 'superadmin') continue;
        const userStats = allChatUsers.find(u => u.user_id === jid || u.user_id?.split('@')[0] === jid.split('@')[0]);
        if (userStats) {
          const days = Object.entries(userStats.stats || {}).filter(([date]) => new Date(date) >= cutoff);
          const totalMsgs = days.reduce((acc, [, d]) => acc + (d.msgs || 0), 0);
          if (totalMsgs === 0) sider.push(jid);
        } else {
          sider.push(jid);
        }
      }
      if (sider.length === 0) return msg.reply('《✧》 Este grupo é activo, não tem inativos.');
      if (args[0] === 'listinactive')
        return sock.reply(msg.chat, `《✧》 *Lista de inativos* (${sider.length})\n\n${sider.map(v => '⭔ @' + v.replace(/@.+/, '')).join('\n')}`, msg, { mentions: sider });
      await msg.reply(`《✧》 *A remover inativos* (${sider.length})\n> O processo tomará alguns segundos...`);
      let eliminados = 0, errores = [];
      for (const jid of sider) {
        try { await sock.groupParticipantsUpdate(msg.chat, [jid], 'remove'); eliminados++; await new Promise(r => setTimeout(r, 3000)); }
        catch (e) { errores.push(`@${jid.split('@')[0]}: ${e.message}`); }
      }
      let res = `《✧》 Processo concluído. usuários eliminados: *${eliminados}*`;
      if (errores.length > 0) res += `\n> Erros: *[${errores.join('\n')}]*`;
      return msg.reply(res);
    }
    if (!msg.mentionedJid[0] && !msg.quoted) {
      return msg.reply(`《✧》 Por favor, Marca ou responde à *mensagem* da *pessoa* que deseja remover.\n\n✎ *Opções especiais:*\n> *${usedPrefix + command} num +57* - Remover todos os usuários com prefixo +57\n> *${usedPrefix + command} listnum +56* - Listar usuários com prefixo +56\n> *${usedPrefix + command} all* - Remover todos os usuários\n> *${usedPrefix + command} inactive* - Remover usuários inativos últimos (30 dias)\n> *${usedPrefix + command} listinactive* - Listar usuários inactivos`);
    }
    const targetRaw = msg.mentionedJid[0] ? msg.mentionedJid[0] : msg.quoted.sender;
    const userBase = targetRaw.split('@')[0];
    const participant = participants.find(p => p.id?.split('@')[0] === userBase || p.lid?.split('@')[0] === userBase);
    if (!participant) return sock.reply(msg.chat, `《✧》 *@${userBase}* já não está no grupo.`, msg, { mentions: [targetRaw] });
    const realJid = participant.id || targetRaw;
    if (realJid === sock.decodeJid(sock.user.id)) return msg.reply('《✧》 Não posso remover o *bot* do grupo');
    if (realJid === ownerGroup) return msg.reply('《✧》 Não posso remover al *proprietário* do grupo');
    if (realJid === ownerBot)   return msg.reply('《✧》 Não posso remover al *proprietário* do bot');
    try {
      await sock.groupParticipantsUpdate(msg.chat, [realJid], 'remove');
      sock.reply(msg.chat, `✎ @${userBase} *removido* correctamente`, msg, { mentions: [targetRaw] });
    } catch (e) {
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};