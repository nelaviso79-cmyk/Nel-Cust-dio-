export default {
  command: ['bola8', '8ball', 'magic8', 'perguntar'],
  category: 'diversao',
  description: 'Bola mágica 8 - Faça uma pergunta 🔮',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(`🔮 *BOLA MÁGICA 8*\n\n◈ Faça uma pergunta!\n\n✎ Exemplo: *${usedPrefix + command} Vou ficar rico?*`);
    }
    
    const respostas = [
      'Sim, definitivamente! ✨',
      'Sem dúvida nenhuma! 💯',
      'Pode contar com isso! 🌟',
      'Provavelmente sim 👍',
      'Os sinais apontam que sim 📈',
      'Tudo indica que sim 🎯',
      'Resposta nebulosa, tente novamente 🌫️',
      'Pergunte novamente mais tarde ⏳',
      'Melhor não contar agora 🤫',
      'Concentre-se e pergunte de novo 🧘',
      'Não conte com isso 😬',
      'Minha resposta é não ❌',
      'Definitivamente não! 🚫',
      'Muito duvidoso 😤',
      'As probabilidades não são favoráveis 📉',
      'O destino diz: NÃO! 💀'
    ];
    
    const resposta = respostas[Math.floor(Math.random() * respostas.length)];
    
    return msg.reply(
      `🔮 *BOLA MÁGICA 8* 🔮\n\n` +
      `▸ Pergunta: _${text}_\n\n` +
      `▸ Resposta: *${resposta}*\n\n` +
      `_🔮 Nel-Aviso-Bot_`
    );
  }
};
