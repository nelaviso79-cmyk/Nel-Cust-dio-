import fetch from 'node-fetch';
import cheerio from 'cheerio';

export default {
  command: ['noticiasmz', 'mznews', 'moznews'],
  category: 'utilidades',
  description: 'Mostra as últimas notícias de Moçambique.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    await msg.react('📰');
    try {
      // Usando o RSS do Jornal Notícias ou similar (exemplo simplificado via API de notícias se disponível ou scraping)
      // Para este exemplo, usaremos uma busca via API de notícias genérica filtrada por Moçambique
      const res = await fetch(`https://newsapi.org/v2/everything?q=Moçambique&language=pt&sortBy=publishedAt&apiKey=YOUR_NEWSAPI_KEY`);
      // Nota: Como não temos API Key, vamos simular ou usar um site de notícias público
      
      // Alternativa: Scraping rápido do portal MMO ou similar
      const mmo = await fetch('https://noticias.mmo.co.mz/').then(r => r.text());
      const $ = cheerio.load(mmo);
      
      let news = '📰 *ÚLTIMAS NOTÍCIAS DE MOÇAMBIQUE*\n\n';
      
      $('.post-title.entry-title').slice(0, 5).each((i, el) => {
        const title = $(el).text().trim();
        const link = $(el).find('a').attr('href');
        news += `🔹 *${title}*\n🔗 ${link}\n\n`;
      });

      if (news === '📰 *ÚLTIMAS NOTÍCIAS DE MOÇAMBIQUE*\n\n') {
        return msg.reply('❌ Não consegui obter notícias no momento. Tente novamente mais tarde.');
      }

      await msg.reply(news + '> 🇲🇿 *Nel-Aviso-Bot-Moz*');
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao obter notícias: ${e.message}`);
    }
  }
};
