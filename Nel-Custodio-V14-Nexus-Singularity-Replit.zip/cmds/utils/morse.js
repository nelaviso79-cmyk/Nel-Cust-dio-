export default {
  command: ['morse', 'codigomorse', 'morsecode', 'telegrafo'],
  category: 'utilidades',
  description: 'Converter texto para código Morse e vice-versa 📡',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <texto ou morse>\n\nExemplos:\n${usedPrefix}${command} OLA\n${usedPrefix}${command} --- .-.. .-\n\nMorse = pontos(.) e traços(-), letras separadas por espaço` }, { quoted: msg });

    const morseMap = {
      'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
      'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
      'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
      'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
      'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
      '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
      '8': '---..', '9': '----.', '.': '.-.-.-', ',': '--..--', '?': '..--..',
      '!': '-.-.--', ' ': '/'
    };

    const reverseMap = Object.fromEntries(Object.entries(morseMap).map(([k, v]) => [v, k]));

    // Detect if input is morse code
    const isMorse = /^[.\-/\s]+$/.test(text);

    let result = '';
    if (isMorse) {
      // Morse to text
      const letters = text.split(' ');
      const decoded = letters.map(m => {
        if (m === '/') return ' ';
        return reverseMap[m] || '?';
      }).join('');
      result = `📡 *MORSE → TEXTO*\n\n`;
      result += `📥 Morse: ${text}\n`;
      result += `📤 Texto: *${decoded}*\n\n`;
      result += `🔊 Som: ${text.replace(/\./g, 'dit ').replace(/-/g, 'dah ').replace(/\//g, '[pausa] ')}`;
    } else {
      // Text to morse
      const upper = text.toUpperCase();
      const encoded = upper.split('').map(ch => morseMap[ch] || '').filter(Boolean).join(' ');
      result = `📡 *TEXTO → MORSE*\n\n`;
      result += `📥 Texto: ${text}\n`;
      result += `📤 Morse: *${encoded}*\n\n`;
      result += `🔊 Som: ${encoded.replace(/\./g, 'dit ').replace(/-/g, 'dah ').replace(/\//g, '[pausa] ')}`;
    }

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
