export default {
  command: ['casal', 'ship', 'casamento', 'compatibilidade'],
  category: 'diversao',
  description: 'Calcula a compatibilidade entre duas pessoas! 💕',
  run: async ({ msg, sock, usedPrefix, command, sender, participants }) => {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (mentioned.length < 2) {
      return msg.reply(`❥ Mencione duas pessoas para calcular a compatibilidade!\n\n✎ Exemplo: *${usedPrefix + command}* @pessoa1 @pessoa2`);
    }

    const pessoa1 = mentioned[0];
    const pessoa2 = mentioned[1];
    const nome1 = pessoa1.split('@')[0];
    const nome2 = pessoa2.split('@')[0];

    // Gerar percentagem baseada nos números de telefone (consistente)
    const num1 = parseInt(nome1.slice(-4));
    const num2 = parseInt(nome2.slice(-4));
    const percent = ((num1 + num2) % 101);
    
    let coracao = '';
    let status = '';
    if (percent >= 90) { coracao = '💕🔥'; status = 'Casamento Confirmado! Almas gémeas!'; }
    else if (percent >= 75) { coracao = '❤️🔥'; status = 'Muito compatíveis! Relação séria!'; }
    else if (percent >= 60) { coracao = '💗'; status = 'Boa compatibilidade! Talvez dê certo!'; }
    else if (percent >= 40) { coracao = '💛'; status = 'Compatibilidade média. Amizade primeiro!'; }
    else if (percent >= 20) { coracao = '💔'; status = 'Pouca compatibilidade... Complicado!'; }
    else { coracao = '💨'; status = 'Sem compatibilidade! Fuga!'; }

    const barra = '█'.repeat(Math.floor(percent / 5)) + '░'.repeat(20 - Math.floor(percent / 5));

    return msg.reply(
      `💘 *TESTE DE COMPATIBILIDADE* 💘\n\n` +
      `▸ @${nome1}\n` +
      `▸ @${nome2}\n\n` +
      `[${barra}] ${percent}%\n\n` +
      `${coracao} ${status}\n\n` +
      `_Resultados gerados pelo Nel-Aviso-Bot_`
    , { mentions: [pessoa1, pessoa2] });
  },
};
