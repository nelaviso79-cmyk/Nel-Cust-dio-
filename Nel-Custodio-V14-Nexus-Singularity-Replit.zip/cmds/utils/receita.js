// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/receita.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['receita', 'recipe', 'cozinhar', 'cozinha', 'prato'],
  category: 'utilidades',
  description: 'Buscar receitas de cozinha com ingredientes e passo-a-passo 🍳',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ').trim();

    if (!query) {
      return msg.reply(
        `🍳 *RECEITAS* 🍳\n\n` +
        `Busque receitas pelo nome ou ingrediente!\n\n` +
        `📋 Exemplos:\n` +
        `• *${usedPrefix}${command} matapa*\n` +
        `• *${usedPrefix}${command} frango assado*\n` +
        `• *${usedPrefix}${command} arroz com feijão*\n\n` +
        `> Mostra ingredientes, tempo e passo-a-passo!`
      );
    }

    await msg.reply(`⏳ A buscar receita de *${query}*...`);

    try {
      // Primary: Cookpad via Delirius
      const res = await fetch(
        `https://api.delirius.store/search/cookpad?query=${encodeURIComponent(query)}&country=MZ`
      );
      const data = await res.json();

      if (data.status && data.result && data.result.length > 0) {
        const recipes = data.result.slice(0, 3);

        for (const recipe of recipes) {
          let text =
            `🍳 *${recipe.title || recipe.name}*\n\n` +
            `👤 Autor: ${recipe.author || 'Desconhecido'}\n` +
            `⏱ Tempo: ${recipe.time || recipe.cook_time || 'N/A'}\n` +
            `🍽 Porções: ${recipe.servings || recipe.yield || 'N/A'}\n\n`;

          if (recipe.ingredients) {
            const ings = Array.isArray(recipe.ingredients) ? recipe.ingredients : recipe.ingredients.split('\n');
            text += `📋 *INGREDIENTES:*\n`;
            for (const ing of ings.slice(0, 15)) {
              text += `• ${ing}\n`;
            }
            text += '\n';
          }

          if (recipe.steps || recipe.instructions) {
            const steps = Array.isArray(recipe.steps || recipe.instructions)
              ? (recipe.steps || recipe.instructions)
              : (recipe.steps || recipe.instructions).split('\n');
            text += `👩‍🍳 *MODO DE PREPARO:*\n`;
            for (let i = 0; i < Math.min(steps.length, 10); i++) {
              text += `${i + 1}. ${steps[i]}\n`;
            }
          }

          if (recipe.url || recipe.link) {
            text += `\n🔗 ${recipe.url || recipe.link}`;
          }

          if (recipe.image || recipe.thumbnail) {
            await sock.sendMessage(msg.chat, {
              image: { url: recipe.image || recipe.thumbnail },
              caption: text
            }, { quoted: msg });
          } else {
            await msg.reply(text);
          }
        }

        if (recipes.length > 1) {
          await msg.reply(`✅ Mostrando *${recipes.length}* receitas de *${query}*`);
        }
        return;
      }

      // Fallback: try cookpad detail with different format
      const res2 = await fetch(
        `https://api.delirius.store/search/cookpad?query=${encodeURIComponent(query)}`
      );
      const data2 = await res2.json();

      if (data2.status && data2.result && data2.result.length > 0) {
        const r = data2.result[0];
        const text =
          `🍳 *${r.title || r.name || query}*\n\n` +
          `${r.description || r.summary || ''}\n\n` +
          `🔗 ${r.url || r.link || 'Sem link'}`;

        if (r.image || r.thumbnail) {
          await sock.sendMessage(msg.chat, {
            image: { url: r.image || r.thumbnail },
            caption: text
          }, { quoted: msg });
        } else {
          await msg.reply(text);
        }
        return;
      }

      await msg.reply(
        `❌ Nenhuma receita encontrada para *${query}*.\n` +
        `> Tente um termo diferente ou em inglês.`
      );
    } catch (e) {
      await msg.reply(`❌ Erro ao buscar receita: *${e.message}*`);
    }
  }
};
