import moment from 'moment-timezone';
import { getKeepAliveStats } from '#core/keepAlive';
import os from 'os';

function formatarMs(ms) {
  const segundos = Math.floor(ms / 1000);
  const minutos = Math.floor(segundos / 60);
  const horas = Math.floor(minutos / 60);
  const dias = Math.floor(horas / 24);
  return [dias && `${dias}d`, `${horas % 24}h`, `${minutos % 60}m`, `${segundos % 60}s`].filter(Boolean).join(' ');
}

export default {
  command: ['status247', 'antisleep', '247', 'saude', 'nexushealth'],
  category: 'utilidades',
  description: 'Ver o estado de saúde e uptime 24/7 do núcleo Nexus.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const stats = getKeepAliveStats();
      const now = moment.tz('Africa/Maputo').format('DD/MM/YYYY HH:mm:ss');
      
      const memUsage = process.memoryUsage();
      const heapUsed = Math.round(memUsage.heapUsed / 1024 / 1024);
      const totalMem = Math.round(os.totalmem() / 1024 / 1024);
      const freeMem = Math.round(os.freemem() / 1024 / 1024);
      
      const botUptime = formatarMs(process.uptime() * 1000);
      const keepUptime = formatarMs(stats.uptime);
      const lastPing = stats.lastPing ? moment(stats.lastPing).tz('Africa/Maputo').format('DD/MM/YYYY HH:mm:ss') : 'Nenhum sinal';

      const start = Date.now();
      await msg.react('📡');
      const ping = Date.now() - start;

      const texto = `╭───「 🔋 *NEXUS CORE HEALTH* 」
│
│ 👑 *Dono:* Nel Custódio
│ 🤖 *Núcleo:* Nexus V12 Intelligence
│ 📡 *Latência:* ${ping}ms
│
├─「 ⏱️ *UPTIME & PINGS* 」
│ 🕒 Nexus Online: *${keepUptime}*
│ 🔄 Processo Vivo: *${botUptime}*
│ 📥 Sinais Recebidos: *${stats.pings}*
│ 🕐 Último Sinal: *${lastPing}*
│
├─「 💾 *HARDWARE NEXUS* 」
│ 📟 RAM em Uso: *${heapUsed}MB*
│ 📊 RAM Livre: *${freeMem}MB* / *${totalMem}MB*
│ 🔋 Anti-Sleep: *${stats.isRunning ? '✅ ATIVO' : '❌ INATIVO'}*
│
╰───────────────────
_Verificado em: ${now}_
_Nexus Intelligence - Monitorização Ativa_`;

      return msg.reply(texto);
    } catch (e) {
      console.error(e);
      return msg.reply(`❌ Erro ao aceder aos sensores de saúde Nexus.`);
    }
  }
};
