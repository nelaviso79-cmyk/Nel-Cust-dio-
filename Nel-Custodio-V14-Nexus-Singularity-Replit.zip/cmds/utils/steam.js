// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/steam.js
//   Steam — Informações de jogos da Steam
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'steam',
  aliases: ['steaminfo', 'jogosteam', 'steamsearch', 'gameinfo'],
  description: 'Informações de jogos da Steam (preço, avaliação, requisitos)',
  category: 'utilidades',
  usage: '.steam <nome do jogo>',
  example: '.steam GTA V'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o nome do jogo!\n\n💡 *Uso:* .steam <nome do jogo>\n📌 *Ex:* .steam GTA V'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🎮', key: msg.key } });

  try {
    // Delirius Search — /search/steam
    const res = await fetch(`https://api.delirius.store/search/steam?query=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const game = data.result[0];
      const g = game;

      // Formatar preço
      let priceStr = 'Gratuito 🆓';
      if (g.price && g.price !== 'Free' && g.price !== '0') {
        priceStr = g.price;
      } else if (g.isFree) {
        priceStr = 'Gratuito 🆓';
      }

      // Formatar desconto
      let discountStr = '';
      if (g.discount && g.discount !== '0' && g.discount !== 0) {
        discountStr = `\n  • Desconto: 🔥 -${g.discount}%`;
      }

      const info = `🎮 *STEAM* — Informação do Jogo

━━━━━━━━━━━━━━━━━━━━

🕹️ *${g.title || g.name || 'N/A'}*

💰 *Preço:*
  • ${priceStr}${discountStr}

⭐ *Avaliação:*
  • ${g.review || g.rating || 'N/A'}

📋 *Detalhes:*
  • ID: ${g.id || g.appId || 'N/A'}
  • Lançamento: ${g.releaseDate || g.released || 'N/A'}
  • Desenvolvedor: ${g.developer || 'N/A'}
  • Editora: ${g.publisher || 'N/A'}
${g.genre ? `  • Género: ${g.genre}` : ''}
${g.platforms ? `  • Plataformas: ${g.platforms}` : ''}

🔗 *Link:* ${g.url || g.link || `https://store.steampowered.com/app/${g.id || g.appId}`}`;

      // Enviar imagem se disponível
      const imgUrl = g.image || g.headerImage || g.img || g.thumbnail;
      if (imgUrl) {
        try {
          const imgRes = await fetch(imgUrl);
          if (imgRes.ok) {
            const buffer = Buffer.from(await imgRes.arrayBuffer());
            await sock.sendMessage(from, {
              image: buffer,
              caption: info,
              contextInfo: {
                externalAdReply: {
                  title: g.title || g.name || 'Steam Game',
                  body: priceStr,
                  thumbnailUrl: imgUrl,
                  mediaType: 1
                }
              }
            }, { quoted: msg });
            return;
          }
        } catch (e) { }
      }

      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Steam primary failed:', e.message);
  }

  // Fallback — buscar via web search
  try {
    const res = await fetch(`https://api.delirius.store/search/google?query=${encodeURIComponent(query + ' site:store.steampowered.com')}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const result = data.result[0];
      await sock.sendMessage(from, {
        text: `🎮 *Steam Search*\n\n📌 ${result.title || query}\n🔗 ${result.url || 'N/A'}\n📝 ${result.description || 'Sem descrição'}\n\n_⚠️ Resultado parcial — API Steam indisponível_`
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Steam fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: `❌ Não encontrei "${query}" na Steam. Verifica o nome do jogo.`
  }, { quoted: msg });
}
