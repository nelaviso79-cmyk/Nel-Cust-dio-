import db from '#db';
export default {
  command: ['sorteio', 'giveaway', 'sortear'],
  category: 'diversao',
  description: 'Fazer um sorteio aleatório entre os membros do grupo.',
  isAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, participants }) => {
    if (!args.length) {
      return msg.reply(
        `❧ *Sorteio no Grupo* 🎲\n\n` +
        `✎ Como usar:\n` +
        `> *${usedPrefix + command} prémio*\n\n` +
        `▸ Exemplo: *${usedPrefix + command} 100 coins*`
      );
    }

    const prize = args.join(' ');
    const botId = sock.decodeJid(sock.user.id);
    const ownerGroup = msg.chat.split('-')[0] + '@s.whatsapp.net';

    // Filter out bot and owner
    const eligible = participants.filter(p => 
      p.id && p.id !== botId && p.id !== ownerGroup && 
      p.admin !== 'superadmin'
    ).map(p => p.id);

    if (eligible.length < 2) {
      return msg.reply('❧ Precisas de pelo menos 2 membros para fazer um sorteio.');
    }

    const winner = eligible[Math.floor(Math.random() * eligible.length)];
    const winnerNum = winner.replace(/@.+/, '');

    return sock.reply(msg.chat, 
      `❧ *SORTEIO* 🎉\n\n` +
      `▸ Prémio: *${prize}*\n` +
      `▸ Participantes: *${eligible.length}*\n\n` +
      `🏆 *O vencedor é:* @${winnerNum}\n\n` +
      `Parabéns! 🎊🎆`, 
      msg, 
      { mentions: [winner] }
    );
  },
};
