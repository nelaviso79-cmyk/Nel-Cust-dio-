export default {
  command: ['quote', 'quotecard', 'quoteimg'],
  category: 'diversao',
  description: 'Cria um cartão de citação com imagem de perfil',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command, sender, pushname }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} citação*\n\nExemplo: ${usedPrefix}${command} A vida é bela`);

    await msg.react('⏳');
    try {
      let avatarUrl = '';
      try {
        avatarUrl = await sock.profilePictureUrl(sender, 'image');
      } catch {
        avatarUrl = 'https://i.imgur.com/0h9pKfg.jpg';
      }

      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/quote?avatar=${encodeURIComponent(avatarUrl)}&text=${encodeURIComponent(text)}&username=${encodeURIComponent(pushname || 'User')}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `💬 *Quote Card*\n👤 ${pushname}\n📝 ${text}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar citação: ${e.message}`);
    }
  }
};
