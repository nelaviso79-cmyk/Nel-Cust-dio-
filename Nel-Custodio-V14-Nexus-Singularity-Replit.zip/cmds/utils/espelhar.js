import fs from 'fs';
import { spawn } from 'child_process';

export default {
  command: ['espelhar', 'mirror', 'flip', 'espelho'],
  category: 'utilidades',
  description: 'Espelhar uma imagem horizontalmente 🪞',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com:\n${usedPrefix + command} [h|v]\n\n✎ h = horizontal, v = vertical`);
    }
    
    const mode = (text || 'h').toLowerCase();
    if (!['h', 'v', 'horizontal', 'vertical'].includes(mode)) {
      return msg.reply('◈ Modo inválido! Use: h (horizontal) ou v (vertical)');
    }
    
    const flipFilter = mode.startsWith('v') ? 'vflip' : 'hflip';
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/mirror_in_${Date.now()}.jpg`;
      const outputPath = `./tmp/mirror_out_${Date.now()}.jpg`;
      fs.writeFileSync(inputPath, buffer);
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', flipFilter, outputPath]);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      const tipo = mode.startsWith('v') ? 'verticalmente' : 'horizontalmente';
      await sock.sendMessage(msg.chat, { image: result, caption: `◈ Imagem espelhada ${tipo}! 🪞` }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro: ${e.message}`);
    }
  }
};
