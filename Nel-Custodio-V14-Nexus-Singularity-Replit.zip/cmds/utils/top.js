/**
 * 📊 TOP — Top usuários mais activos do grupo (completo)
 */
import db from '#db';

export default {
  command: ['top', 'topactivos', 'topativos', 'rankingactivos', 'maisactivos'],
  category: 'grupos',
  description: 'Top usuários mais activos do grupo 📊',
  run: async ({ msg, sock, from, isGroup }) => {
    if (!isGroup) return msg.reply('❌ Só funciona em grupos.');

    try {
      const chat = db.getChat(from) || {};
      const members = chat.members || {};

      // Ordenar por mensagemCount
      const entries = Object.entries(members).sort((a, b) => {
        const countA = a[1]?.messageCount || a[1]?.msg || 0;
        const countB = b[1]?.messageCount || b[1]?.msg || 0;
        return countB - countA;
      });

      if (!entries.length) return msg.reply('❌ Sem dados de actividade ainda.');

      const top = entries.slice(0, 10);
      const medalhas = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

      let r = `📊 *TOP 10 ACTIVOS*\n\n`;

      for (let i = 0; i < top.length; i++) {
        const [jid, data] = top[i];
        const count = data?.messageCount || data?.msg || 0;
        const nome = data?.name || data?.nome || jid.split('@')[0];
        r += `${medalhas[i]} ${nome}: *${count}* msgs\n`;
      }

      // Posição do remetente
      const senderPos = entries.findIndex(e => e[0] === msg.sender);
      if (senderPos > 2) {
        const senderCount = entries[senderPos]?.[1]?.messageCount || entries[senderPos]?.[1]?.msg || 0;
        r += `\n📍 Tu: #${senderPos + 1} com *${senderCount}* msgs`;
      }

      const totalMsgs = entries.reduce((sum, [, d]) => sum + (d?.messageCount || d?.msg || 0), 0);
      r += `\n\n📈 Total: *${totalMsgs}* mensagens de *${entries.length}* membros`;

      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao obter top: ${e.message}`);
    }
  }
};
