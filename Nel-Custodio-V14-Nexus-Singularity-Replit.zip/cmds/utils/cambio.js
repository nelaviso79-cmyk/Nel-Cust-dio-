import axios from 'axios';

export default {
  command: ['cambio', 'cotacao', 'metical', 'conversor'],
  category: 'utilidades',
  description: 'Ver a cotação atual do Metical (MZN) face a outras moedas.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const response = await axios.get('https://api.exchangerate-api.com/v4/latest/USD');
      const rates = response.data.rates;
      const mzn = rates.MZN;
      const eur = rates.EUR;
      const zar = rates.ZAR;

      // Conversão baseada em 1 USD
      const usdToMzn = mzn.toFixed(2);
      const eurToMzn = (mzn / eur).toFixed(2);
      const zarToMzn = (mzn / zar).toFixed(2);

      let text = `🇲🇿 *CÂMBIO MOÇAMBIQUE (MZN)* 🇲🇿\n\n`;
      text += `💵 1 USD ➔ *${usdToMzn} MT*\n`;
      text += `💶 1 EUR ➔ *${eurToMzn} MT*\n`;
      text += `🇿🇦 1 ZAR ➔ *${zarToMzn} MT*\n\n`;
      
      if (args[0] && !isNaN(args[0])) {
        const valor = parseFloat(args[0]);
        text += `📊 *CONVERSÃO (${valor} USD):*\n`;
        text += `➔ ${(valor * mzn).toFixed(2)} MT\n\n`;
      }

      text += `🕒 Atualizado em: ${new Date().toLocaleDateString('pt-MZ')}\n`;
      text += `_Fonte: ExchangeRate-API_`;

      return msg.reply(text);
    } catch (e) {
      return msg.reply('❌ Erro ao obter as taxas de câmbio. Tente novamente mais tarde.');
    }
  }
};
