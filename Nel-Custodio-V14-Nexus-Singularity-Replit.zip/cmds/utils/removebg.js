import fetch from 'node-fetch';
import axios from 'axios';
import FormData from 'form-data';

export default {
  command: ['removebg', 'removerfundo', 'rmbg', 'nobg'],
  category: 'utilidades',
  description: 'Remover o fundo de uma imagem ✂️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let imageMsg = null;
    if (msg.quoted) {
      const qMsg = msg.quoted.message;
      if (qMsg?.imageMessage) {
        imageMsg = msg.quoted;
      }
    }

    if (!imageMsg) {
      return msg.reply(
        `✂️ *REMOVER FUNDO DE IMAGEM* ✂️\n\n` +
        `▸ Responda a uma imagem para remover o fundo!\n\n` +
        `✏️ *Como usar:*\n` +
        `▸ Responda a uma imagem com: *${usedPrefix + command}*\n\n` +
        `💡 A imagem ficará com fundo transparente (PNG)!`
      );
    }

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: '✂️ A remover o fundo da imagem...' }, { quoted: msg });
      await msg.react('✂️');

      // Baixar a imagem
      const buffer = await sock.downloadMediaMessage(imageMsg);
      if (!buffer) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível baixar a imagem.', edit: key }, { quoted: msg });
      }

      let resultBuffer = null;

      // Método 1: API siputzx - removebg
      try {
        const body = new FormData();
        body.append('image', buffer, 'image.jpg');
        const res = await axios.post('https://api.siputzx.my.id/api/s/removebg', body, {
          headers: body.getHeaders(),
          responseType: 'arraybuffer'
        });
        if (res.data && Buffer.from(res.data).length > 1000) {
          resultBuffer = Buffer.from(res.data);
        }
      } catch {}

      // Método 2: API delirius
      if (!resultBuffer) {
        try {
          const body = new FormData();
          body.append('image', buffer, 'image.jpg');
          const res = await axios.post(`${global.APIs.delirius.url}/tools/removebg`, body, {
            headers: body.getHeaders(),
            responseType: 'arraybuffer'
          });
          if (res.data && Buffer.from(res.data).length > 1000) {
            resultBuffer = Buffer.from(res.data);
          }
        } catch {}
      }

      // Método 3: Upload para Uguu + API
      if (!resultBuffer) {
        try {
          const body = new FormData();
          body.append('files[]', buffer, 'image.jpg');
          const uploadRes = await fetch('https://uguu.se/upload.php', { method: 'POST', body, headers: body.getHeaders() });
          const uploadJson = await uploadRes.json();
          const imageUrl = uploadJson.files?.[0]?.url;
          if (imageUrl) {
            const res = await fetch(`${global.APIs.delirius.url}/tools/removebg?url=${encodeURIComponent(imageUrl)}`);
            if (res.ok) {
              const data = await res.arrayBuffer();
              if (data.byteLength > 1000) resultBuffer = Buffer.from(data);
            }
          }
        } catch {}
      }

      if (!resultBuffer) {
        return sock.sendMessage(msg.chat, {
          text: '❧ Não foi possível remover o fundo. Tente com outra imagem.',
          edit: key
        }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, {
        image: resultBuffer,
        caption: `✂️ *Fundo Removido!*\n\n▸ Formato: PNG (transparente)\n💡 Use *${usedPrefix + command}* para remover mais fundos!`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};
