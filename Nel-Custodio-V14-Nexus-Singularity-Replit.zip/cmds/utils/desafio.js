export default {
  command: ['dare', 'desafios', 'challenge', 'verdadedesafio'],
  category: 'diversao',
  description: 'Desafio - Verdade ou Desafio 😈',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const desafios = [
      'Manda uma mensagem de amor para a última pessoa com quem conversaste!',
      'Faz uma declaração de amor para alguém do grupo!',
      'Envia a tua última foto da galeria!',
      'Liga para a 5ª pessoa da tua lista de contactos e canta!',
      'Escreve "Sou uma galinha" no teu status!',
      'Faz um áudio cantando a tua música favorita!',
      'Envia uma foto tua a fazer cara feia!',
      'Manda "Gostas de mim?" para a primeira pessoa da tua lista!',
      'Troca o teu nome no WhatsApp por "Patinho Feio" por 10 minutos!',
      'Escreve um poema de amor e envia aqui!',
      'Faz uma imitação de um animal em áudio!',
      'Conte um segredo que ninguém sabe!',
      'Bebe um copo de água em 5 segundos e grava!',
      'Faz 10 flexões e manda vídeo!',
      'Manda "Preciso de ti" para o teu crush!',
      'Escreve "Adoro cheirar meus dedos do pé" no teu status!',
      'Diz o teu peso real!',
      'Liga para tua mãe e diz que te casaste!',
      'Faz a dança mais ridícula que consegues!',
      'Começa a contar uma história e deixa alguém continuar!',
      'Fala num idioma inventado por 1 minuto!',
      'Descreve a pessoa à tua direita sem usar o nome dela!',
      'Manda um áudio a rir sem parar por 15 segundos!',
      'Diz 3 qualidades da pessoa que te mandou este comando!'
    ];
    
    const desafio = desafios[Math.floor(Math.random() * desafios.length)];
    
    return msg.reply(
      `😈 *VERDADE OU DESAFIO* 😈\n\n` +
      `▸ *DESAFIO*\n\n` +
      `▸ ${desafio}\n\n` +
      `▸ Usa *${usedPrefix}verdade* para uma verdade!\n\n` +
      `_😈 Nel-Aviso-Bot_`
    );
  }
};
