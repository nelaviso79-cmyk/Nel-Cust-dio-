export default {
  command: ['conselho', 'advice', 'conselhododia'],
  category: 'diversao',
  description: 'Receber um conselho aleatório para a vida.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const conselhos = [
      '🧠 Nunca pares de aprender. O conhecimento é o melhor investimento.',
      '💬 Escuta mais do que falas. Vais aprender muito mais.',
      '⏰ Não adies para amanhã o que podes fazer hoje.',
      '🤝 Trata os outros como gostarias de ser tratado.',
      '💪 Quando caíres, levanta-te mais forte do que antes.',
      '🧘 Tira tempo para ti mesmo. Saúde mental é importante.',
      '💰 Poupa um pouco cada mês. O futuro agradece.',
      '🎯 Define objectivos claros e trabalha para os alcançar.',
      '📚 Lê pelo menos 30 minutos por dia. A mente expande-se.',
      '🌞 Começa cada dia com gratidão e positividade.',
      '🏃 Faz exercício regularmente. O corpo é o teu templo.',
      '🌱 Rodeia-te de pessoas que te fazem crescer.',
      '🎨 Não tenhas medo de ser diferente. A originalidade é poder.',
      '🌊 Aprende a deixar ir o que não podes controlar.',
      '💡 Antes de julgar, tenta entender o ponto de vista do outro.',
      '🔒 Cuida da tua reputação. É o que as pessoas lembram de ti.',
      '🌍 Viaja quando puder. A experiência é a melhor professora.',
      '❤️ Diz "amo-te" para quem amas, antes que seja tarde.',
      '🚫 Não compares a tua vida com a dos outros nas redes sociais.',
      '⭐ Celebra as pequenas vitórias. Elas constroem o caminho.',
      '🦷 Cuida dos teus dentes agora para não chorares depois.',
      '📱 Passa menos tempo no telemóvel e mais com pessoas reais.',
      '🎵 Ouve música que te faça sentir bem. É terapia.',
      '🌅 Acorda cedo e aproveita a manhã. É a parte mais produtiva do dia.',
      '🙏 Sê grato pelo que tens enquanto persegues o que queres.',
    ];
    const conselho = conselhos[Math.floor(Math.random() * conselhos.length)];
    return msg.reply(`❧ *Conselho do Dia*\n\n${conselho}\n\n▸ Use *${usedPrefix + command}* para outro conselho!`);
  },
};
