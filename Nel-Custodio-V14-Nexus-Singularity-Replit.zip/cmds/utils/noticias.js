/**
 * 📰 NOTÍCIAS — Notícias de Moçambique e do mundo
 */
import fetch from 'node-fetch';

export default {
  command: ['noticias', 'news', 'noticia', 'jornal'],
  category: 'utilidades',
  description: 'Ver notícias de Moçambique e do mundo 📰',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const query = args.join(' ').trim() || 'Moçambique';
      let noticias = null;

      // API 1: delirius
      try {
        const res = await fetch(`https://api.delirius.store/search/news?query=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.status && data.result?.length) {
          noticias = data.result.slice(0, 8);
        }
      } catch {}

      // API 2: gnews
      if (!noticias) {
        try {
          const res = await fetch(`https://gnews.io/api/v4/search?q=${encodeURIComponent(query)}&lang=pt&max=8&apikey=demo`);
          const data = await res.json();
          if (data.articles?.length) {
            noticias = data.articles.map(a => ({
              title: a.title,
              description: a.description,
              url: a.url,
              source: a.source?.name || a.source,
              date: a.publishedAt
            }));
          }
        } catch {}
      }

      if (!noticias?.length) {
        return msg.reply(`❌ Não foi possível obter notícias agora. Tente novamente.`);
      }

      let r = `📰 *NOTÍCIAS* — ${query}\n\n`;
      noticias.forEach((n, i) => {
        const titulo = n.title || n.titulo || 'Sem título';
        const desc = (n.description || n.desc || n.content || '').substring(0, 120);
        const fonte = n.source?.name || n.source || n.fonte || '';
        const data = n.date || n.publishedAt || n.data || '';
        r += `${i + 1}. *${titulo}*\n`;
        if (desc) r += `   ${desc}...\n`;
        if (fonte) r += `   📡 ${fonte}`;
        if (data) r += ` · ${new Date(data).toLocaleDateString('pt-BR')}`;
        r += '\n\n';
      });
      r += `🔍 *${usedPrefix}noticias <tema>* para buscar mais`;

      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao buscar notícias.`);
    }
  }
};
