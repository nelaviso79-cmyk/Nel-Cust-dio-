export default {
  command: ['suporte', 'ajudaia', 'duvida'],
  category: 'utilidades',
  description: 'Suporte inteligente via IA para dúvidas Nel Net.',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🤖 *SUPORTE NEL AVISO*\n\nComo posso ajudar hoje? Digite a sua dúvida após o comando.\n\nEx: *${usedPrefix + command} como funciona o mpesa?*`);

    await msg.reply("🤖 *IA a processar a sua dúvida...*");
    
    // Simulação de resposta inteligente baseada no contexto do negócio
    const duvida = text.toLowerCase();
    let resposta = "";

    if (duvida.includes('mpesa') || duvida.includes('pagar')) {
      resposta = "Para pagar via M-Pesa: \n1. Envie o valor para o número no comando *.pagamento*\n2. O bot detecta o comprovativo automaticamente\n3. O seu pacote é activado na hora!";
    } else if (duvida.includes('pacote') || duvida.includes('preço')) {
      resposta = "Temos pacotes desde 5MT (200MB) até 1800MT (71.5GB). Digite *.megas* para ver a tabela completa.";
    } else {
      resposta = "Recebi a sua dúvida! Um humano (Nel Aviso) irá analisar e responder em breve se eu não conseguir ajudar agora. \n\n💡 Dica: Tente ser mais específico sobre M-Pesa, pacotes ou erros.";
    }

    return msg.reply(`🤖 *RESPOSTA DA IA:*\n\n${resposta}`);
  }
};
