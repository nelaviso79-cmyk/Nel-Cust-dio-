export default {
  command: ['calc', 'calculadora', 'calcular'],
  category: 'utilidades',
  description: 'Calculadora: resolve expressões matemáticas simples.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(
        `❧ *Calculadora*\n\n` +
        `✎ Usa o comando com uma expressão matemática:\n` +
        `> *${usedPrefix + command} 2+2*\n` +
        `> *${usedPrefix + command} 100*50/2*\n` +
        `> *${usedPrefix + command} sqrt(144)*\n\n` +
        `▸ Operações: + - * / ^ () sqrt sin cos tan log pi e`
      );
    }
    const expr = args.join(' ').trim();
    // Security: only allow math characters
    if (!/^[0-9+\-*/().^sqrtlncospitaeng ]+$/i.test(expr)) {
      return msg.reply('❧ Expressão inválida! Usa apenas números e operadores matemáticos.');
    }
    try {
      // Replace math functions with Math equivalents
      let safeExpr = expr
        .replace(/sqrt/gi, 'Math.sqrt')
        .replace(/sin/gi, 'Math.sin')
        .replace(/cos/gi, 'Math.cos')
        .replace(/tan/gi, 'Math.tan')
        .replace(/log/gi, 'Math.log')
        .replace(/pi/gi, 'Math.PI')
        .replace(/\^/g, '**');
      // Evaluate safely
      const result = new Function(`return (${safeExpr})`)();
      if (result === Infinity || result === -Infinity) return msg.reply('❧ Resultado: *Infinito* ∞');
      if (isNaN(result)) return msg.reply('❧ Resultado inválido. Verifica a expressão.');
      return msg.reply(`❧ *Calculadora*\n\n▸ Expressão: *${expr}*\n▸ Resultado: *${Number(result.toFixed(8))}*`);
    } catch (e) {
      return msg.reply('❧ Erro na expressão! Verifica se está escrita corretamente.\n✎ Exemplo: *2+2*, *sqrt(144)*, *10^3*');
    }
  },
};
