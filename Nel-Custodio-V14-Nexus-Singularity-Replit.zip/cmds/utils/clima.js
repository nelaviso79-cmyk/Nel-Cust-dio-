export default {
  command: ['clima', 'tempo', 'previsao'],
  category: 'utilidades',
  description: 'Ver a previsão do tempo de qualquer cidade.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ *Previsão do Tempo* 🌤️\n\n✎ Exemplo: *${usedPrefix + command} Maputo*`);
    }

    const city = args.join(' ');
    try {
      const fetch = (await import('node-fetch')).default;
      const url = `https://api.open-meteo.com/v1/forecast?latitude=-25.97&longitude=32.57&current_weather=true&timezone=Africa/Maputo`;
      // Use a geocoding approach - try wttr.in which doesn't need API key
      const response = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
      
      if (!response.ok) throw new Error('Cidade não encontrada');
      const data = await response.json();
      
      const current = data.current_condition?.[0];
      if (!current) throw new Error('Sem dados');
      
      const temp = current.temp_C;
      const feelsLike = current.FeelsLikeC;
      const humidity = current.humidity;
      const desc = current.lang_pt?.[0]?.value || current.weatherDesc?.[0]?.value || 'N/A';
      const wind = current.windspeedKmph;
      const visibility = current.visibility;
      const city_name = data.nearest_area?.[0]?.areaName?.[0]?.value || city;
      const country = data.nearest_area?.[0]?.country?.[0]?.value || '';
      
      const emoji = parseInt(temp) > 30 ? '🔥' : parseInt(temp) > 20 ? '☀️' : parseInt(temp) > 10 ? '🌤️' : '❄️';

      return msg.reply(
        `❧ *Previsão do Tempo* ${emoji}\n\n` +
        `▸ Local: *${city_name}, ${country}*\n` +
        `▸ Temperatura: *${temp}°C*\n` +
        `▸ Sensação: *${feelsLike}°C*\n` +
        `▸ Condição: *${desc}*\n` +
        `▸ Humidade: *${humidity}%*\n` +
        `▸ Vento: *${wind} km/h*\n` +
        `▸ Visibilidade: *${visibility} km*\n\n` +
        `▸ Dados de wttr.in`
      );
    } catch (e) {
      return msg.reply(`❧ Não foi possível obter a previsão para *${city}*.\n▸ Verifica o nome da cidade e tenta novamente.`);
    }
  },
};
