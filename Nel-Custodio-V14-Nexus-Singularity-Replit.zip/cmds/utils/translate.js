import { translate } from '@vitalets/google-translate-api';

export default {
  command: ['translate', 'trad', 'traducir'],
  category: 'utilidades',
  description: 'Traduzir texto para o idioma especificado.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const defaultLang = 'es';
    if (!args[0] && !msg.quoted) {
      return msg.reply('《✧》 Insira el idioma seguido do texto que quieras traducir.');
    }
    let lang = args[0];
    let text = '';
    if (msg.quoted) {
      text = msg.quoted.text || msg.quoted.caption || msg.quoted.body || '';
      if ((lang || '').length === 2 && args[1]) {
        lang = args[0];
        text = args.slice(1).join(' ') || text;
      } else if ((lang || '').length !== 2) {
        lang = defaultLang;
        text = args.join(' ') || text;
      }
    } else {
      if ((lang || '').length === 2) {
        text = args.slice(1).join(' ');
      } else {
        lang = defaultLang;
        text = args.join(' ');
      }
    }
    if (!text.trim()) {
      return msg.reply('《✧》 Não há texto para traducir.');
    }
    try {
      await msg.react('🕒');
      const result = await translate(text, { to: lang, autoCorrect: true });
      await sock.sendMessage(msg.chat, { text: result.text }, { quoted: msg });
      await msg.react('✔️');
    } catch (e) {
      await msg.react('✖️');
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};