/**
 * ╔════════════════════════════════════════════════════════════════════╗
 * ║  🏆 RANKING DE COMPRADORES — Top compradores do grupo             ║
 * ║  Mostra ranking com total acumulado, posição e bónus             ║
 * ╚════════════════════════════════════════════════════════════════════╝
 */

import db from '#db';

function mbToReadable(mb) {
  if (mb >= 1024) return (mb / 1024).toFixed(2) + 'GB';
  return mb + 'MB';
}

function getComprasGrupo(chatId) {
  const chat = db.getChat(chatId) || {};
  return chat.compras || { totalGeral: 0, compradores: {} };
}

function getRanking(chatId, limite = 15) {
  const compras = getComprasGrupo(chatId);
  const entries = Object.entries(compras.compradores || {});
  entries.sort((a, b) => b[1].totalMB - a[1].totalMB);
  return entries.slice(0, limite);
}

const MEDALHAS = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

export default {
  command: ['ranking', 'rank', 'topcompradores', 'maiorcomprador', 'top'],
  category: 'pagamentos',
  description: 'Ver ranking dos maiores compradores do grupo 🏆',
  run: async ({ msg, sock, args, usedPrefix, command, from, sender, pushname, isGroup }) => {
    if (!isGroup) {
      return msg.reply(`⚠️ O ranking só funciona em grupos!`);
    }

    const compras = getComprasGrupo(from);
    const ranking = getRanking(from, 10);
    const totalCompradores = Object.keys(compras.compradores || {}).length;

    if (ranking.length === 0) {
      return msg.reply(
        `┌──「 🏆 *RANKING* 」\n│\n│ 😔 Nenhuma compra registada ainda.\n│\n│ 💡 Use *${usedPrefix}comprar <valorMT>*\n│ para registar compras!\n└───────────────`
      );
    }

    const totalMB = Object.values(compras.compradores).reduce((acc, c) => acc + c.totalMB, 0);
    const totalMT = Object.values(compras.compradores).reduce((acc, c) => acc + c.totalMT, 0);

    let r = `┌──「 🏆 *RANKING DE COMPRADORES* 」\n│\n`;
    r += `│ 👥 Compradores: *${totalCompradores}*\n`;
    r += `│ 💰 Total movimentado: *${totalMT.toFixed(0)} MT*\n`;
    r += `│ 📊 Total de dados: *${mbToReadable(totalMB)}*\n`;
    r += `│\n│ ────── *TOP ${ranking.length}* ──────\n│\n`;

    for (let i = 0; i < ranking.length; i++) {
      const [phone, data] = ranking[i];
      const medalha = MEDALHAS[i] || `${i + 1}º`;
      const nome = data.nome || phone;
      const totalReadable = mbToReadable(data.totalMB);
      const comprasHoje = data.comprasHoje || 0;

      let linha = `│ ${medalha} *${nome}*\n`;
      linha += `│    📊 ${totalReadable} · 🛒 ${data.totalCompras}x · 💵 ${data.totalMT.toFixed(0)}MT`;
      if (comprasHoje > 0) linha += ` · 🔄 ${comprasHoje} hoje`;
      linha += `\n`;

      // Bónus especiais
      if (i === 0) linha += `│    👑 *LÍDER* — Bônus: +50MB/compra\n`;
      else if (i === 1) linha += `│    🥈 *VICE* — Bônus: +25MB/compra\n`;
      else if (i === 2) linha += `│    🥉 *TOP 3* — Bônus: +10MB/compra\n`;

      r += linha + `│\n`;
    }

    // Posição do remetente
    const senderPhone = sender.split('@')[0];
    const senderData = compras.compradores[senderPhone];
    if (senderData) {
      const allSorted = Object.entries(compras.compradores).sort((a, b) => b[1].totalMB - a[1].totalMB);
      const senderPos = allSorted.findIndex(([p]) => p === senderPhone) + 1;
      if (senderPos > 3) {
        r += `│ ─────────────────\n`;
        r += `│ 📍 *Tua posição:* nº ${senderPos}\n`;
        r += `│ 📊 Teu total: *${mbToReadable(senderData.totalMB)}*\n`;
        r += `│ 💡 Compra mais para subir no ranking!\n│\n`;
      }
    }

    r += `└───────────────\n💡 *${usedPrefix}minhascompras* para ver teu histórico`;

    // Mencionar top 3
    const mentions = ranking.slice(0, 3).map(([phone]) => phone + '@s.whatsapp.net');
    return sock.sendMessage(msg.chat, { text: r, mentions }, { quoted: msg });
  }
};
