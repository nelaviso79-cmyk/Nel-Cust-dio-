/**
 * 📩 RASTREAR — Rastrear encomenda/pacote
 */
import fetch from 'node-fetch';

export default {
  command: ['rastrear', 'track', 'rastreio', 'encomenda'],
  category: 'utilidades',
  description: 'Rastrear encomenda por código 📩',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const code = args[0]?.trim();
    if (!code) return msg.reply(`❌ Use: *${usedPrefix}${command} <código>*\nEx: *${usedPrefix}rastrear NL123456789BR*`);

    try {
      let tracking = null;

      // API 1: delirius
      try {
        const res = await fetch(`https://api.delirius.store/other/correios?code=${encodeURIComponent(code)}`);
        const data = await res.json();
        if (data.status && data.result) tracking = data.result;
      } catch {}

      if (!tracking) {
        return msg.reply(`❌ Não foi possível rastrear "${code}". Verifique o código e tente novamente.`);
      }

      let r = `📩 *RASTREIO* 📩\n\n`;
      r += `📦 Código: *${code}*\n\n`;

      if (Array.isArray(tracking)) {
        tracking.forEach((event, i) => {
          const status = event.status || event.estado || event.type || '';
          const local = event.local || event.location || event.city || '';
          const data = event.date || event.data || event.when || '';
          const detalhe = event.detail || event.detalhes || '';
          r += `${i === 0 ? '📍' : '  '} *${status}*\n`;
          if (local) r += `   🏬 ${local}\n`;
          if (data) r += `   📅 ${data}\n`;
          if (detalhe) r += `   📝 ${detalhe}\n`;
          r += '\n';
        });
      } else if (typeof tracking === 'object') {
        for (const [k, v] of Object.entries(tracking)) {
          r += `• ${k}: ${v}\n`;
        }
      }

      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao rastrear encomenda.`);
    }
  }
};
