import fs from 'fs';
import { spawn } from 'child_process';

export default {
  command: ['autofig', 'autosticker', 'figurinha', 'fig'],
  category: 'utilidades',
  description: 'Converter imagem para sticker automaticamente (sem opções) 🖼️➡️🎭',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime) && !/video/.test(mime)) {
      return msg.reply(`◈ Envie ou responda a uma *imagem/vídeo* com:\n${usedPrefix + command}\n\n✎ O sticker será criado automaticamente!`);
    }
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const isVideo = /video/.test(mime);
      const inputPath = `./tmp/autofig_${Date.now()}.${isVideo ? 'mp4' : 'jpg'}`;
      const outputPath = `./tmp/autofig_out_${Date.now()}.webp`;
      fs.writeFileSync(inputPath, buffer);
      
      const vf = 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba';
      
      if (isVideo) {
        if ((quoted.msg || quoted).seconds > 15) {
          fs.unlinkSync(inputPath);
          return msg.reply('◈ O vídeo não pode durar mais de 15 segundos!');
        }
        await new Promise((resolve, reject) => {
          const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', 'fps=10,' + vf, '-an', '-c:v', 'libwebp_anim', '-preset', 'picture', '-compression_level', '6', '-q:v', '70', '-loop', '0', outputPath]);
          let err = '';
          proc.stderr.on('data', d => err += d.toString());
          proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
        });
      } else {
        await new Promise((resolve, reject) => {
          const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', vf, '-c:v', 'libwebp', '-preset', 'picture', '-compression_level', '6', '-q:v', '80', outputPath]);
          let err = '';
          proc.stderr.on('data', d => err += d.toString());
          proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
        });
      }
      
      const stickerBuffer = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { sticker: stickerBuffer }, { quoted: msg });
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro ao criar sticker: ${e.message}`);
    }
  }
};
