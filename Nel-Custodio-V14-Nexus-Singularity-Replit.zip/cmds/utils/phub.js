export default {
  command: ['phub', 'fakephub', 'phcomment'],
  category: 'diversao',
  description: 'Cria um comentário fativo estilo PornHub',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} username|comentário*\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Este bot é incrível!`);

    const parts = text.split('|');
    const username = parts[0]?.trim() || 'User';
    const commentText = parts.slice(1).join('|').trim();

    if (!commentText) return msg.reply(`❌ Forneça o comentário!\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Este bot é incrível!`);

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/phub?username=${encodeURIComponent(username)}&text=${encodeURIComponent(commentText)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `💬 *Fake PH Comment*\n👤 @${username}\n💬 ${commentText}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar comentário: ${e.message}`);
    }
  }
};
