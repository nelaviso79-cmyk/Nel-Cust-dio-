/**
 * 🆔 FAKEINFO — Gerador de identidade fictícia
 */
import fetch from 'node-fetch';

export default {
  command: ['fakeinfo', 'fakeid', 'identidadefake', 'fakeidentity', 'fake'],
  category: 'utilidades',
  description: 'Gerar identidade fictícia para testes 🆔',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      let fake = null;

      // API 1: delirius
      try {
        const res = await fetch('https://api.delirius.store/other/fakeidentity');
        const data = await res.json();
        if (data.status && data.result) fake = data.result;
      } catch {}

      // API 2: randomuser
      if (!fake) {
        try {
          const res = await fetch('https://randomuser.me/api/?nat=BR,PT');
          const data = await res.json();
          const u = data.results?.[0];
          if (u) {
            fake = {
              name: `${u.name.first} ${u.name.last}`,
              gender: u.gender === 'male' ? 'Masculino' : 'Feminino',
              birthday: u.dob.date?.split('T')[0],
              address: `${u.location.street.name}, ${u.location.street.number}`,
              city: u.location.city,
              state: u.location.state,
              country: u.location.country,
              zip: u.location.postcode,
              email: u.email,
              phone: u.phone,
              username: u.login.username,
              password: u.login.password,
              picture: u.picture?.large
            };
          }
        } catch {}
      }

      if (!fake) return msg.reply(`❌ Não foi possível gerar identidade.`);

      let r = `🆔 *IDENTIDADE FICTÍCIA*\n`;
      r += `⚠️ Apenas para testes!\n\n`;
      r += `👤 Nome: ${fake.name || fake.nome || '—'}\n`;
      r += `🧬 Género: ${fake.gender || fake.genero || '—'}\n`;
      r += `📅 Nascimento: ${fake.birthday || fake.data_nascimento || '—'}\n`;
      r += `📍 Endereço: ${fake.address || fake.endereco || '—'}\n`;
      r += `🏙️ Cidade: ${fake.city || fake.cidade || '—'}\n`;
      r += `🗺️ Estado: ${fake.state || fake.estado || '—'}\n`;
      r += `🌍 País: ${fake.country || fake.pais || '—'}\n`;
      r += `📮 CEP: ${fake.zip || fake.cep || '—'}\n`;
      r += `📧 Email: ${fake.email || '—'}\n`;
      r += `📱 Telefone: ${fake.phone || fake.telefone || '—'}\n`;
      r += `🔑 User: ${fake.username || '—'}\n`;
      r += `🔒 Senha: ${fake.password || fake.senha || '—'}\n\n`;
      r += `⚠️ _Dados 100% fictícios. Não use para fins ilegais!_`;

      await msg.reply(r);
    } catch (e) {
      msg.reply(`❌ Erro ao gerar identidade.`);
    }
  }
};
