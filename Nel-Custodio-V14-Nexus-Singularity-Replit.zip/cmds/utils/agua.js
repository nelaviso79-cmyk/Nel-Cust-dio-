export default {
  command: ['agua', 'beberagua', 'lembreteagua'],
  category: 'utilidades',
  description: 'Lembrete programável para beber água 💧',
  run: async ({ msg, sock, args, usedPrefix, command, sender }) => {
    if (!args.length) {
      return msg.reply(
        `💧 *HIDRATAÇÃO NEXUS* 💧\n\n` +
        `Defina um lembrete para beber água e manter o seu corpo saudável.\n\n` +
        `▸ *Uso:* ${usedPrefix + command} <minutos>\n` +
        `▸ *Exemplo:* ${usedPrefix + command} 60 (avisa daqui a 1 hora)\n\n` +
        `_A hidratação é essencial para a performance cerebral!_ 🧠`
      );
    }

    const minutos = parseInt(args[0]);
    if (isNaN(minutos) || minutos <= 0) return msg.reply(`❌ Insira um tempo válido em minutos.`);
    if (minutos > 1440) return msg.reply(`❌ O tempo máximo é de 24 horas (1440 minutos).`);

    await msg.reply(`✅ Lembrete de hidratação definido para daqui a *${minutos} minutos*! 💧`);

    setTimeout(async () => {
      try {
        await sock.sendMessage(msg.chat, {
          text: `💧 *HORA DE BEBER ÁGUA!* 💧\n\n▸ @${sender.split('@')[0]}, a sua saúde é prioridade.\n▸ Beba um copo de água agora para manter a sua alta performance!\n\n_Nexus Health Intelligence_ 🛡️`,
          mentions: [sender]
        });
      } catch (e) {
        console.error('Erro no lembrete de água:', e);
      }
    }, minutos * 60 * 1000);
  }
};
