export default {
  command: ['vote', 'votacao', 'votação'],
  category: 'diversao',
  description: 'Criar uma votação no grupo. Todos podem votar.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(
        `❧ *Votação no Grupo*\n\n` +
        `✎ Como usar:\n` +
        `> *${usedPrefix + command} pergunta | opção1 | opção2 | opção3*\n\n` +
        `▸ Exemplo: *${usedPrefix + vote} Melhor comida? | Matapa | Xima | Frango*`
      );
    }
    const parts = args.join(' ').split('|').map(p => p.trim()).filter(Boolean);
    if (parts.length < 3) {
      return msg.reply(`❧ Precisas de pelo menos uma pergunta e 2 opções.\n✎ Exemplo: *${usedPrefix + command} Melhor comida? | Matapa | Xima*`);
    }

    const question = parts[0];
    const options = parts.slice(1);
    if (options.length > 10) return msg.reply('❧ Máximo de 10 opções na votação.');

    let text = `❧ *VOTAÇÃO* 🗳️\n\n▸ Pergunta: *${question}*\n\n`;
    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
    options.forEach((opt, i) => {
      text += `${emojis[i]} *${opt}*\n`;
    });
    text += `\n▸ Reaja com o emoji correspondente para votar!`;

    const sent = await sock.sendMessage(msg.chat, { text }, { quoted: msg });
    // Send reactions for voting
    for (let i = 0; i < options.length; i++) {
      try {
        await sock.sendMessage(msg.chat, { react: { key: sent.key, text: `${i + 1}️⃣` } });
      } catch (e) { }
    }
  },
};
