export default {
  command: ['farmacia', 'farmacias', 'saude'],
  category: 'utilidades',
  description: 'Informações sobre farmácias e saúde em Moçambique.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let text = `🏥 *FARMÁCIAS E SAÚDE - MOÇAMBIQUE* 🏥\n\n`;
    text += `Para encontrar a farmácia de serviço mais próxima, pode consultar os seguintes recursos:\n\n`;
    text += `🌐 *Portal de Saúde:* www.misau.gov.mz\n`;
    text += `📱 *Linha de Saúde:* 110 (Grátis)\n\n`;
    text += `💡 *Dica:* Em Maputo e outras capitais provinciais, as farmácias de serviço mudam semanalmente. Verifique os editais nas portas das farmácias ou nos jornais locais.\n\n`;
    text += `🚨 *Números Úteis:* \n`;
    text += `▸ Ambulância: 117\n`;
    text += `▸ Cruz Vermelha: 21 497 111\n\n`;
    text += `_🇲🇿 Nel-Aviso-Bot-Moz_ `;
    
    return msg.reply(text);
  }
};
