// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/wattpad.js
//   Wattpad — Busca de histórias no Wattpad
// ╚══════════════════════════════════════════════════════════════╝

export const command = {
  name: 'wattpad',
  aliases: ['historia', 'story', 'wattpadsearch', 'fanfic', 'contos'],
  description: 'Busca histórias no Wattpad (fanfics, contos, romances)',
  category: 'utilidades',
  usage: '.wattpad <tema ou título>',
  example: '.wattpad romance vampires'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o que queres buscar!\n\n💡 *Uso:* .wattpad <tema>\n📌 *Ex:* .wattpad romance vampires'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '📚', key: msg.key } });

  try {
    // Delirius Search — /search/wattpad
    const res = await fetch(`https://api.delirius.store/search/wattpad?query=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const results = data.result.slice(0, 3);
      let text = `📚 *WATTPAD* — "${query}"\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;

      for (let i = 0; i < results.length; i++) {
        const s = results[i];
        text += `${i === 0 ? '📖' : '📕'} *${s.title || 'Sem título'}*\n`;
        if (s.author || s.user) text += `  ✍️ Autor: ${s.author || s.user}\n`;
        if (s.reads || s.readCount) text += `  👁️ Leitura: ${(s.reads || s.readCount).toLocaleString()}\n`;
        if (s.votes || s.voteCount) text += `  👍 Votos: ${(s.votes || s.voteCount).toLocaleString()}\n`;
        if (s.chapters || s.chapterCount) text += `  📄 Capítulos: ${s.chapters || s.chapterCount}\n`;
        if (s.genre || s.categories) text += `  🏷️ ${s.genre || s.categories}\n`;
        if (s.description) text += `  💬 ${s.description.substring(0, 200)}${s.description.length > 200 ? '...' : ''}\n`;
        if (s.url || s.link) text += `  🔗 ${s.url || s.link}\n`;
        text += '\n';
      }

      await sock.sendMessage(from, {
        text: text.trim(),
        contextInfo: {
          externalAdReply: {
            title: 'Wattpad Search',
            body: `"${query}" — ${data.result.length} resultados`,
            thumbnailUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Wattpad_logo.svg/1200px-Wattpad_logo.svg.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Wattpad primary failed:', e.message);
  }

  // Fallback — Google search
  try {
    const res = await fetch(`https://api.delirius.store/search/google?query=${encodeURIComponent(query + ' site:wattpad.com')}`);
    const data = await res.json();

    if (data?.status === 200 && data?.result && data.result.length > 0) {
      const results = data.result.slice(0, 3);
      let text = `📚 *WATTPAD* — "${query}"\n_(Resultados via Google)_\n\n`;

      for (const r of results) {
        text += `📖 *${r.title}*\n🔗 ${r.url}\n📝 ${r.description || 'Sem descrição'}\n\n`;
      }

      await sock.sendMessage(from, { text: text.trim() }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Wattpad fallback failed:', e.message);
  }

  await sock.sendMessage(from, {
    text: `❌ Não encontrei histórias sobre "${query}" no Wattpad.`
  }, { quoted: msg });
}
