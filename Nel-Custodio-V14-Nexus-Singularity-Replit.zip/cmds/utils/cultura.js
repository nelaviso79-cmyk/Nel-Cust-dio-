/**
 * 🇲🇿 CULTURA DE MOÇAMBIQUE — Informações culturais, artistas e tradições
 */

export default {
  command: ['cultura', 'artistas', 'tradições', 'mozcultura'],
  category: 'utilidades',
  description: 'Informações sobre a cultura e artistas de Moçambique 🇲🇿',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const cultura = {
      'musica': {
        titulo: '🎵 MÚSICA E DANÇA',
        info: 'A música moçambicana é rica e diversa. A *Marrabenta* é o género mais icónico de Maputo. No norte, destaca-se a *Timbila* dos Chopes (Património da UNESCO).',
        artistas: 'Mr. Bow, Lizha James, Azagaia, Stewart Sukuma, Ghorwane, Ziqo, Neyma, Messias Maricoa, Shellsy Baronet.'
      },
      'literatura': {
        titulo: '📚 LITERATURA',
        info: 'Moçambique tem uma das literaturas mais vibrantes de África, com foco na resistência e identidade.',
        artistas: 'José Craveirinha (Prémio Camões), Mia Couto, Paulina Chiziane (Prémio Camões), Noémia de Sousa, Ungulani Ba Ka Khosa.'
      },
      'artes': {
        titulo: '🎨 ARTES PLÁSTICAS',
        info: 'O artesanato Makonde (escultura em pau-preto) é mundialmente famoso pela sua complexidade.',
        artistas: 'Malangatana Valente Ngwenya (pintor icónico), Reinata Sadimba, Alberto Chissano (escultor).'
      },
      'gastronomia': {
        titulo: '🍲 GASTRONOMIA',
        info: 'A culinária moçambicana mistura influências africanas, portuguesas e árabes.',
        pratos: 'Matapa (folhas de mandioquinha com amendoim e coco), Xima, Frango à Cafreal, Camarão da Beira, Badjias.'
      }
    };

    if (text) {
      const query = text.toLowerCase();
      let found = null;
      if (query.includes('musica') || query.includes('artista')) found = cultura.musica;
      else if (query.includes('livro') || query.includes('escr')) found = cultura.literatura;
      else if (query.includes('arte') || query.includes('pint')) found = cultura.artes;
      else if (query.includes('comida') || query.includes('prato')) found = cultura.gastronomia;

      if (found) {
        let r = `🇲🇿 *${found.titulo}* 🇲🇿\n\n`;
        r += `📝 *Info:* ${found.info}\n\n`;
        if (found.artistas) r += `🌟 *Destaques:* ${found.artistas}\n`;
        if (found.pratos) r += `🍽️ *Pratos Típicos:* ${found.pratos}\n`;
        r += `\n_🇲🇿 Nel-Aviso-Bot-Moz_`;
        return msg.reply(r);
      }
    }

    let result = `🇲🇿 *CULTURA DE MOÇAMBIQUE* 🇲🇿\n\n`;
    result += `Escolha um tema para saber mais:\n\n`;
    result += `▸ *${usedPrefix + command} musica* — Música e Artistas\n`;
    result += `▸ *${usedPrefix + command} literatura* — Escritores e Livros\n`;
    result += `▸ *${usedPrefix + command} artes* — Pintura e Escultura\n`;
    result += `▸ *${usedPrefix + command} gastronomia* — Comida Típica\n\n`;
    result += `💡 Sabia que a *Timbila* é considerada Património Oral e Imaterial da Humanidade?\n\n`;
    result += `_🇲🇿 Nel-Aviso-Bot-Moz_`;

    await msg.reply(result);
  }
};
