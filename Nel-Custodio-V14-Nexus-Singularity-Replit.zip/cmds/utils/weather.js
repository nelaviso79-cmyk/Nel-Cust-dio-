import fetch from 'node-fetch';

export default {
  command: ['clima2', 'weather', 'tempo2', 'previsao'],
  category: 'utilidades',
  description: 'Previsão do tempo para qualquer cidade do mundo 🌤️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const city = args.join(' ').trim();
    if (!city) {
      return msg.reply(
        `🌤️ *PREVISÃO DO TEMPO*\n\n` +
        `▸ Escreva o nome da cidade!\n\n` +
        `✏️ *Exemplos:*\n` +
        `▸ *${usedPrefix + command} Maputo*\n` +
        `▸ *${usedPrefix + command} São Paulo*\n` +
        `▸ *${usedPrefix + command} Lisboa*\n` +
        `▸ *${usedPrefix + command} New York*`
      );
    }

    try {
      await msg.react('🌤️');
      let weatherData = null;

      // Método 1: wttr.in (gratuito, sem API key)
      try {
        const res = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`, {
          headers: { 'User-Agent': 'curl/7.68.0' }
        });
        if (res.ok) {
          const json = await res.json();
          const current = json.current_condition?.[0];
          const area = json.nearest_area?.[0];
          if (current) {
            weatherData = {
              city: area?.areaName?.[0]?.value || city,
              country: area?.country?.[0]?.value || 'N/A',
              region: area?.region?.[0]?.value || '',
              temp: current.temp_C + '°C',
              feelsLike: current.FeelsLikeC + '°C',
              humidity: current.humidity + '%',
              wind: current.windspeedKmph + ' km/h',
              windDir: current.winddir16Point || '',
              visibility: current.visibility + ' km',
              pressure: current.pressure + ' hPa',
              cloudCover: current.cloudcover + '%',
              uvIndex: current.uvIndex || 'N/A',
              description: current.weatherDesc?.[0]?.value || 'N/A',
              precipitation: current.precipMM + ' mm',
              observationTime: current.observation_time || 'N/A',
              forecast: json.weather?.slice(0, 3).map(w => ({
                date: w.date,
                maxTemp: w.maxtempC + '°C',
                minTemp: w.mintempC + '°C',
                desc: w.hourly?.[4]?.weatherDesc?.[0]?.value || 'N/A'
              })) || []
            };
          }
        }
      } catch {}

      // Método 2: API delirius
      if (!weatherData) {
        try {
          const res = await fetch(`${global.APIs.delirius.url}/tools/clima?city=${encodeURIComponent(city)}`);
          const json = await res.json();
          if (json?.status && json?.data) {
            const d = json.data;
            weatherData = {
              city: d.city || city,
              country: d.country || 'N/A',
              temp: d.temperature || 'N/A',
              humidity: d.humidity || 'N/A',
              wind: d.wind || 'N/A',
              description: d.description || d.climate || 'N/A',
              forecast: []
            };
          }
        } catch {}
      }

      if (!weatherData) {
        return msg.reply(`❧ Não foi possível obter a previsão para *${city}*.`);
      }

      const weatherEmoji = getWeatherEmoji(weatherData.description);

      let forecastText = '';
      if (weatherData.forecast.length > 0) {
        forecastText = `\n\n📅 *Previsão:*\n${weatherData.forecast.map(f =>
          `▸ ${f.date}: ${f.desc} ${f.minTemp}-${f.maxTemp}`
        ).join('\n')}`;
      }

      const result = `
${weatherEmoji} *TEMPO EM ${weatherData.city.toUpperCase()}* ${weatherEmoji}

📍 *Localização:*
▸ Cidade: *${weatherData.city}*
▸ País: *${weatherData.country}*
${weatherData.region ? `▸ Região: *${weatherData.region}*\n` : ''}
🌡️ *Condições Actuais:*
▸ Temperatura: *${weatherData.temp}*
▸ Sensação: *${weatherData.feelsLike || 'N/A'}*
▸ Descrição: *${weatherData.description}*
▸ Humidade: *${weatherData.humidity}*
▸ Vento: *${weatherData.wind}${weatherData.windDir ? ' ' + weatherData.windDir : ''}*
▸ Visibilidade: *${weatherData.visibility || 'N/A'}*
▸ Pressão: *${weatherData.pressure || 'N/A'}*
▸ Nuvens: *${weatherData.cloudCover || 'N/A'}*
▸ UV: *${weatherData.uvIndex || 'N/A'}*
▸ Precipitação: *${weatherData.precipitation || 'N/A'}*
▸ Observado: *${weatherData.observationTime || 'N/A'}*${forecastText}
`.trim();

      await msg.reply(result);
    } catch (e) {
      await msg.reply(`> Erro ao obter clima: *${e.message}*`);
    }
  },
};

function getWeatherEmoji(desc) {
  const d = (desc || '').toLowerCase();
  if (/sol|sunny|clear|limpo/.test(d)) return '☀️';
  if (/nuvem|cloud|nublado/.test(d)) return '☁️';
  if (/chuva|rain/.test(d)) return '🌧️';
  if (/trovoada|thunder|storm/.test(d)) return '⛈️';
  if (/neve|snow/.test(d)) return '❄️';
  if (/nevoeiro|fog|mist/.test(d)) return '🌫️';
  if (/vento|wind/.test(d)) return '💨';
  if (/parcial|partial|partly/.test(d)) return '⛅';
  return '🌤️';
}
