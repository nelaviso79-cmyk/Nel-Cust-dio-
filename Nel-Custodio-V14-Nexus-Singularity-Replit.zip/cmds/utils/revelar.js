export default {
  command: ['revelar', 'reveal', 'descobrir'],
  category: 'diversao',
  description: 'Revelar posições no jogo de memória 🧠',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    global._memoria = global._memoria || {};
    const jogo = global._memoria[msg.sender];

    if (!jogo) {
      return msg.reply(`◈ Nenhum jogo ativo! Use *${usedPrefix}memoria* para começar.`);
    }

    if (args.length < 2) {
      return msg.reply(`◈ Escolha 2 posições para revelar!\n\n✎ Exemplo: *${usedPrefix + command} 1 2*`);
    }

    const pos1 = parseInt(args[0]) - 1;
    const pos2 = parseInt(args[1]) - 1;

    if (isNaN(pos1) || isNaN(pos2) || pos1 < 0 || pos2 < 0 || pos1 >= jogo.pares.length || pos2 >= jogo.pares.length) {
      return msg.reply(`◈ Posições inválidas! Use 1 a ${jogo.pares.length}`);
    }

    if (pos1 === pos2) return msg.reply('◈ Escolha posições diferentes!');

    const emoji1 = jogo.pares[pos1];
    const emoji2 = jogo.pares[pos2];

    if (emoji1 === emoji2) {
      // Acertou!
      jogo.revelados[pos1] = true;
      jogo.revelados[pos2] = true;

      // Mostrar tabuleiro
      let grid = '';
      const cols = 4;
      for (let i = 0; i < jogo.pares.length; i++) {
        if (i % cols === 0 && i > 0) grid += '\n';
        grid += `│${jogo.revelados[i] ? jogo.pares[i] : '❓'}│`;
      }

      const todosRevelados = jogo.revelados.every(r => r);
      if (todosRevelados) {
        delete global._memoria[msg.sender];
        return msg.reply(
          `🧠 *MEMÓRIA* 🧠\n\n${grid}\n\n` +
          `🎉 *PARABÉNS! Encontrou todos os pares!* 🎉\n\n` +
          `_🧠 Nel-Aviso-Bot-Moz_`
        );
      }

      return msg.reply(
        `🧠 *MEMÓRIA* 🧠\n\n${grid}\n\n` +
        `✅ Par encontrado: *${emoji1}*\n` +
        `▸ Continue! *${usedPrefix + command} pos1 pos2*\n\n` +
        `_🧠 Nel-Aviso-Bot-Moz_`
      );
    } else {
      // Errou
      jogo.tentativas--;
      let grid = '';
      const cols = 4;
      for (let i = 0; i < jogo.pares.length; i++) {
        if (i % cols === 0 && i > 0) grid += '\n';
        if (i === pos1 || i === pos2) {
          grid += `│${jogo.pares[i]}│`;
        } else {
          grid += `│${jogo.revelados[i] ? jogo.pares[i] : '❓'}│`;
        }
      }

      if (jogo.tentativas <= 0) {
        // Mostrar tudo
        let gridFinal = '';
        for (let i = 0; i < jogo.pares.length; i++) {
          if (i % cols === 0 && i > 0) gridFinal += '\n';
          gridFinal += `│${jogo.pares[i]}│`;
        }
        delete global._memoria[msg.sender];
        return msg.reply(
          `🧠 *MEMÓRIA* 🧠\n\n${grid}\n\n` +
          `❌ Não era par: *${emoji1}* ≠ *${emoji2}*\n\n` +
          `💀 *GAME OVER!* Sem tentativas!\n\n` +
          `Respostas:\n${gridFinal}\n\n` +
          `_🧠 Nel-Aviso-Bot-Moz_`
        );
      }

      return msg.reply(
        `🧠 *MEMÓRIA* 🧠\n\n${grid}\n\n` +
        `❌ Não era par: *${emoji1}* ≠ *${emoji2}*\n` +
        `▸ Tentativas restantes: *${jogo.tentativas}*\n` +
        `▸ Tente novamente: *${usedPrefix + command} pos1 pos2*\n\n` +
        `_🧠 Nel-Aviso-Bot-Moz_`
      );
    }
  }
};
