/**
 * 🔊 TTS — Texto para Voz (múltiplas línguas)
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['tts', 'voz', 'textovoz', 'falar', 'voztexto'],
  category: 'utilidades',
  description: 'Converter texto em voz 🔊',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    // Tenta detectar língua no início: .tts pt Olá mundo / .tts en Hello world
    let lang = 'pt';
    let text = args.join(' ').trim();

    if (args[0]?.length === 2 && !/^\d/.test(args[0])) {
      lang = args[0].toLowerCase();
      text = args.slice(1).join(' ').trim();
    }

    if (!text) {
      return msg.reply(`❌ Use: *${usedPrefix}${command} [idioma] <texto>*\n\nIdiomas: pt, en, es, fr, de, it, ja, ko, zh, ru, ar, id\nEx: *${usedPrefix}tts pt Olá, como estás?*\nEx: *${usedPrefix}tts en Hello world*`);
    }

    if (text.length > 500) text = text.substring(0, 500);

    try {
      const tmpFile = `./tmp/tts_${Date.now()}.mp3`;
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });

      let audioBuffer = null;

      // API 1: Google TTS
      try {
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(text)}`;
        const res = await fetch(url, {
          headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        if (res.ok) {
          const buf = await res.buffer();
          if (buf.length > 1000) audioBuffer = buf;
        }
      } catch {}

      // API 2: delirius TTS
      if (!audioBuffer) {
        try {
          const url = `https://api.delirius.store/other/tts?text=${encodeURIComponent(text)}&lang=${lang}`;
          const res = await fetch(url);
          if (res.ok) {
            const buf = await res.buffer();
            if (buf.length > 1000) audioBuffer = buf;
          }
        } catch {}
      }

      if (audioBuffer) {
        fs.writeFileSync(tmpFile, audioBuffer);
        await sock.sendMessage(msg.chat, {
          audio: { url: tmpFile },
          mimetype: 'audio/mpeg',
          ptt: true
        }, { quoted: msg });

        setTimeout(() => {
          try { fs.unlinkSync(tmpFile); } catch {}
        }, 5000);
      } else {
        msg.reply(`❌ Não foi possível gerar o áudio. Tente texto mais curto ou outro idioma.`);
      }
    } catch (e) {
      msg.reply(`❌ Erro ao gerar voz: ${e.message}`);
    }
  }
};
