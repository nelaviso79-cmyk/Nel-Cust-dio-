/**
 * 😤 INSULTAR — Gerador de insultos cómicos
 */
import fetch from 'node-fetch';

export default {
  command: ['insultar', 'insulto', 'xingar', 'ofender', 'roast'],
  category: 'diversao',
  description: 'Gerar insulto cómico 😤',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const target = msg.mentionedJid?.[0] || null;
    const nome = target ? `@${target.split('@')[0]}` : 'alguém';

    try {
      let insulto = null;

      // API 1: evilinsult
      try {
        const res = await fetch('https://evilinsult.com/generate_insult.php?lang=pt&type=json');
        const data = await res.json();
        if (data.insult) insulto = data.insult;
      } catch {}

      // API 2: delirius
      if (!insulto) {
        try {
          const res = await fetch('https://api.delirius.store/other/insult');
          const data = await res.json();
          if (data.status && data.result?.insult) insulto = data.result.insult;
        } catch {}
      }

      if (!insulto) insulto = 'O teu cérebro deve estar de férias permanentes! 🤡';

      let r = `😤 *INSULTO* 😤\n\n`;
      r += `${target ? `🎯 ${nome}, ` : ''}${insulto}\n\n`;
      r += `_⚠️ Apenas brincadeira! Não leve a mal_ 🤣`;

      await sock.sendMessage(msg.chat, {
        text: r,
        mentions: target ? [target] : []
      }, { quoted: msg });
    } catch (e) {
      msg.reply(`😤 O teu Wi-Fi tem mais estabilidade que a tua cara! 🤣\n\n_(Apenas brincadeira!)_`);
    }
  }
};
