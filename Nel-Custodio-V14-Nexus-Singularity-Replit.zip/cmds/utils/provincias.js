export default {
  command: ['provincias', 'moz', 'moçambique', 'mapaprovincia', 'regioes'],
  category: 'utilidades',
  description: 'Informações sobre as províncias de Moçambique 🇲🇿',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const provincias = {
      'Niassa': { capital: 'Lichinga', area: '129,056 km²', populacao: '~2.0M', pontos: 'Reserva do Niassa, Lago Niassa', curiosidade: 'Província mais extensa e menos povoada.' },
      'Cabo Delgado': { capital: 'Pemba', area: '82,625 km²', populacao: '~2.5M', pontos: 'Arquipélago das Quirimbas, Praia de Wimbe', curiosidade: 'Famosa pelo artesanato Makonde.' },
      'Nampula': { capital: 'Nampula', area: '81,606 km²', populacao: '~6.5M', pontos: 'Ilha de Moçambique (UNESCO), Praia de Chocas', curiosidade: 'Conhecida como a capital do Norte.' },
      'Zambézia': { capital: 'Quelimane', area: '105,708 km²', populacao: '~5.5M', pontos: 'Gurué (chá), Praia de Zalala', curiosidade: 'Segunda província mais populosa.' },
      'Tete': { capital: 'Tete', area: '100,724 km²', populacao: '~2.9M', pontos: 'Albufeira de Cahora Bassa, Ponte Samora Machel', curiosidade: 'Centro da mineração de carvão.' },
      'Manica': { capital: 'Chimoio', area: '62,272 km²', populacao: '~2.1M', pontos: 'Cabeça do Velho, Monte Binga', curiosidade: 'Faz fronteira com o Zimbabué.' },
      'Sofala': { capital: 'Beira', area: '68,018 km²', populacao: '~2.5M', pontos: 'Parque Nacional da Gorongosa, Praia do Savane', curiosidade: 'A Beira é a segunda maior cidade.' },
      'Inhambane': { capital: 'Inhambane', area: '68,615 km²', populacao: '~1.6M', pontos: 'Praia do Tofo, Arquipélago de Bazaruto', curiosidade: 'Terra da Boa Gente.' },
      'Gaza': { capital: 'Xai-Xai', area: '75,334 km²', populacao: '~1.5M', pontos: 'Parque Nacional do Limpopo, Praia de Bilene', curiosidade: 'Famosa pelo gado e agricultura.' },
      'Maputo Província': { capital: 'Matola', area: '26,058 km²', populacao: '~2.3M', pontos: 'Reserva Especial de Maputo, Ponta do Ouro', curiosidade: 'A Matola é o maior centro industrial.' },
      'Maputo Cidade': { capital: 'Maputo', area: '347 km²', populacao: '~1.2M', pontos: 'Mercado Central, Fortaleza, Museu de História Natural', curiosidade: 'Capital da República.' }
    };

    if (text) {
      const nome = text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
      const prov = provincias[nome] || Object.entries(provincias).find(([k]) => k.toLowerCase().includes(text.toLowerCase()))?.[1];
      const provNome = Object.entries(provincias).find(([k]) => k.toLowerCase().includes(text.toLowerCase()))?.[0];
      
      if (prov) {
        return msg.reply(
          `🇲🇿 *${provNome.toUpperCase()}* 🇲🇿\n\n` +
          `▸ Capital: *${prov.capital}*\n` +
          `▸ Área: *${prov.area}*\n` +
          `▸ População: *${prov.populacao}*\n` +
          `▸ Pontos Turísticos: *${prov.pontos}*\n` +
          `▸ Curiosidade: _${prov.curiosidade}_\n\n` +
          `_🇲🇿 Nel-Aviso-Bot-Moz_`
        );
      }
      return msg.reply(`◈ Província "${text}" não encontrada! Use *${usedPrefix + command}* sem argumentos para ver todas.`);
    }

    let result = `🇲🇿 *PROVÍNCIAS DE MOÇAMBIQUE* 🇲🇿\n\n`;
    
    for (const [nome, dados] of Object.entries(provincias)) {
      result += `▸ *${nome}*\n  Capital: ${dados.capital}\n\n`;
    }

    result += 
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `◈ Para ver detalhes: *${usedPrefix + command} Nampula*\n\n` +
      `_🇲🇿 Nel-Aviso-Bot-Moz_`;

    return msg.reply(result);
  }
};
