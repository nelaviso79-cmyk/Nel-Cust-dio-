export const command = {
  name: 'cfcheck',
  aliases: ['cloudflare', 'cf', 'iscloudflare', 'cfdetect'],
  description: 'Verifica se um site usa Cloudflare',
  category: 'utilidades',
  usage: '.cfcheck <URL>',
  example: '.cfcheck https://example.com'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const url = args[0];
  if (!url) {
    return sock.sendMessage(from, {
      text: '❌ Fornece a URL!\n\n💡 *Uso:* .cfcheck <URL>\n📌 *Ex:* .cfcheck https://example.com'
    }, { quoted: msg });
  }

  if (!url.startsWith('http')) {
    return sock.sendMessage(from, { text: '❌ URL deve começar com http:// ou https://' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '☁️', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/tools/cloudflare?url=${encodeURIComponent(url)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const info = `☁️ *CLOUDFLARE CHECK* — ${url}

━━━━━━━━━━━━━━━━━━━━

🛡️ Cloudflare: ${r.cloudflare || r.isCloudflare ? '✅ Sim' : '❌ Não'}
${r.ip ? `🌐 IP: ${r.ip}` : ''}
${r.location ? `📍 Localização: ${r.location}` : ''}
${r.provider ? `🔌 Provider: ${r.provider}` : ''}
${r.nameservers ? `📋 Nameservers: ${Array.isArray(r.nameservers) ? r.nameservers.join(', ') : r.nameservers}` : ''}
${r.ssl ? `🔒 SSL: ${r.ssl}` : ''}

💡 _Verificação via Delirius API_`;
      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('CF check failed:', e.message);
  }

  await sock.sendMessage(from, { text: '❌ Não consegui verificar o site. Tenta novamente.' }, { quoted: msg });
}
