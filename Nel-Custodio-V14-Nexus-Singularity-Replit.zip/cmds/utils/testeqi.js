export default {
  command: ['testeqi', 'qi', 'inteligencia'],
  category: 'diversao',
  description: 'Faz um teste rápido (e engraçado) do teu QI.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    await msg.react('🧠');
    
    const qi = Math.floor(Math.random() * 180) + 20;
    let rank = '';
    let comment = '';

    if (qi < 50) { rank = 'Batata 🥔'; comment = 'Consegues respirar sem ajuda? Incrível!'; }
    else if (qi < 80) { rank = 'Lento 🐢'; comment = 'Demoras 10 minutos para entender uma piada.'; }
    else if (qi < 100) { rank = 'Normal 😐'; comment = 'És uma pessoa comum. Nada de especial.'; }
    else if (qi < 120) { rank = 'Esperto 🦊'; comment = 'És mais inteligente que a média!'; }
    else if (qi < 140) { rank = 'Génio 🧠'; comment = 'Devias estar na NASA ou na Moz-Elite!'; }
    else { rank = 'EINSTEIN 🌌'; comment = 'O teu cérebro é de outro planeta!'; }

    const texto = `🧠 *TESTE DE QI RÁPIDO*\n\n` +
                  `👤 *Usuário:* ${msg.pushName}\n` +
                  `📊 *Resultado:* ${qi} Pontos\n` +
                  `🏆 *Rank:* ${rank}\n\n` +
                  `💭 *Comentário:* ${comment}\n\n` +
                  `_Nota: Este teste é apenas para diversão!_`;

    await msg.reply(texto);
    await msg.react('✅');
  }
};
