import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['falar', 'say', 'voz', 'tts2'],
  category: 'utilidades',
  description: 'Converte texto em áudio realista (Nota de voz).',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let text = args.join(' ').trim();
    if (!text && msg.quoted?.text) text = msg.quoted.text;
    
    if (!text) return msg.reply(`❌ O que queres que eu diga?\n\nExemplo: *${usedPrefix + command} Olá, eu sou o Nel-Aviso-Bot!*`);

    if (text.length > 300) return msg.reply('❌ Texto muito longo! Máximo 300 caracteres.');

    await msg.react('🗣️');
    
    const languages = ['pt-BR', 'pt-PT', 'en-US', 'es-ES'];
    let audioBuffer = null;

    try {
      // API Primária: Vreden (muito estável para PT)
      const vredenApi = `https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=pt`;
      const res1 = await fetch(vredenApi);
      if (res1.ok) {
        audioBuffer = await res1.buffer();
      }

      // API Secundária: Google TTS (Fallback)
      if (!audioBuffer || audioBuffer.length < 500) {
        const googleApi = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=pt&q=${encodeURIComponent(text)}`;
        const res2 = await fetch(googleApi, { headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (res2.ok) {
          audioBuffer = await res2.buffer();
        }
      }

      if (!audioBuffer || audioBuffer.length < 500) {
        throw new Error('Falha ao obter áudio das APIs.');
      }

      const tmpFile = `./tmp/voice_${Date.now()}.mp3`;
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
      fs.writeFileSync(tmpFile, audioBuffer);

      await sock.sendMessage(msg.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true // Envia como nota de voz
      }, { quoted: msg });

      await msg.react('✅');

      // Limpeza
      setTimeout(() => {
        try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {}
      }, 10000);

    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar voz. Tenta novamente mais tarde.\n> [Erro: ${e.message}]`);
    }
  }
};
