export default {
  command: ['sinaleiro', 'semaforo', 'pareousegue', 'sinal'],
  category: 'diversao',
  description: 'Sinal verde ou vermelho - decidir aleatoriamente 🚦',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const results = [
      { emoji: '🟢', text: 'VERDE - Vai em frente! Pode fazer!', color: 'Aprovação total' },
      { emoji: '🟢', text: 'VERDE - Tá liberado! Sem problema!', color: 'Liberdade' },
      { emoji: '🟡', text: 'AMARELO - Pensa bem antes... Talvez!', color: 'Precaução' },
      { emoji: '🟡', text: 'AMARELO - Hmm, cuidado! Não tenho certeza', color: 'Dúvida' },
      { emoji: '🔴', text: 'VERMELHO - Não faça isso! Pára!', color: 'Proibição' },
      { emoji: '🔴', text: 'VERMELHO - Definitivamente NÃO!', color: 'Negado' },
    ];

    const result = results[Math.floor(Math.random() * results.length)];

    let msg_text = `🚦 *SINALEIRO*\n\n`;
    msg_text += `${result.emoji} *${result.text}*\n\n`;
    msg_text += `📋 Classificação: ${result.color}\n\n`;

    if (text) {
      msg_text += `❓ Sobre: "${text}"\n\n`;
    }

    msg_text += `🔄 Use *${usedPrefix}${command} <questão>* para outra resposta!`;

    await sock.sendMessage(msg.key.remoteJid, { text: msg_text }, { quoted: msg });
  }
};
