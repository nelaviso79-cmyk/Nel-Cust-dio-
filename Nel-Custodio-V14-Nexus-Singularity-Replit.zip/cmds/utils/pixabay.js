/**
 * 🏞️ PIXABAY — Buscar imagens grátis de alta qualidade
 */
import fetch from 'node-fetch';

export default {
  command: ['pixabay', 'imggratis', 'freeimg', 'imglivre'],
  category: 'utilidades',
  description: 'Buscar imagens grátis no Pixabay 🏞️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} <busca>*\nEx: *${usedPrefix}pixabay praia*`);

    try {
      // API Pixabay (chave demo / pública)
      const key = '46189288-6e42d3e4c4f3d6e7ef2f3d2e4';
      const url = `https://pixabay.com/api/?key=${key}&q=${encodeURIComponent(text)}&per_page=5&lang=pt`;
      const res = await fetch(url);
      const data = await res.json();

      if (!data.hits?.length) {
        return msg.reply(`❌ Nenhuma imagem encontrada para "${text}".`);
      }

      for (let i = 0; i < Math.min(3, data.hits.length); i++) {
        const img = data.hits[i];
        await sock.sendMessage(msg.chat, {
          image: { url: img.largeImageURL || img.webformatURL },
          caption: `🏞️ *Pixabay*\n📝 ${img.tags}\n👤 ${img.user}\n❤️ ${img.likes} likes\n📐 ${img.imageWidth}x${img.imageHeight}\n🔗 ${img.pageURL}`
        }, { quoted: msg });
      }
    } catch (e) {
      // Fallback: delirius
      try {
        const url2 = `https://api.delirius.store/search/pixabay?query=${encodeURIComponent(text)}`;
        const res2 = await fetch(url2);
        const data2 = await res2.json();
        if (data2.status && data2.result?.length) {
          for (let i = 0; i < Math.min(3, data2.result.length); i++) {
            const img = data2.result[i];
            await sock.sendMessage(msg.chat, {
              image: { url: img.imageURL || img.largeImageURL || img.url },
              caption: `🏞️ *Pixabay*\n📝 ${img.tags || text}`
            }, { quoted: msg });
          }
          return;
        }
      } catch {}
      msg.reply(`❌ Erro ao buscar imagens. Tente novamente.`);
    }
  }
};
