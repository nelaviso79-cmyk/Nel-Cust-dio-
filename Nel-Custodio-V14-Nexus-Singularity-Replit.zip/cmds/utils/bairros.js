export default {
  command: ['bairros', 'maputobairros', 'bairro', 'zona'],
  category: 'utilidades',
  description: 'Informações sobre bairros e zonas de Maputo 🏘️',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const bairros = {
      '1': { nome: 'Mafalala', distrito: 'KaMpfumo', info: 'Bairro histórico, berço da cultura e desporto (Eusébio, Samora Machel).' },
      '2': { nome: 'Maxaquene', distrito: 'KaMpfumo', info: 'Bairro vibrante, famoso pelo Mercado do Peixe e vida noturna.' },
      '3': { nome: 'Xipamanine', distrito: 'KaMpfumo', info: 'Conhecido pelo maior mercado informal de Maputo.' },
      '4': { nome: 'Chamanculo', distrito: 'KaMpfumo', info: 'Bairro histórico, berço da Marrabenta.' },
      '5': { nome: 'Polana C', distrito: 'KaMpfumo', info: 'Zona nobre de Maputo, onde se localizam embaixadas e hotéis.' },
      '6': { nome: 'Costa do Sol', distrito: 'KaMpfumo', info: 'Zona turística, famosa pela praia e gastronomia.' },
      '7': { nome: 'Alto Maé', distrito: 'KaMpfumo', info: 'Zona central e comercial muito movimentada.' },
      '8': { nome: 'Malhangalene', distrito: 'KaMpfumo', info: 'Zona residencial central e histórica.' },
      '9': { nome: 'Hulene', distrito: 'KaMavota', info: 'Bairro populoso, conhecido pela zona da lixeira (em requalificação).' },
      '10': { nome: 'Zimpeto', distrito: 'KaMavota', info: 'Zona do Estádio Nacional do Zimpeto e Mercado grossista.' },
      '11': { nome: 'Mavalane', distrito: 'KaMavota', info: 'Zona onde se localiza o Aeroporto Internacional de Maputo.' },
      '12': { nome: 'T3', distrito: 'Matola', info: 'Bairro populoso da Matola com grande atividade comercial.' },
      '13': { nome: 'Liberdade', distrito: 'Matola', info: 'Bairro residencial importante na cidade da Matola.' },
      '14': { nome: 'Machava', distrito: 'Matola', info: 'Zona industrial e residencial, sede do Estádio da Machava.' },
      '15': { nome: 'Munhava', distrito: 'Beira', info: 'Bairro icónico e populoso da cidade da Beira.' }
    };

    if (text) {
      const num = text.trim();
      const bairro = bairros[num];
      if (bairro) {
        return msg.reply(
          `🏘️ *BAIRRO ${bairro.nome.toUpperCase()}* 🏘️\n\n` +
          `▸ Nome: *${bairro.nome}*\n` +
          `▸ Distrito: *${bairro.distrito}*\n` +
          `▸ Info: ${bairro.info}\n\n` +
          `_🇲🇿 Nel-Aviso-Bot-Moz_`
        );
      }
      // Search by name
      const found = Object.values(bairros).find(b => b.nome.toLowerCase().includes(text.toLowerCase()));
      if (found) {
        return msg.reply(
          `🏘️ *BAIRRO ${found.nome.toUpperCase()}* 🏘️\n\n` +
          `▸ Nome: *${found.nome}*\n` +
          `▸ Distrito: *${found.distrito}*\n` +
          `▸ Info: ${found.info}\n\n` +
          `_🇲🇿 Nel-Aviso-Bot-Moz_`
        );
      }
      return msg.reply(`◈ Bairro não encontrado! Use *${usedPrefix + command}* para ver a lista.`);
    }

    let result = `🏘️ *BAIRROS DE MAPUTO* 🏘️\n\n`;
    for (const [num, b] of Object.entries(bairros)) {
      result += `▸ *${num}.* ${b.nome} (${b.distrito})\n`;
    }
    result += `\n━━━━━━━━━━━━━━━━━━━━\n◈ Para detalhes: *${usedPrefix + command} 1* ou *${usedPrefix + command} Mafalala*\n\n_🇲🇿 Nel-Aviso-Bot-Moz_`;
    return msg.reply(result);
  }
};
