/**
 * 😀 STICKER EMOJI — Criar sticker a partir de emoji(s)
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['stickeremoji', 'semoji', 'emojisticker', 'emojisticker'],
  category: 'stickers',
  description: 'Criar sticker a partir de emoji 😀',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const emoji1 = args[0];
    const emoji2 = args[1];

    if (!emoji1) {
      return msg.reply(`❌ Use: *${usedPrefix}${command} <emoji> [emoji2]*\n\nEx: *${usedPrefix}${command} 😀*\nEx: *${usedPrefix}${command} 😎 🔥* (mix)`);
    }

    try {
      const tmpFile = `./tmp/sticker_emoji_${Date.now()}.webp`;
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });

      if (emoji2) {
        // Emoji mix (combinar dois emojis)
        try {
          const url = `https://api.delirius.store/other/emojimix?emoji1=${encodeURIComponent(emoji1)}&emoji2=${encodeURIComponent(emoji2)}`;
          const res = await fetch(url);
          const data = await res.json();
          if (data.status && data.result?.url) {
            const imgRes = await fetch(data.result.url);
            const buf = await imgRes.buffer();
            fs.writeFileSync(tmpFile, buf);
            await sock.sendMessage(msg.chat, {
              sticker: { url: tmpFile }
            }, { quoted: msg });
            setTimeout(() => { try { fs.unlinkSync(tmpFile); } catch {} }, 5000);
            return;
          }
        } catch {}
      }

      // Sticker de emoji único — criar via API
      try {
        const url = `https://api.delirius.store/other/emoji2img?emoji=${encodeURIComponent(emoji1)}&style=apple`;
        const res = await fetch(url);
        if (res.ok) {
          const buf = await res.buffer();
          if (buf.length > 500) {
            fs.writeFileSync(tmpFile, buf);
            await sock.sendMessage(msg.chat, {
              sticker: { url: tmpFile }
            }, { quoted: msg });
            setTimeout(() => { try { fs.unlinkSync(tmpFile); } catch {} }, 5000);
            return;
          }
        }
      } catch {}

      // Fallback: usar WhatsApp native
      await sock.sendMessage(msg.chat, {
        sticker: { url: `https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Twemoji_13.0_1f600.svg/120px-Twemoji_13.0_1f600.svg.png` }
      }, { quoted: msg });

    } catch (e) {
      msg.reply(`❌ Erro ao criar sticker de emoji.`);
    }
  }
};
