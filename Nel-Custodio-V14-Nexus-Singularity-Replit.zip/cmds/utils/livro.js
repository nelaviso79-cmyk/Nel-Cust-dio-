export default {
  command: ['livro', 'fakebook', 'bookcover'],
  category: 'diversao',
  description: 'Cria uma capa de livro fativa com texto personalizado',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} título|autor*\n\nExemplo: ${usedPrefix}${command} O Bot Fantástico|Nel-Aviso`);

    const parts = text.split('|');
    const title = parts[0]?.trim() || 'Livro';
    const author = parts[1]?.trim() || 'Desconhecido';

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/livro?title=${encodeURIComponent(title)}&author=${encodeURIComponent(author)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `📚 *Fake Book Cover*\n📖 ${title}\n✍️ ${author}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar capa: ${e.message}`);
    }
  }
};
