import fetch from 'node-fetch';
import moment from 'moment-timezone';

export default {
  command: ['speedtest', 'velocidade', 'ping2', 'latencia', 'speed'],
  category: 'utilidades',
  description: 'Teste de velocidade e latência do bot',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const startPing = Date.now();
      const { key } = await sock.sendMessage(msg.chat, { text: '⚡ A testar velocidade...' }, { quoted: msg });
      const endPing = Date.now();
      const pingMs = endPing - startPing;

      // Teste de velocidade de download
      let downloadSpeed = 'N/A';
      let uploadSpeed = 'N/A';
      let serverInfo = 'N/A';

      try {
        const dlStart = Date.now();
        const response = await fetch('https://speed.cloudflare.com/__down?bytes=1000000', {
          method: 'GET',
          timeout: 10000
        });
        const buffer = await response.arrayBuffer();
        const dlEnd = Date.now();
        const dlDuration = (dlEnd - dlStart) / 1000;
        const dlBytes = buffer.byteLength;
        const dlSpeedMbps = ((dlBytes * 8) / (dlDuration * 1000000)).toFixed(2);
        downloadSpeed = `${dlSpeedMbps} Mbps`;
      } catch {}

      try {
        const ulStart = Date.now();
        const ulData = Buffer.alloc(500000, 'x');
        await fetch('https://speed.cloudflare.com/__up', {
          method: 'POST',
          body: ulData,
          timeout: 10000
        });
        const ulEnd = Date.now();
        const ulDuration = (ulEnd - ulStart) / 1000;
        const ulSpeedMbps = ((ulData.length * 8) / (ulDuration * 1000000)).toFixed(2);
        uploadSpeed = `${ulSpeedMbps} Mbps`;
      } catch {}

      // Teste de latência para APIs
      let apiLatency = 'N/A';
      try {
        const apiStart = Date.now();
        await fetch('https://api.delirius.store', { method: 'HEAD', timeout: 5000 });
        apiLatency = `${Date.now() - apiStart}ms`;
      } catch {}

      const now = moment.tz('Africa/Maputo').format('HH:mm:ss');

      const result = `
⚡ *TESTE DE VELOCIDADE* ⚡

📡 *Latência:*
▸ WhatsApp Ping: *${pingMs}ms*
▸ API Latência: *${apiLatency}*

🚀 *Velocidade:*
▸ Download: *${downloadSpeed}*
▸ Upload: *${uploadSpeed}*

🖥️ *Servidor:*
▸ Node.js: *${process.version}*
▸ Memória: *${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB*
▸ Uptime: *${formatUptime(process.uptime())}*
▸ Hora: *${now}*

📊 *Status:* ${pingMs < 500 ? '🟢 Excelente' : pingMs < 1000 ? '🟡 Bom' : '🔴 Lento'}
`.trim();

      await sock.sendMessage(msg.chat, { text: result, edit: key }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> Erro no speedtest: *${e.message}*`);
    }
  },
};

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}
