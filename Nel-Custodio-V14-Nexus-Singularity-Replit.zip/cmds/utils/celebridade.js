// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/celebridade.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['celebridade', 'celeb', 'whosthis', 'quemceleb', 'recognize'],
  category: 'utilidades',
  description: 'Reconhecer celebridade numa foto com IA 🎬',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const q = msg.quoted;

    if (!q || !q.message?.imageMessage) {
      return msg.reply(
        `🎬 *RECONHECIMENTO DE CELEBRIDADES* 🎬\n\n` +
        `A IA identifica celebridades em fotos!\n\n` +
        `📋 Como usar:\n` +
        `1️⃣ Responda a uma foto\n` +
        `2️⃣ *${usedPrefix}${command}*\n\n` +
        `> A IA vai dizer quem é a pessoa na foto!`
      );
    }

    await msg.reply(`⏳ A analisar a foto com IA de reconhecimento...`);

    try {
      // Download image
      const media = await sock.downloadMediaMessage(q);
      if (!media) throw new Error('Falha ao baixar imagem');

      // Upload to get URL
      const tmpForm = new FormData();
      const blob = new Blob([media]);
      tmpForm.append('reqtype', 'fileupload');
      tmpForm.append('fileToUpload', blob, 'image.jpg');
      const upRes = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: tmpForm });
      if (!upRes.ok) throw new Error('Falha ao hospedar imagem');
      const imgUrl = await upRes.text();

      if (!imgUrl || !imgUrl.startsWith('http')) throw new Error('URL inválida');

      // Primary: Delirius Celebrity API
      const res = await fetch(
        `https://api.delirius.store/ia/celebrity?image=${encodeURIComponent(imgUrl)}`
      );
      const data = await res.json();

      if (data.status && data.result) {
        const celebs = Array.isArray(data.result) ? data.result : [data.result];

        let text = `🎬 *CELEBRIDADES DETECTADAS* 🎬\n\n`;

        for (const c of celebs) {
          text +=
            `⭐ Nome: *${c.name || c.celebrity || 'Desconhecido'}*\n` +
            `📊 Confiança: *${c.confidence || c.score || c.probability ? Math.round((c.confidence || c.score || c.probability) * 100) + '%' : 'N/A'}*\n` +
            `${c.occupation || c.profession ? `💼 Ocupação: ${c.occupation || c.profession}\n` : ''}` +
            `${c.nationality ? `🌍 Nacionalidade: ${c.nationality}\n` : ''}` +
            `${c.description ? `📝 ${c.description}\n` : ''}\n`;
        }

        if (celebs.length === 1 && celebs[0].name) {
          text += `> Resultado da análise de IA`;
        } else if (celebs.length > 1) {
          text += `> ${celebs.length} celebridade(s) detectada(s)`;
        }

        await msg.reply(text);
        return;
      }

      // Fallback: Age detection at least gives some face info
      const ageRes = await fetch(
        `https://api.delirius.store/ia/age?image=${encodeURIComponent(imgUrl)}`
      );
      const ageData = await ageRes.json();

      if (ageData.status && ageData.result) {
        const r = ageData.result;
        await msg.reply(
          `🔍 *ANÁLISE FACIAL* 🔍\n\n` +
          `A IA não identificou uma celebridade específica, mas detectou:\n\n` +
          `👤 Idade aparente: *${r.age || 'N/A'}*\n` +
          `👤 Género: *${r.gender || 'N/A'}*\n` +
          `${r.expression ? `😊 Expressão: ${r.expression}\n` : ''}\n` +
          `> Tente uma foto mais clara de um rosto conhecido.`
        );
        return;
      }

      await msg.reply(
        `❌ Não foi possível reconhecer nenhuma celebridade na foto.\n` +
        `> Tente uma foto mais nítida com um rosto claro.`
      );

    } catch (e) {
      await msg.reply(`❌ Erro ao analisar foto: *${e.message}*`);
    }
  }
};
