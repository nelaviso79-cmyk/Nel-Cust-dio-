/**
 * 🎨 GERADOR DE LOGO — Criar logos estilizados com texto
 */
import fetch from 'node-fetch';
import fs from 'fs';

const STYLES = {
  neon: 'Neon brilhante',
  gelo: 'Efeito gelo',
  fogo: 'Efeito fogo',
  metal: 'Metal 3D',
  arcoiris: 'Arco-íris',
  retros: 'Retro',
  grafite: 'Grafite',
  sand: 'Areia',
  nuvem: 'Nuvem',
  vidro: 'Vidro'
};

export default {
  command: ['logotipo', 'logo', 'criarlogo', 'makelogo', 'textlogo'],
  category: 'utilidades',
  description: 'Criar logos estilizados com texto 🎨',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const style = args[0]?.toLowerCase();
    const text = args.slice(1).join(' ').trim();

    if (!style || !STYLES[style] || !text) {
      const lista = Object.entries(STYLES).map(([k, v]) => `• ${k} = ${v}`).join('\n');
      return msg.reply(`🎨 Use: *${usedPrefix}${command} <estilo> <texto>*\n\n*Estilos:*\n${lista}\n\nEx: *${usedPrefix}logo neon Nel Aviso*`);
    }

    try {
      const tmpFile = `./tmp/logo_${Date.now()}.png`;
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });

      let imgBuffer = null;

      // API 1: delirius textpro
      try {
        const url = `https://api.delirius.store/textpro/${style}?text=${encodeURIComponent(text)}`;
        const res = await fetch(url);
        if (res.ok) {
          const buf = await res.buffer();
          if (buf.length > 5000) imgBuffer = buf;
        }
      } catch {}

      // API 2: siputzx textpro
      if (!imgBuffer) {
        try {
          const url = `https://app.siputzx.my.id/api/textpro/${style}?text=${encodeURIComponent(text)}`;
          const res = await fetch(url);
          if (res.ok) {
            const buf = await res.buffer();
            if (buf.length > 5000) imgBuffer = buf;
          }
        } catch {}
      }

      if (imgBuffer) {
        fs.writeFileSync(tmpFile, imgBuffer);
        await sock.sendMessage(msg.chat, {
          image: { url: tmpFile },
          caption: `🎨 *Logo ${STYLES[style]}*\n📝 ${text}`
        }, { quoted: msg });
        setTimeout(() => { try { fs.unlinkSync(tmpFile); } catch {} }, 5000);
      } else {
        // Fallback: gerarimg
        msg.reply(`❌ Estilo "${style}" indisponível agora. Tente *.gerarimg logo ${style} ${text}* como alternativa.`);
      }
    } catch (e) {
      msg.reply(`❌ Erro ao criar logo.`);
    }
  }
};
