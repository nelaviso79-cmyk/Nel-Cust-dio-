import fetch from 'node-fetch';

export default {
  command: ['ssweb', 'screenshotweb', 'captura', 'webshot', 'siteshot', 'paginaweb'],
  category: 'utilidades',
  description: 'Captura screenshot de qualquer página web',
  run: async ({ sock, msg, args, from }) => {
    const url = args[0];
    if (!url) {
      return msg.reply('❌ Fornece a URL do site!\n\n💡 *Uso:* .ssweb <URL>\n📌 *Ex:* .ssweb https://www.google.com');
    }

    // Validar URL
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return msg.reply('❌ A URL deve começar com http:// ou https://');
    }

    await sock.sendMessage(from, { react: { text: '📸', key: msg.key } });

    try {
      // Delirius Tools — /tools/ssweb
      const res = await fetch(`https://api.delirius.store/tools/ssweb?url=${encodeURIComponent(url)}`);

      if (res.ok) {
        const contentType = res.headers.get('content-type');
        if (contentType && contentType.includes('image')) {
          const buffer = Buffer.from(await res.arrayBuffer());
          await sock.sendMessage(from, {
            image: buffer,
            caption: `📸 *Screenshot*\n🔗 ${url}`,
            contextInfo: {
              externalAdReply: {
                title: 'Web Screenshot',
                body: url,
                thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/2875/2875405.png',
                mediaType: 1
              }
            }
          }, { quoted: msg });
          return;
        }

        // Se retornou JSON
        const data = await res.json();
        if (data?.status === 200 && data?.result) {
          const imgUrl = data.result.image || data.result.url || data.result.screenshot;
          if (imgUrl) {
            const imgRes = await fetch(imgUrl);
            if (imgRes.ok) {
              const buffer = Buffer.from(await imgRes.arrayBuffer());
              await sock.sendMessage(from, {
                image: buffer,
                caption: `📸 *Screenshot*\n🔗 ${url}`
              }, { quoted: msg });
              return;
            }
          }
        }
      }
    } catch (e) {
      console.log('SSWeb primary failed:', e.message);
    }

    // Fallback — screenshot machine API
    try {
      const ssUrl = `https://image.thum.io/get/width/1280/${url}`;
      const res = await fetch(ssUrl);
      if (res.ok) {
        const buffer = Buffer.from(await res.arrayBuffer());
        await sock.sendMessage(from, {
          image: buffer,
          caption: `📸 *Screenshot*\n🔗 ${url}\n\n_⚠️ Resolução reduzida (fallback)_`
        }, { quoted: msg });
        return;
      }
    } catch (e) {
      console.log('SSWeb fallback failed:', e.message);
    }

    await msg.reply(`❌ Não consegui capturar o screenshot de:\n🔗 ${url}\n\nVerifica se a URL está acessível.`);
  }
};
