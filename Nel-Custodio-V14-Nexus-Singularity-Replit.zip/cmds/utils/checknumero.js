export default {
  command: ['checknumero', 'checknum', 'verificar', 'whatsapp', 'wa'],
  category: 'utilidades',
  description: 'Verificar se um número tem WhatsApp 📱',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) {
      return msg.reply(
        `📱 *VERIFICAR NÚMERO* 📱\n\n` +
        `◈ Verifique se um número tem WhatsApp!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} 258876365643*\n` +
        `✎ Exemplo: *${usedPrefix + command} +258 84 000 0000*`
      );
    }

    // Limpar o número
    let numero = text.replace(/[^0-9]/g, '');
    
    if (numero.length < 7 || numero.length > 15) {
      return msg.reply('◈ Número inválido! Verifique e tente novamente.');
    }

    const jid = numero + '@s.whatsapp.net';

    try {
      const [result] = await sock.onWhatsApp(jid);
      
      if (result?.exists) {
        return msg.reply(
          `📱 *NÚMERO VERIFICADO* ✅\n\n` +
          `▸ Número: *${numero}*\n` +
          `▸ WhatsApp: *SIM* ✅\n` +
          `▸ JID: ${result.jid}\n\n` +
          `_📱 Nel-Aviso-Bot-Moz_`
        );
      } else {
        return msg.reply(
          `📱 *NÚMERO VERIFICADO* ❌\n\n` +
          `▸ Número: *${numero}*\n` +
          `▸ WhatsApp: *NÃO* ❌\n\n` +
          `◈ Este número não tem WhatsApp registado.`
        );
      }
    } catch (e) {
      return msg.reply(`◈ Erro ao verificar: ${e.message}`);
    }
  }
};
