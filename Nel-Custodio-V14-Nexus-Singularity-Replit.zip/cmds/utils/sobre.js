export default {
  command: ['sobre', 'aboutmoz', 'moçambiqueinfo', 'mozinfo'],
  category: 'utilidades',
  description: 'Informações sobre Moçambique 🇲🇿',
  run: async ({ msg, sock, usedPrefix, command }) => {
    let result = `🇲🇿 *MOÇAMBIQUE - Informações*\n\n`;
    result += `📋 Nome oficial: República de Moçambique\n`;
    result += `🏙️ Capital: Maputo (Cidade de Maputo)\n`;
    result += `🗺️ Área: 801.590 km²\n`;
    result += `👥 População: ~33 milhões\n`;
    result += `🗣️ Idiomas: Português (oficial), Makhuwa, Tsonga, Lomwe, Sena, etc.\n`;
    result += `💰 Moeda: Metical (MZN)\n`;
    result += `🕐 Fuso: GMT+2 (CAT)\n`;
    result += `🎵 Música: Marrabenta, Xigubo, Timbila, Kizomba\n`;
    result += `🍲 Comida: Matapa, Xima, Frango à cafreal, Camarão\n`;
    result += `🏖️ Praias: Tofo, Bazaruto, Vilankulo, Pemba\n`;
    result += `🌿 Parques: Gorongosa, Limpopo, Bazaruto, Quirimbas\n`;
    result += `📜 Independência: 25 de Junho de 1975\n`;
    result += `🤝 Fronteiras: Tanzânia, Malawi, Zâmbia, Zimbabué, África do Sul, Eswatini\n`;
    result += `🌊 Costa: 2.470 km no Oceano Índico\n\n`;
    result += `🏙️ Principais Cidades:\n`;
    result += `  • Maputo - Capital e maior cidade\n`;
    result += `  • Beira - Porto importante\n`;
    result += `  • Nampula - Centro económico do norte\n`;
    result += `  • Quelimane - Cidade histórica\n`;
    result += `  • Tete - Rica em carvão mineral\n`;
    result += `  • Pemba - Paraíso turístico\n\n`;
    result += `💡 Use *${usedPrefix}provincias* para info de cada província!`;

    await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
  }
};
