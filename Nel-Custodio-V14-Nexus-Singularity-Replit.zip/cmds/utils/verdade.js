export default {
  command: ['verdade', 'truth', 'verdades'],
  category: 'diversao',
  description: 'Pergunta de verdade - Verdade ou Desafio 🤔',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const perguntas = [
      'Qual foi a última mentira que disse?',
      'Qual é o teu maior medo?',
      'Qual é o teu maior arrependiz-mento?',
      'Qual é a coisa mais embaraçosa que te aconteceu?',
      'Qual é o teu segredo mais profundo?',
      'Quem é a pessoa que mais admiras?',
      'Qual é o teu maior sonho?',
      'Já traíste alguém ou foste traído?',
      'Qual é a coisa que mais te dá raiva?',
      'Qual é o teu vício que ninguém sabe?',
      'Se pudesses mudar uma coisa em ti, o que seria?',
      'Qual é a pessoa neste grupo que mais te atrai?',
      'Qual é a coisa mais maluca que já fizeste?',
      'Qual é o teu maior complexo?',
      'Já choraste por causa de alguém deste grupo?',
      'Qual é a mensagem mais recente no teu telefone?',
      'Qual é a coisa que mais te envergonha?',
      'Qual é o teu maior fracasso?',
      'Já roubaste algo? O quê?',
      'Qual é o teu maior talento oculto?',
      'O que farías se fosses invisível por um dia?',
      'Qual é a coisa mais infantil que ainda fazes?',
      'Qual é o pior apelido que já te deram?',
      'Qual é a comida que mais odeias mas finges gostar?',
      'Qual é o teu pior hábito?'
    ];
    
    const pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];
    
    return msg.reply(
      `🤔 *VERDADE OU DESAFIO* 🤔\n\n` +
      `▸ *VERDADE*\n\n` +
      `▸ ${pergunta}\n\n` +
      `▸ Usa *${usedPrefix}desafio* para um desafio!\n\n` +
      `_🤔 Nel-Aviso-Bot_`
    );
  }
};
