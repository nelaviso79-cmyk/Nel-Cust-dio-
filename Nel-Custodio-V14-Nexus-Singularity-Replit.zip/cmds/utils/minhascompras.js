/**
 * 📊 MINHAS COMPRAS — Histórico pessoal de compras
 */
import db from '#db';

function mbToReadable(mb) {
  if (mb >= 1024) return (mb / 1024).toFixed(2) + 'GB';
  return mb + 'MB';
}

export default {
  command: ['minhascompras', 'meuhistorico', 'meusdados', 'meuperfil'],
  category: 'pagamentos',
  description: 'Ver tuas compras e histórico pessoal 📊',
  run: async ({ msg, sock, args, usedPrefix, from, sender, pushname, isGroup }) => {
    const phone = sender.split('@')[0];
    const compras = (db.getChat(from) || {}).compras || { compradores: {} };
    const comp = compras.compradores[phone];

    if (!comp) {
      return msg.reply(
        `┌──「 📊 *TUAS COMPRAS* 」\n│\n│ 😔 Nenhuma compra registada.\n│\n│ 💡 Use *${usedPrefix}comprar <valor>*\n│ para registar a tua primeira compra!\n└───────────────`
      );
    }

    // Posição no ranking
    const all = Object.entries(compras.compradores).sort((a, b) => b[1].totalMB - a[1].totalMB);
    const pos = all.findIndex(([p]) => p === phone) + 1;
    const maior = all[0]?.[1]?.totalMB || 0;

    let r = `┌──「 📊 *TUAS COMPRAS* 」\n│\n`;
    r += `│ 👤 Nome: *${comp.nome || phone}*\n`;
    r += `│ 📱 Número: *${phone}*\n`;
    r += `│\n`;
    r += `│ 📊 Total acumulado: *${mbToReadable(comp.totalMB)}*\n`;
    r += `│ 💵 Total gasto: *${comp.totalMT.toFixed(2)} MT*\n`;
    r += `│ 🛒 Compras feitas: *${comp.totalCompras}*\n`;
    r += `│ 🔄 Compras hoje: *${comp.comprasHoje || 0}*\n`;
    r += `│ 🏆 Posição: * nº ${pos}* de ${all.length}\n`;

    if (pos === 1) r += `│ 👑 *LÍDER do ranking!*\n`;
    else if (maior > comp.totalMB) {
      const falta = mbToReadable(maior - comp.totalMB);
      r += `│ 💡 Faltam *${falta}* para o topo!\n`;
    }

    r += `│\n│ ── *HISTÓRICO RECENTE* ──\n│\n`;

    const hist = (comp.historico || []).slice(-5).reverse();
    for (const h of hist) {
      r += `│ ▸ ${h.data}\n`;
      r += `│   💵 ${h.valor}MT → ${h.megas >= 1024 ? mbToReadable(h.megas) : h.megas + 'MB'} (${h.tipo})\n`;
    }

    if (hist.length === 0) r += `│ (sem histórico detalhado)\n`;

    r += `│\n└───────────────\n🏆 *${usedPrefix}ranking* para ver o top!`;

    return msg.reply(r);
  }
};
