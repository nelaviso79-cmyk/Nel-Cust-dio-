export default {
  command: ['ifaketext', 'faketext', 'imsg', 'fakeimessage'],
  category: 'diversao',
  description: 'Cria uma conversa fativa estilo iMessage',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} nome|mensagem*\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Olá, como estás?`);

    const parts = text.split('|');
    const name = parts[0]?.trim() || 'Contato';
    const messageText = parts.slice(1).join('|').trim();

    if (!messageText) return msg.reply(`❌ Forneça a mensagem!\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Olá, como estás?`);

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/ifaketext?name=${encodeURIComponent(name)}&text=${encodeURIComponent(messageText)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `📱 *Fake iMessage*\n👤 ${name}\n💬 ${messageText}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar iMessage: ${e.message}`);
    }
  }
};
