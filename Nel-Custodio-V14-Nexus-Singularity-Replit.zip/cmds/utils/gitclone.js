import fetch from 'node-fetch';

const regex = /^(?:https:\/\/|git@)github\.com\/([^\/]+)\/([^\/]+?)(?:\.git)?$/i;

export default {
  command: ['gitclone', 'git'],
  category: 'utilidades',
  description: 'Pesquisar e baixar um repositório do GitHub.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    if (!text) {
      return sock.reply(msg.chat, '《✧》 Por favor, forneça um link ou nome do repositório de GitHub.', msg);
    }
    try {
      await msg.react('🕒');
      let info = '';
      let image;
      let zipBuffer, zipName;
      let repos = [];
      const match = text.match(regex);
      if (match) {
        const [, user, repo] = match;
        const repoRes = await fetch(`https://api.github.com/repos/${user}/${repo}`);
        const zipRes = await fetch(`https://api.github.com/repos/${user}/${repo}/zipball`);
        const repoData = await repoRes.json();
        zipName = zipRes.headers.get('content-disposition')?.match(/filename=(.*)/)?.[1];
        if (!zipName) zipName = `${repo}-${user}.zip`;
        zipBuffer = Buffer.from(await zipRes.arrayBuffer());
        repos.push(repoData);
        image = 'https://cdn.yuki-wabot.my.id/files/MqnN.jpeg';
      } else {
        const res = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(text)}`);
        const json = await res.json();
        if (!json.items.length) {
          return sock.reply(msg.chat, '《✧》 Nenhum resultado encontrado.', msg);
        }
        if (json.items.length === 1) {
          const repo = json.items[0];
          const zipRes = await fetch(`https://api.github.com/repos/${repo.owner.login}/${repo.name}/zipball`);
          zipName = zipRes.headers.get('content-disposition')?.match(/filename=(.*)/)?.[1];
          if (!zipName) zipName = `${repo.name}-${repo.owner.login}.zip`;
          zipBuffer = Buffer.from(await zipRes.arrayBuffer());
          repos.push(repo);
          image = Buffer.from(await (await fetch(repo.owner.avatar_url)).arrayBuffer());
        } else {
          repos = json.items;
          image = Buffer.from(await (await fetch(repos[0].owner.avatar_url)).arrayBuffer());
        }
      }
      info += repos.map((repo, index) => `✩ Resultado: ${index + 1}
✩ Criador: ${repo.owner.login}
✩ Nome: ${repo.name}
✩ Criado: ${formatDate(repo.created_at)}
✩ Atualizado: ${formatDate(repo.updated_at)}
✩ Visitas: ${repo.watchers}
✩ Bifurcado: ${repo.forks}
✩ Estrelas: ${repo.stargazers_count}
✩ Issues: ${repo.open_issues}
✩ Descrição: ${repo.description ? repo.description : 'Sem Descrição'}
✩ Link: ${repo.clone_url}`).join('\n────────────────────\n');
      await sock.sendFile(msg.chat, image, 'github_info.jpg', info.trim(), msg);
      if (zipBuffer && zipName) {
        await sock.sendFile(msg.chat, zipBuffer, zipName, null, msg);
      }
      await msg.react('✔️');
    } catch (e) {
      await msg.react('✖️');
      return msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};

function formatDate(n, locale = 'pt-BR') {
  const d = new Date(n);
  return d.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
}