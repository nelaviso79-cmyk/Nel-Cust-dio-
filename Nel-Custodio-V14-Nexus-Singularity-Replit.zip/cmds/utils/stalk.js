// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/stalk.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['stalk', 'stalker', 'stalkear', 'perfilred'],
  category: 'utilidades',
  description: 'Stalk de perfil de redes sociais (TikTok/Instagram/Telegram/X) 🔍',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args[0]) {
      return msg.reply(
        `🔍 *STALK — Perfil de Redes Sociais*\n\n` +
        `Use para ver informações públicas de um perfil:\n\n` +
        `📱 TikTok: *${usedPrefix}${command} tiktok @usuario*\n` +
        `📷 Instagram: *${usedPrefix}${command} ig @usuario*\n` +
        `✈️ Telegram: *${usedPrefix}${command} tg @canal*\n` +
        `🐦 Twitter/X: *${usedPrefix}${command} x @usuario*\n\n` +
        `> Exemplo: *${usedPrefix}${command} tiktok @nelcustodio*`
      );
    }

    const platform = args[0].toLowerCase();
    const username = args.slice(1).join(' ').replace(/@/g, '').trim();

    if (!username) {
      return msg.reply(`❌ Especifique o username! Ex: *${usedPrefix}${command} ${platform} @usuario*`);
    }

    await msg.reply(`⏳ A buscar perfil de *${username}* no *${platform}*...`);

    try {
      switch (platform) {
        case 'tiktok':
        case 'tt':
          await stalkTikTok(msg, sock, username);
          break;
        case 'instagram':
        case 'ig':
        case 'insta':
          await stalkInstagram(msg, sock, username);
          break;
        case 'telegram':
        case 'tg':
        case 'tele':
          await stalkTelegram(msg, sock, username);
          break;
        case 'twitter':
        case 'x':
        case 'twit':
          await stalkTwitter(msg, sock, username);
          break;
        default:
          return msg.reply(
            `❌ Plataforma *${platform}* não suportada!\n\nUse: *tiktok*, *ig*, *tg* ou *x*`
          );
      }
    } catch (e) {
      await msg.reply(`❌ Erro ao buscar perfil: *${e.message}*\n> Verifique se o username está correcto.`);
    }
  }
};

async function stalkTikTok(msg, sock, username) {
  const res = await fetch(`https://api.delirius.store/tools/tiktokstalk?q=${encodeURIComponent(username)}`);
  const data = await res.json();

  if (!data.status || !data.result) throw new Error('Perfil não encontrado');

  const u = data.result;
  const info =
    `📱 *TIKTOK STALK* 📱\n\n` +
    `👤 Nome: *${u.nickname || u.name || 'N/A'}*\n` +
    `🆔 Username: *@${u.username || username}*\n` +
    `📝 Bio: ${u.signature || u.bio || 'Sem bio'}\n\n` +
    `📊 *STATS*\n` +
    `👥 Seguidores: *${formatNum(u.followers || u.fans || 0)}*\n` +
    `👤 Seguindo: *${formatNum(u.following || 0)}*\n` +
    `🎬 Vídeos: *${formatNum(u.posts || u.videos || 0)}*\n` +
    `❤️ Likes: *${formatNum(u.likes || u.hearts || 0)}*\n\n` +
    `✅ Verificado: ${u.verified ? '✔️ Sim' : '❌ Não'}\n` +
    `🌍 Região: ${u.region || 'N/A'}\n` +
    `🔗 Link: https://tiktok.com/@${u.username || username}`;

  if (u.profilePicture || u.avatar || u.photo) {
    const img = u.profilePicture || u.avatar || u.photo;
    await sock.sendMessage(msg.chat, {
      image: { url: img },
      caption: info
    }, { quoted: msg });
  } else {
    await msg.reply(info);
  }
}

async function stalkInstagram(msg, sock, username) {
  const res = await fetch(`https://api.delirius.store/tools/igstalk?username=${encodeURIComponent(username)}`);
  const data = await res.json();

  if (!data.status || !data.result) throw new Error('Perfil não encontrado');

  const u = data.result;
  const info =
    `📷 *INSTAGRAM STALK* 📷\n\n` +
    `👤 Nome: *${u.fullname || u.name || 'N/A'}*\n` +
    `🆔 Username: *@${u.username || username}*\n` +
    `📝 Bio: ${u.biography || u.bio || 'Sem bio'}\n\n` +
    `📊 *STATS*\n` +
    `👥 Seguidores: *${formatNum(u.followers || 0)}*\n` +
    `👤 Seguindo: *${formatNum(u.following || 0)}*\n` +
    `🎬 Posts: *${formatNum(u.posts || 0)}*\n` +
    `🎞 Reels: *${formatNum(u.reels || 0)}*\n\n` +
    `✅ Verificado: ${u.verified ? '✔️ Sim' : '❌ Não'}\n` +
    `🔒 Privado: ${u.private ? '🔒 Sim' : '🔓 Não'}\n` +
    `🔗 Link: https://instagram.com/${u.username || username}`;

  if (u.profilePicture || u.avatar || u.photo || u.hd_profile_pic_url_info?.url) {
    const img = u.hd_profile_pic_url_info?.url || u.profilePicture || u.avatar || u.photo;
    await sock.sendMessage(msg.chat, {
      image: { url: img },
      caption: info
    }, { quoted: msg });
  } else {
    await msg.reply(info);
  }
}

async function stalkTelegram(msg, sock, username) {
  const res = await fetch(`https://api.delirius.store/tools/telegramchannelstalk?channel=${encodeURIComponent(username)}`);
  const data = await res.json();

  if (!data.status || !data.result) throw new Error('Canal não encontrado');

  const u = data.result;
  const info =
    `✈️ *TELEGRAM STALK* ✈️\n\n` +
    `📢 Título: *${u.title || u.name || 'N/A'}*\n` +
    `🆔 Username: *@${u.username || username}*\n` +
    `📝 Descrição: ${u.description || u.about || 'Sem descrição'}\n\n` +
    `📊 *STATS*\n` +
    `👥 Membros: *${formatNum(u.subscribers || u.members || 0)}*\n` +
    `📸 Fotos: *${formatNum(u.photos || 0)}*\n\n` +
    `🔗 Link: https://t.me/${u.username || username}`;

  if (u.photo) {
    await sock.sendMessage(msg.chat, {
      image: { url: u.photo },
      caption: info
    }, { quoted: msg });
  } else {
    await msg.reply(info);
  }
}

async function stalkTwitter(msg, sock, username) {
  const res = await fetch(`https://api.delirius.store/tools/xstalk?username=${encodeURIComponent(username)}`);
  const data = await res.json();

  if (!data.status || !data.result) throw new Error('Perfil não encontrado');

  const u = data.result;
  const info =
    `🐦 *TWITTER/X STALK* 🐦\n\n` +
    `👤 Nome: *${u.name || u.displayName || 'N/A'}*\n` +
    `🆔 Username: *@${u.username || username}*\n` +
    `📝 Bio: ${u.bio || u.description || 'Sem bio'}\n\n` +
    `📊 *STATS*\n` +
    `👥 Seguidores: *${formatNum(u.followers || 0)}*\n` +
    `👤 Seguindo: *${formatNum(u.following || 0)}*\n` +
    `📝 Tweets: *${formatNum(u.tweets || u.statuses || 0)}*\n\n` +
    `✅ Verificado: ${u.verified ? '✔️ Sim' : '❌ Não'}\n` +
    `🔗 Link: https://x.com/${u.username || username}`;

  if (u.avatar || u.profilePicture || u.banner) {
    const img = u.avatar || u.profilePicture || u.banner;
    await sock.sendMessage(msg.chat, {
      image: { url: img },
      caption: info
    }, { quoted: msg });
  } else {
    await msg.reply(info);
  }
}

function formatNum(n) {
  if (typeof n !== 'number') n = parseInt(n) || 0;
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K';
  return n.toLocaleString();
}
