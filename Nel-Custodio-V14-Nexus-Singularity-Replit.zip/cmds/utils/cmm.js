export default {
  command: ['cmm', 'changemymind', 'changemind'],
  category: 'diversao',
  description: 'Cria um meme "Change My Mind" com texto personalizado',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} opinião*\n\nExemplo: ${usedPrefix}${command} Bot é melhor que humano`);

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/changemymind?text=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `🤔 *Change My Mind*\n📝 ${text}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar meme: ${e.message}`);
    }
  }
};
