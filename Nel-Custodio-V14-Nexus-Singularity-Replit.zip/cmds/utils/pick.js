export default {
  command: ['pick', 'escolher', 'issoouaquilo'],
  category: 'diversao',
  description: 'Jogo "Isso ou Aquilo" - escolhe entre duas opções aleatórias!',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const picks = [
      ['🍕 Pizza', '🍔 Hambúrguer'],
      ['🏖️ Praia', '🏔️ Montanha'],
      ['🌅 Nascer do sol', '🌙 Pôr do sol'],
      ['📱 Android', '🍎 iPhone'],
      ['🎬 Cinema', '🏠 Netflix'],
      ['⚽ Futebol', '🏀 Basquete'],
      ['📖 Livro', '🎬 Filme'],
      ['🎮 Videojogo', '🎭 Teatro'],
      ['🎶 Música', '📺 Séries'],
      ['☕ Café', '🍵 Chá'],
      ['🦁 Leão', '🐘 Elefante'],
      ['✈️ Viajar', '🏠 Ficar em casa'],
      ['💰 Dinheiro', '❤️ Amor'],
      ['🧠 Inteligência', '💪 Força'],
      ['🎨 Criatividade', '📊 Lógica'],
      ['🚗 Carro', '🏍️ Moto'],
      ['🥩 Carne', '🥬 Vegetais'],
      ['📚 Estudar', '🎮 Jogar'],
      ['🐱 Gato', '🐶 Cão'],
      ['🌞 Verão', '🌧️ Inverno'],
      ['🎵 Kizomba', '🎵 Marrabenta'],
      ['🇲🇿 Moçambique', '🌍 Portugal'],
      ['🍚 Xima', '🥘 Matapa'],
      ['💪 Treinar', '😴 Dormir'],
      ['🧙 Magia', '🔬 Ciência'],
    ];

    const [opt1, opt2] = picks[Math.floor(Math.random() * picks.length)];
    const emoji = ['✅', '❌', '🅰️', '🅱️', '⬆️', '⬇️', '1️⃣', '2️⃣'];

    const text = 
      `❧ *Isso ou Aquilo* 🤔\n\n` +
      `▸ Escolhe uma opção!\n\n` +
      `🅰️ ${opt1}\n` +
      `🅱️ ${opt2}\n\n` +
      `▸ Reaja com 🅰️ ou 🅱️ para votar!`;

    return msg.reply(text);
  },
};
