/**
 * 🔄 TRADUZIR — Tradutor rápido com detecção automática
 */
import fetch from 'node-fetch';

export default {
  command: ['traduzir', 'traduz', 'trans', 'translate2'],
  category: 'utilidades',
  description: 'Traduzir texto com detecção automática 🔄',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    // Formato: .traduzir pt Olá mundo / .traduzir en->pt Hello world
    let targetLang = 'pt';
    let text = args.join(' ').trim();

    // Detectar idioma alvo no início
    if (args[0]?.length === 2 && !/^\d/.test(args[0])) {
      targetLang = args[0].toLowerCase();
      text = args.slice(1).join(' ').trim();
    }

    // Se citou mensagem
    if (!text && msg.quoted) {
      text = msg.quoted.text || msg.quoted.body || '';
    }

    if (!text) {
      return msg.reply(`❌ Use: *${usedPrefix}${command} [idioma] <texto>*\n\nIdiomas: pt, en, es, fr, de, it, ja, zh, ru, ar\nEx: *${usedPrefix}traduzir en Bom dia*\nEx: *${usedPrefix}traduzir pt* (citar mensagem)`);
    }

    try {
      let traduzido = null;
      let detected = null;

      // API 1: delirius translate
      try {
        const res = await fetch(`https://api.delirius.store/other/translate?text=${encodeURIComponent(text)}&to=${targetLang}`);
        const data = await res.json();
        if (data.status && data.result) {
          traduzido = data.result.translated || data.result.text || data.result;
          detected = data.result.language || data.result.from;
        }
      } catch {}

      // API 2: MyMemory
      if (!traduzido) {
        try {
          const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${targetLang}`);
          const data = await res.json();
          if (data.responseData?.translatedText) {
            traduzido = data.responseData.translatedText;
            detected = data.responseData.detectedLanguage || '';
          }
        } catch {}
      }

      if (traduzido) {
        let r = `🔄 *TRADUÇÃO*\n\n`;
        r += `📝 Original: ${text.substring(0, 300)}\n\n`;
        r += `✅ ${targetLang.toUpperCase()}: ${traduzido}`;
        if (detected) r += `\n\n🔍 Detectado: ${detected}`;
        await msg.reply(r);
      } else {
        msg.reply(`❌ Não foi possível traduzir. Tente *.trad* como alternativa.`);
      }
    } catch (e) {
      msg.reply(`❌ Erro na tradução.`);
    }
  }
};
