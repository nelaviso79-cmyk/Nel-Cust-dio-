import fetch from 'node-fetch';
import axios from 'axios';

export default {
  command: ['gerarimg', 'gerarimagem', 'dalle', 'imgai', 'aiimg', 'criarimg'],
  category: 'ia',
  description: 'Gerar imagens com Inteligência Artificial! 🎨',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(
        `🎨 *GERAR IMAGEM COM IA* 🎨\n\n` +
        `▸ Descreva a imagem que quer criar!\n\n` +
        `✏️ *Exemplos:*\n` +
        `▸ *${usedPrefix + command} um gato astronauta no espaço*\n` +
        `▸ *${usedPrefix + command} mapa de Moçambique em estilo pixel*\n` +
        `▸ *${usedPrefix + command} uma praia tropical ao pôr do sol*\n` +
        `▸ *${usedPrefix + command} robô a dançar na lua*\n\n` +
        `💡 Quanto mais detalhado, melhor o resultado!`
      );
    }

    try {
      const { key } = await sock.sendMessage(msg.chat, { text: `🎨 *Gerando imagem...*\n▸ Prompt: ${text}\n⏳ Aguarde...` }, { quoted: msg });
      await msg.react('🎨');

      let imageUrl = null;

      // Método 1: API siputzx - text2img
      try {
        const res = await fetch(`https://api.siputzx.my.id/api/s/text2img?prompt=${encodeURIComponent(text)}`);
        const json = await res.json();
        if (json?.status && json?.data?.url) imageUrl = json.data.url;
        else if (json?.status && json?.url) imageUrl = json.url;
        else if (json?.data) imageUrl = typeof json.data === 'string' ? json.data : json.data.url || json.data.image;
      } catch {}

      // Método 2: API delirius
      if (!imageUrl) {
        try {
          const res = await fetch(`${global.APIs.delirius.url}/ia/dalle?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : json.data.url || json.data.image;
        } catch {}
      }

      // Método 3: API yuki
      if (!imageUrl) {
        try {
          const res = await fetch(`${global.APIs.yuki.url}/ai/dalle?text=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`);
          const json = await res.json();
          if (json?.status && json?.result) imageUrl = typeof json.result === 'string' ? json.result : json.result.url || json.result.image;
        } catch {}
      }

      // Método 4: API vreden
      if (!imageUrl) {
        try {
          const res = await fetch(`${global.APIs.vreden.url}/api/v1/ai/text2img?prompt=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.status && json?.result) imageUrl = typeof json.result === 'string' ? json.result : json.result.url || json.result.image;
        } catch {}
      }

      // Método 5: Pollinations AI (gratuito, sem API key)
      if (!imageUrl) {
        try {
          const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}?width=1024&height=1024&nologo=true`;
          const testRes = await fetch(pollinationsUrl, { method: 'HEAD' });
          if (testRes.ok) imageUrl = pollinationsUrl;
        } catch {}
      }

      if (!imageUrl) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível gerar a imagem. Tente novamente ou reformule o prompt.', edit: key }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, {
        image: { url: imageUrl },
        caption: `🎨 *Imagem Gerada com IA*\n\n▸ Prompt: *${text}*\n▸ Modelo: AI Image Generator\n\n💡 Use *${usedPrefix}gerarimg* para criar mais!`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro ao gerar imagem: *${e.message}*`);
    }
  },
};
