export default {
  command: ['excel-tool', 'excel', 'tabela-gerar'],
  category: 'utilidades',
  description: 'Criação básica de tabelas de texto 📊',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text || !text.includes('|')) {
      return msg.reply(
        `📊 *NEXUS TABLE TOOL* 📊\n\n` +
        `Crie tabelas formatadas rapidamente.\n\n` +
        `▸ *Uso:* ${usedPrefix + command} Título | Col1, Col2 | Val1, Val2\n` +
        `▸ *Exemplo:* ${usedPrefix + command} Vendas | Produto, Preço | Arroz, 50MT | Feijão, 80MT`
      );
    }

    const parts = text.split('|').map(p => p.trim());
    const title = parts[0];
    const headers = parts[1].split(',').map(h => h.trim());
    const rows = parts.slice(2).map(r => r.split(',').map(v => v.trim()));

    let table = `📊 *${title.toUpperCase()}*\n\n`;
    
    // Headers
    table += `┏${headers.map(() => '━'.repeat(10)).join('┳')}┓\n`;
    table += `┃${headers.map(h => h.padEnd(10).substring(0, 10)).join('┃')}┃\n`;
    table += `┣${headers.map(() => '━'.repeat(10)).join('╋')}┫\n`;

    // Rows
    rows.forEach(row => {
      const paddedRow = headers.map((_, i) => (row[i] || '').padEnd(10).substring(0, 10));
      table += `┃${paddedRow.join('┃')}┃\n`;
    });

    table += `┗${headers.map(() => '━'.repeat(10)).join('┻')}┛\n\n`;
    table += `_Gerado por Nexus Intelligence_ 🧠`;

    return msg.reply('```' + table + '```');
  }
};
