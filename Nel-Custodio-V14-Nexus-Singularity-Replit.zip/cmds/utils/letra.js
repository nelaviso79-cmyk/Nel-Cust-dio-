export default {
  command: ['letra', 'lyrics', 'letrademusica'],
  category: 'utilidades',
  description: 'Buscar letra de música pelo nome.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ *Letra de Música* 🎵\n\n✎ Exemplo: *${usedPrefix + command} Imagine John Lennon*`);
    }

    const query = args.join(' ');
    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`https://api.lyrics.ovh/v1/${encodeURIComponent(query)}`);
      
      if (!response.ok) throw new Error('Não encontrada');
      const data = await response.json();
      
      if (!data.lyrics) throw new Error('Sem letra');
      
      // Truncate if too long
      let lyrics = data.lyrics;
      if (lyrics.length > 3000) {
        lyrics = lyrics.substring(0, 3000) + '\n\n▸ ... (letra truncada, muito longa)';
      }

      return msg.reply(`❧ *Letra de Música* 🎵\n\n▸ Música: *${query}*\n\n${lyrics}`);
    } catch (e) {
      return msg.reply(`❧ Não foi possível encontrar a letra de *${query}*.\n▸ Tenta com o formato: "Artista Música"\n✎ Exemplo: *${usedPrefix + command} Anitta Vai Malandra*`);
    }
  },
};
