export default {
  command: ['versiculo', 'biblia', 'versiculo-do-dia'],
  category: 'diversao',
  description: 'Receber um versículo bíblico aleatório para reflexão.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const versiculos = [
      { ref: 'João 3:16', texto: 'Porque Deus amou o mundo de tal maneira que deu o seu Filho unigénito, para que todo aquele que nele crê não pereça, mas tenha a vida eterna.' },
      { ref: 'Filipenses 4:13', texto: 'Tudo posso naquele que me fortalece.' },
      { ref: 'Jeremias 29:11', texto: 'Porque eu sei os planos que tenho para vós, diz o Senhor; planos de paz, e não de mal, para vos dar o fim que esperais.' },
      { ref: 'Provérbios 3:5-6', texto: 'Confia no Senhor de todo o teu coração, e não te estribes no teu próprio entendiz-mento. Em todos os teus caminhos reconhece-o, e ele endireitará as tuas veredas.' },
      { ref: 'Salmos 23:1', texto: 'O Senhor é o meu pastor; nada me faltará.' },
      { ref: 'Romanos 8:28', texto: 'E sabemos que todas as coisas contribuem juntamente para o bem daqueles que amam a Deus.' },
      { ref: 'Isaías 41:10', texto: 'Não temas, porque eu sou contigo; não te assombres, porque eu sou teu Deus; eu te fortaleço, e te ajudo, e te sustento com a destra da minha justiça.' },
      { ref: 'Mateus 7:7', texto: 'Pedi, e dar-se-vos-á; buscai, e encontrareis; batei, e abrir-se-vos-á.' },
      { ref: 'Salmos 46:1', texto: 'Deus é o nosso refúgio e fortaleza, socorro bem presente na angústia.' },
      { ref: 'Provérbios 22:6', texto: 'Instrui o menino no caminho em que deve andar, e até quando envelhecer não se desviará dele.' },
      { ref: 'Gálatas 5:22-23', texto: 'Mas o fruto do Espírito é: amor, gozo, paz, longanimidade, benignidade, bondade, fé, mansidão, temperança.' },
      { ref: '1 Coríntios 13:4', texto: 'O amor é sofredor, é benigno; o amor não é invejoso; o amor não trata com leviandade, não se ensoberbece.' },
      { ref: 'Hebreus 11:1', texto: 'Ora, a fé é o firme fundamento das coisas que se esperam, e a prova das coisas que se não veem.' },
      { ref: 'Salmos 91:1', texto: 'Aquele que habita no esconderijo do Altíssimo, à sombra do Onipotente descansará.' },
      { ref: 'Apocalipse 21:4', texto: 'E Deus limpará de seus olhos toda a lágrima; e não haverá mais morte, nem pranto, nem clamor, nem dor.' },
      { ref: 'Josué 1:9', texto: 'Não to mandei eu? Esforça-te, e tem bom ânimo; não pasmes, nem te espantes; porque o Senhor teu Deus é contigo, por onde quer que andares.' },
      { ref: 'Salmos 37:4', texto: 'Deleita-te também no Senhor, e te concederá os desejos do teu coração.' },
      { ref: 'Romanos 12:12', texto: 'Alegrai-vos na esperança, sede pacientes na tribulação, perseverai na oração.' },
      { ref: 'Provérbios 16:3', texto: 'Confia ao Senhor as tuas obras, e teus pensamentos serão estabelecidos.' },
      { ref: '2 Timóteo 1:7', texto: 'Porque Deus não nos deu o espírito de temor, mas de fortaleza, e de amor, e de moderação.' },
    ];

    const v = versiculos[Math.floor(Math.random() * versiculos.length)];
    return msg.reply(
      `❧ *Versículo do Dia* 📖\n\n` +
      `▸ *${v.ref}*\n\n` +
      `"${v.texto}"\n\n` +
      `▸ Usa *${usedPrefix + command}* para outro versículo!`
    );
  },
};
