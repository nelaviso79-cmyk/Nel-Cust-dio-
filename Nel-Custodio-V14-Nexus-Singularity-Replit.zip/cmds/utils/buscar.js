/**
 * 🌐 BUSCAR — Pesquisa web com resultados múltiplos
 */
import fetch from 'node-fetch';

export default {
  command: ['buscar', 'search', 'procurar', 'pesquisarweb'],
  category: 'utilidades',
  description: 'Pesquisar na web com resultados 🌐',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} <busca>*\nEx: *${usedPrefix}buscar melhor restaurante Maputo*`);

    try {
      let results = null;

      // API 1: delirius google
      try {
        const res = await fetch(`https://api.delirius.store/search/google?query=${encodeURIComponent(text)}`);
        const data = await res.json();
        if (data.status && data.result?.length) results = data.result.slice(0, 8);
      } catch {}

      // API 2: siputzx
      if (!results) {
        try {
          const res = await fetch(`https://app.siputzx.my.id/api/search/google?query=${encodeURIComponent(text)}`);
          const data = await res.json();
          if (data.status && data.data?.length) results = data.data.slice(0, 8);
        } catch {}
      }

      if (!results?.length) return msg.reply(`❌ Sem resultados para "${text}".`);

      let r = `🌐 *RESULTADOS* — ${text}\n\n`;
      results.forEach((item, i) => {
        const titulo = item.title || item.titulo || item.name || '';
        const desc = (item.description || item.desc || item.snippet || '').substring(0, 100);
        const url = item.url || item.link || '';
        r += `${i + 1}. *${titulo}*\n`;
        if (desc) r += `   ${desc}...\n`;
        if (url) r += `   🔗 ${url}\n`;
        r += '\n';
      });

      if (r.length > 4096) r = r.substring(0, 4096) + '...';
      await msg.reply(r.trim());
    } catch (e) {
      msg.reply(`❌ Erro na pesquisa. Tente *.degoogle* como alternativa.`);
    }
  }
};
