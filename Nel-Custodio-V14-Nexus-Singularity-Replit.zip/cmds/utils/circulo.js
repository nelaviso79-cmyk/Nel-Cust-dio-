import fs from 'fs';
import { spawn } from 'child_process';

export default {
  command: ['circulo', 'circle', 'circular', 'arredondar'],
  category: 'utilidades',
  description: 'Recortar imagem em formato circular 🔵',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const quoted = msg.quoted || msg;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!/image/.test(mime)) {
      return msg.reply(`◈ Responda a uma *imagem* com:\n${usedPrefix + command}`);
    }
    
    await msg.react('⏳');
    
    try {
      const buffer = await quoted.download();
      const inputPath = `./tmp/circle_in_${Date.now()}.png`;
      const outputPath = `./tmp/circle_out_${Date.now()}.png`;
      fs.writeFileSync(inputPath, buffer);
      
      const W = 512, H = 512;
      const cx = W / 2, cy = H / 2, r = Math.min(W, H) / 2;
      const alpha = `if(lte((X-${cx})*(X-${cx})+(Y-${cy})*(Y-${cy}),${r*r}),255,0)`;
      
      await new Promise((resolve, reject) => {
        const proc = spawn('ffmpeg', ['-y', '-i', inputPath, '-vf', `scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='${alpha}'`, outputPath]);
        let err = '';
        proc.stderr.on('data', d => err += d.toString());
        proc.on('close', code => code === 0 ? resolve() : reject(new Error(err)));
      });
      
      const result = fs.readFileSync(outputPath);
      fs.unlinkSync(inputPath);
      fs.unlinkSync(outputPath);
      
      await sock.sendMessage(msg.chat, { image: result, caption: '◈ Imagem circular! 🔵' }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro: ${e.message}`);
    }
  }
};
