/**
 * ╔════════════════════════════════════════════════════════════╗
 * ║  🧾 COMANDO M-PESA — Verificação + Registo + Histórico    ║
 * ╚════════════════════════════════════════════════════════════╝
 */

import fetch from 'node-fetch';
import axios from 'axios';
import FormData from 'form-data';
import db from '#db';

function parseAmount(str) {
  if (!str) return null;
  return parseFloat(str.replace(/\s/g, '').replace(/\./g, '').replace(',', '.')) || null;
}

function formatBytes(mb) {
  if (mb >= 1024) return (mb / 1024).toFixed(2) + 'GB';
  return mb + 'MB';
}

export default {
  command: ['mpesa', 'comprovativo', 'verificar', 'comp'],
  category: 'pagamentos',
  description: 'Verificar comprovativo M-Pesa, ver registo e histórico',
  run: async ({ msg, sock, args, usedPrefix, command, isOwner, isAdmins, sender, pushname, from }) => {
    const subcmd = (args[0] || '').toLowerCase();

    // ═══ SUBCOMANDO: AJUDA ═══
    if (!subcmd || subcmd === 'ajuda' || subcmd === 'help') {
      return msg.reply(
        `┌──「 🧾 *M-PESA SISTEMA* 」\n│\n` +
        `│ 🤖 *Detecção automática:* O bot detecta\n│ comprovativos enviados por texto ou foto!\n│\n` +
        `│ 📋 *Comandos disponíveis:*\n│\n` +
        `│ ▸ *${usedPrefix}mpesa* — Este menu\n` +
        `│ ▸ *${usedPrefix}mpesa verificar* — Verificar comp. citado\n` +
        `│ ▸ *${usedPrefix}mpesa registo* — Ver registo de comprovativos\n` +
        `│ ▸ *${usedPrefix}mpesa foto* — Verificar foto de comp.\n` +
        `│ ▸ *${usedPrefix}mpesa texto <msg>* — Verificar texto\n` +
        `│\n` +
        `│ 💡 O bot detecta AUTOMATICAMENTE quando\n` +
        `│ alguém envia um comprovativo M-Pesa!\n` +
        `│ (por texto ou imagem/print)\n` +
        `└───────────────`
      );
    }

    // ═══ SUBCOMANDO: VERIFICAR MENSAGEM CITADA ═══
    if (subcmd === 'verificar' || subcmd === 'ver') {
      if (!msg.quoted) {
        return msg.reply(`⚠️ Responda a uma mensagem de comprovativo com *${usedPrefix}mpesa verificar*`);
      }

      let textToCheck = msg.quoted.text || msg.quoted.body || '';

      // Se a mensagem citada é uma imagem
      if (msg.quoted.message?.imageMessage && !textToCheck) {
        try {
          await msg.react('🔍');
          const buffer = await sock.downloadMediaMessage(msg.quoted).catch(() => null);
          if (buffer) {
            // OCR
            let ocrText = null;
            try {
              const body = new FormData();
              body.append('image', buffer, 'comp.jpg');
              const res = await axios.post(`${global.APIs.delirius.url}/tools/ocr`, body, { headers: body.getHeaders(), timeout: 30000 });
              if (res.data?.status && res.data?.data) ocrText = typeof res.data.data === 'string' ? res.data.data : res.data.data.text;
            } catch {}
            if (!ocrText) try {
              const body = new FormData();
              body.append('image', buffer, 'comp.jpg');
              const res = await axios.post('https://api.siputzx.my.id/api/s/ocr', body, { headers: body.getHeaders(), timeout: 30000 });
              if (res.data?.status && res.data?.data) ocrText = typeof res.data.data === 'string' ? res.data.data : res.data.data.text;
            } catch {}
            if (ocrText) textToCheck = ocrText;
          }
        } catch (e) {
          return msg.reply(`❌ Erro ao processar imagem: ${e.message}`);
        }
      }

      if (!textToCheck) {
        return msg.reply(`❌ Não consegui extrair texto da mensagem citada.`);
      }

      // Verificar com a IA para análise mais profunda
      let aiAnalysis = null;
      try {
        const prompt = `Analisa este texto de comprovativo M-Pesa de Moçambique. Determina se é AUTÊNTICO ou FALSO. Identifica: chave/código, valor, nome destinatário, número, hora, ID transação. Responde em português de forma concisa.\n\nTexto: "${textToCheck}"`;
        const res = await axios.post(`${global.APIs.delirius.url}/ia/gptprompt?text=${encodeURIComponent(prompt)}&prompt=${encodeURIComponent('És um verificador de comprovativos M-Pesa de Moçambique. Analisa comprovativos e determina autenticidade. Responde em português moçambicano.')}`);
        if (res.data?.status && res.data?.data) aiAnalysis = res.data.data;
      } catch {}

      let r = `┌──「 🔍 *VERIFICAÇÃO MANUAL* 」\n│\n│ 📝 Texto analisado:\n│ ${textToCheck.substring(0, 200)}${textToCheck.length > 200 ? '...' : ''}\n│\n`;
      if (aiAnalysis) {
        r += `│ 🤖 *Análise IA:*\n│ ${aiAnalysis}\n│\n`;
      } else {
        r += `│ ⚠️ Análise IA indisponível\n│\n`;
      }
      r += `└───────────────\n💡 Detecção automática ativa — basta enviar o comp.!`;
      if (aiAnalysis && (aiAnalysis.toLowerCase().includes('autêntico') || aiAnalysis.toLowerCase().includes('confirmado'))) {
        const amountMatch = aiAnalysis.match(/(\d+)\s*MT/i);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : 0;
        if (amount > 0) {
          try {
            const db = (await import('#db')).default;
            db.addSale(sender, amount, 'Compra via M-Pesa');
            if (amount >= 100) {
              db.setUser(sender, 'vip', 1);
              db.setUser(sender, 'vipTime', Date.now() + (30 * 86400000));
              await msg.reply('💎 *NEXUS VIP ATIVADO:* O seu pagamento de ' + amount + ' MT foi detectado e o seu acesso VIP foi ativado por 30 dias! 🚀');
            }
          } catch (e) { console.error('Error in auto-sale:', e); }
        }
      }
      return msg.reply(r);
    }

    // ═══ SUBCOMANDO: VERIFICAR POR TEXTO ═══
    if (subcmd === 'texto') {
      const text = args.slice(1).join(' ').trim();
      if (!text) return msg.reply(`⚠️ Escreva o texto do comprovativo:\n*${usedPrefix}mpesa texto Confirmado ABC123...*`);

      let aiAnalysis = null;
      try {
        const prompt = `Analisa este texto de comprovativo M-Pesa de Moçambique. Determina se é AUTÊNTICO ou FALSO. Identifica: chave/código, valor, nome destinatário, número, hora, ID transação. Responde em português de forma concisa.\n\nTexto: "${text}"`;
        const res = await axios.post(`${global.APIs.delirius.url}/ia/gptprompt?text=${encodeURIComponent(prompt)}&prompt=${encodeURIComponent('És um verificador de comprovativos M-Pesa. Responde em português.')}`);
        if (res.data?.status && res.data?.data) aiAnalysis = res.data.data;
      } catch {}
      try {
        if (!aiAnalysis) {
          const res = await fetch(`https://api.siputzx.my.id/api/s/gpt?content=${encodeURIComponent(text + '\n\nAnalisa este comprovativo M-Pesa de Moçambique. É autêntico ou falso? Extrai: chave, valor, nome, número, hora.')}`);
          const json = await res.json();
          if (json?.data) aiAnalysis = json.data;
        }
      } catch {}

      let r = `┌──「 🔍 *VERIFICAÇÃO POR TEXTO* 」\n│\n`;
      if (aiAnalysis) r += `│ 🤖 *Análise:*\n│ ${aiAnalysis}\n│\n`;
      else r += `│ ❌ Análise indisponível\n│\n`;
      r += `└───────────────`;
      if (aiAnalysis && (aiAnalysis.toLowerCase().includes('autêntico') || aiAnalysis.toLowerCase().includes('confirmado'))) {
        const amountMatch = aiAnalysis.match(/(\d+)\s*MT/i);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : 0;
        if (amount > 0) {
          try {
            const db = (await import('#db')).default;
            db.addSale(sender, amount, 'Compra via M-Pesa');
            if (amount >= 100) {
              db.setUser(sender, 'vip', 1);
              db.setUser(sender, 'vipTime', Date.now() + (30 * 86400000));
              await msg.reply('💎 *NEXUS VIP ATIVADO:* O seu pagamento de ' + amount + ' MT foi detectado e o seu acesso VIP foi ativado por 30 dias! 🚀');
            }
          } catch (e) { console.error('Error in auto-sale:', e); }
        }
      }
      return msg.reply(r);
    }

    // ═══ SUBCOMANDO: VERIFICAR FOTO ═══
    if (subcmd === 'foto') {
      if (!msg.quoted || !msg.quoted.message?.imageMessage) {
        return msg.reply(`⚠️ Responda a uma *imagem* de comprovativo com:\n*${usedPrefix}mpesa foto*`);
      }
      try {
        await msg.react('🔍');
        const buffer = await sock.downloadMediaMessage(msg.quoted).catch(() => null);
        if (!buffer) return msg.reply(`❌ Não consegui baixar a imagem.`);

        let ocrText = null;
        try { const body = new FormData(); body.append('image', buffer, 'comp.jpg'); const res = await axios.post(`${global.APIs.delirius.url}/tools/ocr`, body, { headers: body.getHeaders(), timeout: 30000 }); if (res.data?.status && res.data?.data) ocrText = typeof res.data.data === 'string' ? res.data.data : res.data.data.text; } catch {}
        if (!ocrText) try { const body = new FormData(); body.append('image', buffer, 'comp.jpg'); const res = await axios.post('https://api.siputzx.my.id/api/s/ocr', body, { headers: body.getHeaders(), timeout: 30000 }); if (res.data?.status && res.data?.data) ocrText = typeof res.data.data === 'string' ? res.data.data : res.data.data.text; } catch {}

        if (!ocrText) return msg.reply(`❌ Não consegui extrair texto da imagem. Tente com uma imagem mais nítida.`);

        // Análise IA
        let aiAnalysis = null;
        try {
          const prompt = `Analisa este comprovativo M-Pesa extraído de uma imagem. Determina autenticidade. Responde em português conciso.\n\nTexto extraído: "${ocrText}"`;
          const res = await axios.post(`${global.APIs.delirius.url}/ia/gptprompt?text=${encodeURIComponent(prompt)}&prompt=${encodeURIComponent('Verificador de comprovativos M-Pesa. Responde em português.')}`);
          if (res.data?.status && res.data?.data) aiAnalysis = res.data.data;
        } catch {}

        let r = `┌──「 📸 *VERIFICAÇÃO POR FOTO* 」\n│\n│ 📝 *Texto extraído:*\n│ ${ocrText.substring(0, 300)}${ocrText.length > 300 ? '...' : ''}\n│\n`;
        if (aiAnalysis) r += `│ 🤖 *Análise IA:*\n│ ${aiAnalysis}\n│\n`;
        else r += `│ ⚠️ Análise IA indisponível\n│\n`;
        r += `└───────────────`;
      if (aiAnalysis && (aiAnalysis.toLowerCase().includes('autêntico') || aiAnalysis.toLowerCase().includes('confirmado'))) {
        const amountMatch = aiAnalysis.match(/(\d+)\s*MT/i);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : 0;
        if (amount > 0) {
          try {
            const db = (await import('#db')).default;
            db.addSale(sender, amount, 'Compra via M-Pesa');
            if (amount >= 100) {
              db.setUser(sender, 'vip', 1);
              db.setUser(sender, 'vipTime', Date.now() + (30 * 86400000));
              await msg.reply('💎 *NEXUS VIP ATIVADO:* O seu pagamento de ' + amount + ' MT foi detectado e o seu acesso VIP foi ativado por 30 dias! 🚀');
            }
          } catch (e) { console.error('Error in auto-sale:', e); }
        }
      }
        return msg.reply(r);
      } catch (e) {
        return msg.reply(`❌ Erro: ${e.message}`);
      }
    }

    // ═══ SUBCOMANDO: REGISTO ═══
    if (subcmd === 'registo' || subcmd === 'registry' || subcmd === 'historico') {
      if (!isOwner && !isAdmins) {
        return msg.reply(`⚠️ Apenas admins podem ver o registo.`);
      }
      const registry = global.mpesaRegistry;
      if (!registry || registry.size === 0) {
        return msg.reply(`📋 *Registo de Comprovativos*\n\nNenhum comprovativo registado ainda.`);
      }
      let r = `┌──「 📋 *REGISTO M-PESA* 」\n│\n│ 📊 Total: *${registry.size}* comprovativos\n│\n`;
      let count = 0;
      for (const [key, val] of registry) {
        if (count >= 15) { r += `│ ... e mais ${registry.size - 15}\n`; break; }
        const date = val.date ? new Date(val.date).toLocaleString('pt-MZ') : '?';
        r += `│ 🔑 ${key}\n│    💵 ${val.amount?.toFixed(2) || '?'} MT → ${val.destinationName || '?'}\n│    🕒 ${date}\n│\n`;
        count++;
      }
      r += `└───────────────`;
      if (aiAnalysis && (aiAnalysis.toLowerCase().includes('autêntico') || aiAnalysis.toLowerCase().includes('confirmado'))) {
        const amountMatch = aiAnalysis.match(/(\d+)\s*MT/i);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : 0;
        if (amount > 0) {
          try {
            const db = (await import('#db')).default;
            db.addSale(sender, amount, 'Compra via M-Pesa');
            if (amount >= 100) {
              db.setUser(sender, 'vip', 1);
              db.setUser(sender, 'vipTime', Date.now() + (30 * 86400000));
              await msg.reply('💎 *NEXUS VIP ATIVADO:* O seu pagamento de ' + amount + ' MT foi detectado e o seu acesso VIP foi ativado por 30 dias! 🚀');
            }
          } catch (e) { console.error('Error in auto-sale:', e); }
        }
      }
      return msg.reply(r);
    }

    // ═══ SUBCOMANDO DEFAULT: AJUDA ═══
    return msg.reply(
      `┌──「 🧾 *M-PESA SISTEMA* 」\n│\n` +
      `│ 🤖 *Detecção automática ativa!*\n│ Envie um comprovativo por texto\n│ ou foto e o bot detecta.\n│\n` +
      `│ 📋 *Comandos:*\n│ ▸ *${usedPrefix}mpesa* — Menu\n│ ▸ *${usedPrefix}mpesa verificar* — Verificar citado\n│ ▸ *${usedPrefix}mpesa foto* — Verificar imagem citada\n│ ▸ *${usedPrefix}mpesa texto <msg>* — Verificar texto\n│ ▸ *${usedPrefix}mpesa registo* — Ver registo (admin)\n│\n` +
      `└───────────────`
    );
  }
};
