import fetch from 'node-fetch';

export default {
  command: ['resolver', 'unshort', 'unshorten', 'expandir'],
  category: 'utilidades',
  description: 'Resolver/desencurtar links encurtados (bit.ly, tinyurl, etc)',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url) {
      return msg.reply(
        `🔗 *RESOLVER LINK ENCURTADO*\n\n` +
        `▸ Descobre o link original por trás de URLs encurtados!\n\n` +
        `✏️ *Exemplos:*\n` +
        `▸ *${usedPrefix + command} https://bit.ly/abc123*\n` +
        `▸ *${usedPrefix + command} https://tinyurl.com/abc*\n` +
        `▸ *${usedPrefix + command} https://t.co/abc123*\n\n` +
        `📋 *Suportados:* bit.ly, tinyurl, t.co, goo.gl, ow.ly, is.gd, etc.`
      );
    }

    if (!/^https?:\/\//i.test(url)) {
      return msg.reply('❧ O link deve começar com http:// ou https://');
    }

    try {
      await msg.react('🔗');
      let finalUrl = url;
      let redirects = [];
      let currentUrl = url;
      let maxRedirects = 15;

      // Seguir redirecionamentos manualmente
      while (maxRedirects-- > 0) {
        try {
          const response = await fetch(currentUrl, {
            method: 'HEAD',
            redirect: 'manual',
            timeout: 10000,
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
          });

          const location = response.headers.get('location');
          if (location) {
            redirects.push(currentUrl);
            currentUrl = location.startsWith('http') ? location : new URL(location, currentUrl).href;
            finalUrl = currentUrl;
          } else {
            break;
          }
        } catch { break; }
      }

      // Se não resolveu por HEAD, tentar com API
      if (finalUrl === url && url.length < 50) {
        try {
          const res = await fetch(`https://api.delirius.store/tools/unshorten?url=${encodeURIComponent(url)}`);
          const json = await res.json();
          if (json?.status && json?.data?.url) finalUrl = json.data.url;
        } catch {}
      }

      const steps = redirects.length > 0
        ? `\n\n🔗 *Redirecionamentos:*\n${redirects.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n${redirects.length + 1}. ${finalUrl}`
        : '';

      const result = `
🔗 *LINK RESOLvido*\n\n▸ Link encurtado: *${url}*\n▸ Link original: *${finalUrl}*\n▸ Redirecionamentos: *${redirects.length}*${steps}
`.trim();

      await msg.reply(result);
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro ao resolver link: *${e.message}*`);
    }
  },
};
