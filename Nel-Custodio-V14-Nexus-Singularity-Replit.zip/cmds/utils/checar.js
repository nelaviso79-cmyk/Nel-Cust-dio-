// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/checar.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['checar', 'checkurl', 'checklink', 'analisarurl', 'urlinfo'],
  category: 'utilidades',
  description: 'Analisar URL/link — segurança, hosting, NSFW check 🔗',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];

    if (!url) {
      return msg.reply(
        `🔗 *ANALISADOR DE URL* 🔗\n\n` +
        `Analise qualquer link antes de abrir!\n\n` +
        `📋 Como usar:\n` +
        `• *${usedPrefix}${command} https://exemplo.com*\n\n` +
        `🔍 Mostra:\n` +
        `• Se o link é seguro\n` +
        `• Informações de hosting\n` +
        `• Se contém conteúdo NSFW\n` +
        `• Detalhes do domínio`
      );
    }

    // Validate URL
    let validUrl;
    try {
      validUrl = new URL(url).href;
    } catch (e) {
      return msg.reply(`❌ URL inválida! Use formato: *https://exemplo.com*`);
    }

    await msg.reply(`⏳ A analisar *${url}*...`);

    try {
      const results = [];

      // 1. Check URL safety + redirect chain
      try {
        const checkRes = await fetch(
          `https://api.delirius.store/tools/checkurl?url=${encodeURIComponent(validUrl)}`
        );
        const checkData = await checkRes.json();
        if (checkData.status && checkData.result) {
          const r = checkData.result;
          results.push(
            `🔗 *URL INFO*\n` +
            `📋 URL: ${r.url || validUrl}\n` +
            `${r.finalUrl && r.finalUrl !== r.url ? `🔀 Redireciona para: ${r.finalUrl}\n` : ''}` +
            `${r.status ? `📊 Status HTTP: *${r.status}*\n` : ''}` +
            `${r.contentType ? `📄 Content-Type: ${r.contentType}\n` : ''}` +
            `${r.server ? `🖥 Servidor: ${r.server}\n` : ''}` +
            `${r.redirects?.length ? `🔀 Redireções: ${r.redirects.length}\n` : ''}`
          );
        }
      } catch (e) { /* skip */ }

      // 2. Hosting checker
      try {
        const hostRes = await fetch(
          `https://api.delirius.store/tools/hostingchecker?url=${encodeURIComponent(validUrl)}`
        );
        const hostData = await hostRes.json();
        if (hostData.status && hostData.result) {
          const r = hostData.result;
          results.push(
            `🖥 *HOSTING*\n` +
            `${r.hosting || r.provider ? `🏢 Provedor: ${r.hosting || r.provider}\n` : ''}` +
            `${r.ip ? `🌐 IP: ${r.ip}\n` : ''}` +
            `${r.location || r.country ? `📍 Localização: ${r.location || r.country}\n` : ''}` +
            `${r.nameserver ? `📡 NS: ${r.nameserver}\n` : ''}`
          );
        }
      } catch (e) { /* skip */ }

      // 3. Domain info
      try {
        const domainRes = await fetch(
          `https://api.delirius.store/tools/domains?domain=${encodeURIComponent(new URL(validUrl).hostname)}`
        );
        const domainData = await domainRes.json();
        if (domainData.status && domainData.result) {
          const r = domainData.result;
          results.push(
            `🌐 *DOMÍNIO*\n` +
            `${r.domain ? `📛 Domínio: ${r.domain}\n` : ''}` +
            `${r.registrar ? `🏢 Registrar: ${r.registrar}\n` : ''}` +
            `${r.creation_date || r.created ? `📅 Criado: ${r.creation_date || r.created}\n` : ''}` +
            `${r.expiration_date || r.expires ? `⏰ Expira: ${r.expiration_date || r.expires}\n` : ''}` +
            `${r.status ? `🏷 Status: ${r.status}\n` : ''}`
          );
        }
      } catch (e) { /* skip */ }

      // 4. Cloudflare check
      try {
        const cfRes = await fetch(
          `https://api.delirius.store/tools/cloudflare?url=${encodeURIComponent(validUrl)}`
        );
        const cfData = await cfRes.json();
        if (cfData.status && cfData.result) {
          const isCF = cfData.result.cloudflare || cfData.result.isCloudflare;
          results.push(
            `☁️ Cloudflare: ${isCF ? '✔️ Sim' : '❌ Não'}`
          );
        }
      } catch (e) { /* skip */ }

      if (results.length > 0) {
        await msg.reply(
          `🔍 *ANÁLISE DE URL* 🔍\n\n` +
          `🔗 *${validUrl}*\n\n` +
          results.join('\n') +
          `\n━━━━━━━━━━━━━━━━━━\n` +
          `⚠️ Sempre verifique links antes de abrir!`
        );
      } else {
        await msg.reply(
          `🔍 *ANÁLISE DE URL* 🔍\n\n` +
          `🔗 *${validUrl}*\n\n` +
          `❌ Não foi possível obter informações detalhadas.\n` +
          `> O site pode estar offline ou a bloquear a análise.`
        );
      }

    } catch (e) {
      await msg.reply(`❌ Erro ao analisar URL: *${e.message}*`);
    }
  }
};
