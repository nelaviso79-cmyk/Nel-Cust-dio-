export const command = {
  name: 'manga',
  aliases: ['mangasearch', 'mangainfo', 'mangabuscar', 'lermanga'],
  description: 'Busca informações de mangá (título, capítulos, score)',
  category: 'anime',
  usage: '.manga <nome do mangá>',
  example: '.manga One Piece'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o nome do mangá!\n\n💡 *Uso:* .manga <nome>\n📌 *Ex:* .manga One Piece'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '📚', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/search/mangasearch?query=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const chapters = r.chapters || r.chapterCount || 'N/A';
      const info = `📚 *MANGA INFO*

━━━━━━━━━━━━━━━━━━━━

📖 *Título:* ${r.title || r.name || 'N/A'}
${r.titleJp ? `🇯🇵 *JP:* ${r.titleJp}` : ''}
🏷️ *Tipo:* ${r.type || 'Manga'}
⭐ *Score:* ${r.score || r.rating || 'N/A'}
📄 *Capítulos:* ${chapters}
📅 *Status:* ${r.status || 'N/A'}
${r.year ? `📆 *Ano:* ${r.year}` : ''}
${r.author ? `✍️ *Autor:* ${r.author}` : ''}
${r.genres ? `🎭 *Géneros:* ${Array.isArray(r.genres) ? r.genres.join(', ') : r.genres}` : ''}
${r.synopsis || r.description ? `\n💬 *Sinopse:*\n${(r.synopsis || r.description).substring(0, 500)}${(r.synopsis || r.description).length > 500 ? '...' : ''}` : ''}

${r.url || r.link ? `🔗 ${r.url || r.link}` : ''}`;

      const coverUrl = r.cover || r.image || r.thumbnail || r.poster;
      if (coverUrl) {
        try {
          const imgRes = await fetch(coverUrl);
          if (imgRes.ok) {
            const buffer = Buffer.from(await imgRes.arrayBuffer());
            await sock.sendMessage(from, {
              image: buffer,
              caption: info,
              contextInfo: { externalAdReply: { title: r.title || 'Manga', body: `⭐ ${r.score || '?'}`, thumbnailUrl: coverUrl, mediaType: 1 } }
            }, { quoted: msg });
            return;
          }
        } catch (e) { }
      }
      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Manga primary failed:', e.message);
  }

  try {
    const query2 = `query($search:String){Media(search:$search,type:MANGA){id title{romaji english native}chapters status score format genres description startDate{year}coverImage{large}siteUrl}}`;
    const res = await fetch('https://graphql.anilist.co', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: query2, variables: { search: query } })
    });
    const data = await res.json();
    const m = data?.data?.Media;
    if (m) {
      const info = `📚 *MANGA INFO* (AniList)

━━━━━━━━━━━━━━━━━━━━

📖 *${m.title.english || m.title.romaji || 'N/A'}*
${m.title.native ? `🇯🇵 ${m.title.native}` : ''}
🏷️ *Formato:* ${m.format || 'N/A'}
⭐ *Score:* ${m.score || 'N/A'}
📄 *Capítulos:* ${m.chapters || 'N/A'}
📅 *Status:* ${m.status || 'N/A'}
${m.startDate?.year ? `📆 *Ano:* ${m.startDate.year}` : ''}
🎭 *Géneros:* ${m.genres?.join(', ') || 'N/A'}
${m.description ? `\n💬 ${m.description.replace(/<[^>]*>/g, '').substring(0, 500)}` : ''}
🔗 ${m.siteUrl || ''}`;
      if (m.coverImage?.large) {
        try {
          const imgRes = await fetch(m.coverImage.large);
          if (imgRes.ok) {
            const buffer = Buffer.from(await imgRes.arrayBuffer());
            await sock.sendMessage(from, { image: buffer, caption: info }, { quoted: msg });
            return;
          }
        } catch (e) { }
      }
      await sock.sendMessage(from, { text: info }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Manga AniList fallback failed:', e.message);
  }

  await sock.sendMessage(from, { text: `❌ Não encontrei "${query}". Verifica o nome.` }, { quoted: msg });
}
