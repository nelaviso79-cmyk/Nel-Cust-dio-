import uploadImage from '#uploadImage';

export default {
  command: ['tweet', 'faketweet'],
  category: 'diversao',
  description: 'Cria um tweet fativo com texto personalizado',
  botAdmin: false,

  async run({ msg, sock, text, usedPrefix, command }) {
    if (!text) return msg.reply(`❌ Use: *${usedPrefix}${command} texto|\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Eu sou o melhor bot!`);

    const parts = text.split('|');
    const username = parts[0]?.trim() || 'Nel-Aviso';
    const tweetText = parts.slice(1).join('|').trim();

    if (!tweetText) return msg.reply(`❌ Forneça o texto do tweet!\n\nExemplo: ${usedPrefix}${command} Nel-Aviso|Eu sou o melhor bot!`);

    await msg.react('⏳');
    try {
      const api = global.APIs.delirius.url;
      const url = `${api}/canvas/tweet?username=${encodeURIComponent(username)}&text=${encodeURIComponent(tweetText)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API erro: ${res.status}`);
      const buffer = Buffer.from(await res.arrayBuffer());

      await sock.sendMessage(msg.chat, {
        image: buffer,
        caption: `🐦 *Fake Tweet*\n👤 @${username}\n💬 ${tweetText}`
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar tweet: ${e.message}`);
    }
  }
};
