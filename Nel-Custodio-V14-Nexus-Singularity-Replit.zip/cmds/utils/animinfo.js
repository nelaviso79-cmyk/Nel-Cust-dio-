// ╔══════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/animinfo.js
// ╚══════════════════════════════════════════════════════════╝

import fetch from 'node-fetch';

export default {
  command: ['animinfo', 'animeinfo', 'anime', 'mangainfo', 'animesearch'],
  category: 'anime',
  description: 'Informação detalhada de anime/manga com capa e sinopse 🎌',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ').trim();

    if (!query) {
      return msg.reply(
        `🎌 *ANIME/MANGA INFO* 🎌\n\n` +
        `Busque informações detalhadas de qualquer anime ou manga!\n\n` +
        `📋 Exemplos:\n` +
        `• *${usedPrefix}${command} One Piece*\n` +
        `• *${usedPrefix}${command} Naruto*\n` +
        `• *${usedPrefix}${command} Attack on Titan*\n\n` +
        `> Mostra capa, sinopse, episódios, score e mais!`
      );
    }

    await msg.reply(`⏳ A buscar *${query}*...`);

    try {
      // Primary: Delirius anime search
      const res = await fetch(
        `https://api.delirius.store/search/animesearch?q=${encodeURIComponent(query)}`
      );
      const data = await res.json();

      if (data.status && data.result) {
        const results = Array.isArray(data.result) ? data.result : [data.result];
        if (results.length === 0) throw new Error('Não encontrado');

        const a = results[0];
        const info =
          `🎌 *${a.title || a.name || query}*\n\n` +
          `${a.japanese || a.native ? `🇯🇵 Título JP: ${a.japanese || a.native}\n` : ''}` +
          `🏷 Tipo: *${a.type || a.format || 'N/A'}*\n` +
          `📊 Score: *${a.rating || a.score || a.averageScore || 'N/A'}*⭐\n` +
          `🎬 Episódios: *${a.episodes || a.episodeCount || 'N/A'}*\n` +
          `📅 Ano: *${a.year || a.startDate?.year || a.seasonYear || 'N/A'}*\n` +
          `🏷 Status: *${a.status || 'N/A'}*\n` +
          `⏱ Duração: ${a.duration || 'N/A'}\n\n` +
          `${a.genres || a.tags ? `🎭 Gêneros: *${Array.isArray(a.genres || a.tags) ? (a.genres || a.tags).join(', ') : (a.genres || a.tags)}*\n\n` : ''}` +
          `📖 *SINOPSE:*\n${a.description || a.synopsis || a.summary || 'Sem descrição disponível'}\n\n` +
          `${a.url || a.siteUrl ? `🔗 ${a.url || a.siteUrl}` : ''}`;

        const img = a.image || a.cover || a.poster || a.bannerImage || a.coverImage?.large;

        if (img) {
          await sock.sendMessage(msg.chat, {
            image: { url: img },
            caption: info
          }, { quoted: msg });
        } else {
          await msg.reply(info);
        }

        if (results.length > 1) {
          await msg.reply(
            `📋 *Outros resultados:*\n` +
            results.slice(1, 5).map((r, i) => `${i + 2}. ${r.title || r.name} (${r.type || r.format || ''})`).join('\n')
          );
        }
        return;
      }

      // Fallback: AniList
      const alQuery = `
        query ($search: String) {
          Media(search: $search, type: ANIME) {
            title { romaji english native }
            type format status episodes duration
            season seasonYear startDate { year }
            averageScore genres tags { name }
            description(asHtml: false)
            coverImage { large extraLarge }
            bannerImage siteUrl
            studios { nodes { name } }
            nextAiringEpisode { episode timeUntilAiring }
          }
        }`;

      const alRes = await fetch('https://graphql.anilist.co', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: alQuery, variables: { search: query } })
      });
      const alData = await alRes.json();

      if (alData.data?.Media) {
        const m = alData.data.Media;
        const title = m.title.english || m.title.romaji || m.title.native;
        const info =
          `🎌 *${title}*\n\n` +
          `🇯🇵 JP: ${m.title.native || 'N/A'}\n` +
          `🏷 Tipo: *${m.format}*\n` +
          `📊 Score: *${m.averageScore || 'N/A'}*⭐\n` +
          `🎬 Episódios: *${m.episodes || 'N/A'}*\n` +
          `📅 Ano: *${m.seasonYear || m.startDate?.year || 'N/A'}*\n` +
          `🏷 Status: *${m.status}*\n` +
          `⏱ Duração: ${m.duration ? m.duration + 'min' : 'N/A'}\n\n` +
          `🎭 Gêneros: *${(m.genres || []).join(', ')}*\n\n` +
          `🎬 Estúdios: ${(m.studios?.nodes || []).map(s => s.name).join(', ') || 'N/A'}\n\n` +
          `📖 *SINOPSE:*\n${(m.description || 'Sem descrição').replace(/<[^>]*>/g, '')}\n\n` +
          `🔗 ${m.siteUrl || ''}`;

        const img = m.coverImage?.extraLarge || m.coverImage?.large || m.bannerImage;

        if (img) {
          await sock.sendMessage(msg.chat, {
            image: { url: img },
            caption: info
          }, { quoted: msg });
        } else {
          await msg.reply(info);
        }
        return;
      }

      throw new Error('Anime não encontrado');
    } catch (e) {
      await msg.reply(
        `❌ Anime *${query}* não encontrado!\n` +
        `> Tente outro nome ou em inglês.`
      );
    }
  }
};
