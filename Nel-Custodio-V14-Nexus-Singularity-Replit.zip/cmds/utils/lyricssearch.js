export const command = {
  name: 'lyricssearch',
  aliases: ['letramusica', 'letracancion', 'songlyrics', 'lyricsfinder'],
  description: 'Busca letra de música com detalhes do artista',
  category: 'utilidades',
  usage: '.lyricssearch <nome da música>',
  example: '.lyricssearch Bohemian Rhapsody'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  const query = args.join(' ').trim();
  if (!query) {
    return sock.sendMessage(from, {
      text: '❌ Escreve o nome da música!\n\n💡 *Uso:* .lyricssearch <música>\n📌 *Ex:* .lyricssearch Bohemian Rhapsody'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🎵', key: msg.key } });

  try {
    const res = await fetch(`https://api.delirius.store/search/lyrics?query=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (data?.status === 200 && data?.result) {
      const r = data.result;
      const lyrics = r.lyrics || r.text || '';
      const info = `🎵 *LETRA DE MÚSICA*

━━━━━━━━━━━━━━━━━━━━

🎶 *${r.title || r.name || query}*
🎤 *Artista:* ${r.artist || 'N/A'}
${r.album ? `💿 Álbum: ${r.album}` : ''}

━━━━━━━━━━━━━━━━━━━━

${lyrics.substring(0, 2000)}${lyrics.length > 2000 ? '\n\n_📝 Letra truncada (muito longa)_' : ''}

━━━━━━━━━━━━━━━━━━━━
🔗 _Fonte: ${r.source || 'API'}_`;

      await sock.sendMessage(from, {
        text: info,
        contextInfo: {
          externalAdReply: {
            title: r.title || query,
            body: r.artist || '',
            thumbnailUrl: r.image || 'https://cdn-icons-png.flaticon.com/512/2933/2933764.png',
            mediaType: 1
          }
        }
      }, { quoted: msg });
      return;
    }
  } catch (e) {
    console.log('Lyrics search failed:', e.message);
  }

  await sock.sendMessage(from, { text: `❌ Não encontrei a letra de "${query}".` }, { quoted: msg });
}
