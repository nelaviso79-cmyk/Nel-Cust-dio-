export default {
  command: ['filme', 'movie', 'cinema'],
  category: 'utilidades',
  description: 'Buscar informações sobre um filme.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(`❧ *Info de Filme* 🎬\n\n✎ Exemplo: *${usedPrefix + command} Titanic*`);
    }

    const query = args.join(' ');
    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`https://api.omdbapi.com/?t=${encodeURIComponent(query)}&apikey=free&plot=short`);
      
      if (!response.ok) throw new Error('Erro na API');
      const data = await response.json();
      
      if (data.Response === 'False') throw new Error('Não encontrado');
      
      const rating = data.imdbRating || 'N/A';
      const stars = rating !== 'N/A' ? '⭐'.repeat(Math.round(parseFloat(rating) / 2)) : '';

      return msg.reply(
        `❧ *Info de Filme* 🎬\n\n` +
        `▸ Título: *${data.Title}*\n` +
        `▸ Ano: *${data.Year}*\n` +
        `▸ Género: *${data.Genre}*\n` +
        `▸ Director: *${data.Director}*\n` +
        `▸ Actores: *${data.Actors}*\n` +
        `▸ Duração: *${data.Runtime}*\n` +
        `▸ País: *${data.Country}*\n` +
        `▸ IMDB: *${rating}/10* ${stars}\n\n` +
        `▸ Sinopse: ${data.Plot || 'N/A'}`
      );
    } catch (e) {
      return msg.reply(`❧ Não foi possível encontrar informações sobre *${query}*.\n▸ Verifica o nome do filme e tenta novamente.`);
    }
  },
};
