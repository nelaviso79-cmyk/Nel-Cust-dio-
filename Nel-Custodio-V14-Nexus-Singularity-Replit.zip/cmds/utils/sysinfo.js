import os from 'os';
import moment from 'moment-timezone';

export default {
  command: ['sysinfo', 'sistema', 'serverinfo', 'botinfo2'],
  category: 'utilidades',
  description: 'Informações do sistema/servidor onde o bot está a rodar',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const totalMem = os.totalmem();
      const freeMem = os.freemem();
      const usedMem = totalMem - freeMem;
      const memPercent = ((usedMem / totalMem) * 100).toFixed(1);
      const cpuCount = os.cpus().length;
      const cpuModel = os.cpus()[0]?.model || 'Desconhecido';
      const uptime = os.uptime();
      const days = Math.floor(uptime / 86400);
      const hours = Math.floor((uptime % 86400) / 3600);
      const mins = Math.floor((uptime % 3600) / 60);
      const platform = os.platform();
      const arch = os.arch();
      const nodeVersion = process.version;
      const botUptime = process.uptime();
      const botDays = Math.floor(botUptime / 86400);
      const botHours = Math.floor((botUptime % 86400) / 3600);
      const botMins = Math.floor((botUptime % 3600) / 60);
      const processMem = process.memoryUsage();
      const heapUsed = Math.round(processMem.heapUsed / 1024 / 1024);
      const heapTotal = Math.round(processMem.heapTotal / 1024 / 1024);
      const rss = Math.round(processMem.rss / 1024 / 1024);
      const now = moment.tz('Africa/Maputo').format('DD/MM/YYYY HH:mm:ss');

      const text = `
🖥️ *INFORMAÇÕES DO SISTEMA* 🖥️

📋 *Servidor:*
▸ Plataforma: *${platform}*
▸ Arquitectura: *${arch}*
▸ CPU: *${cpuModel.slice(0, 50)}*
▸ Núcleos: *${cpuCount}*
▸ Uptime do Servidor: *${days}d ${hours}h ${mins}m*

💾 *Memória RAM:*
▸ Total: *${formatBytes(totalMem)}*
▸ Usada: *${formatBytes(usedMem)}* (${memPercent}%)
▸ Livre: *${formatBytes(freeMem)}*

🤖 *Bot:*
▸ Node.js: *${nodeVersion}*
▸ Uptime do Bot: *${botDays}d ${botHours}h ${botMins}m*
▸ Heap Usado: *${heapUsed}MB*
▸ Heap Total: *${heapTotal}MB*
▸ RSS: *${rss}MB*
▸ Comandos Carregados: *${global.comandos?.size || 0}*
▸ Conexões Activas: *${global.conns?.length || 0}*

⏰ *Hora actual (Maputo):* ${now}

🔋 *Anti-Sleep:* ${global.keepAliveRunning ? '✅ Ativo' : '❌ Inativo'}
`.trim();

      await msg.reply(text);
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = Number(bytes), unit = 0;
  while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit++; }
  return `${size.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
}
