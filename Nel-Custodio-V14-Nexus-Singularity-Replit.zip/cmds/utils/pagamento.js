/**
 * ╔════════════════════════════════════════════════════════════╗
 * ║  💳 FORMAS DE PAGAMENTO — NEL NET Express                  ║
 * ║  M-Pesa + E-Mola com dados reais do dono                   ║
 * ╚════════════════════════════════════════════════════════════╝
 */

export default {
  command: ['pagamento', 'pagamentos', 'pagar', 'formaspagar', 'comopagar', 'como pagar'],
  category: 'pagamentos',
  description: 'Ver as formas de pagamento NEL NET Express',
  customPrefix: /^(pagamento|pagamentos|pagar|formaspagar|comopagar|como\s*pagar)$/i,
  run: async ({ msg, sock, usedPrefix, command }) => {
    const contas = global.contasDono || {};
    const mpesa = contas.mpesa || {};
    const emola = contas.emola || {};

    let r = `┌──「 💳 *FORMAS DE PAGAMENTO* 」\n│\n`;
    r += `│    *NEL NET EXPRESS* 🌐\n│\n`;
    r += `│ ── *M-PESA* (Vodacom) ──\n│\n`;
    if (mpesa.numero) r += `│ 📱 Número: *${mpesa.numero}*\n`;
    if (mpesa.nome) r += `│ 👤 Titular: *${mpesa.nome}*\n`;
    r += `│ 💲 Taxa: Grátis M-Pesa → M-Pesa\n│\n`;
    r += `│ ── *E-MOLA* (Movitel) ──\n│\n`;
    if (emola.numero) r += `│ 📱 Número: *${emola.numero}*\n`;
    if (emola.nome) r += `│ 👤 Titular: *${emola.nome}*\n`;
    r += `│ 💲 Taxa: Grátis E-Mola → E-Mola\n│\n`;
    r += `│ ─────────────────\n│\n`;
    r += `│ 📝 *COMO COMPRAR:*\n│\n`;
    r += `│ 1️⃣ Efectue a transferência do valor\n`;
    r += `│ 2️⃣ Envie o comprovativo aqui\n`;
    r += `│ 3️⃣ Envie o número Vodacom\n│\n`;
    r += `│ ⚡ Activação: 1 a 2 minutos\n`;
    r += `│ 🕐 Atendimento: 24H / 7 Dias\n│\n`;
    r += `│ 💡 *O bot detecta comprovativos\n│ automaticamente!* Basta enviar.\n│\n`;
    r += `│ 📋 Ver pacotes: *${usedPrefix}megas*\n`;
    r += `│ 🛒 Registar compra: *${usedPrefix}comprar <valor>*\n`;
    r += `│ 🏆 Ranking: *${usedPrefix}ranking*\n`;
    r += `│\n└───────────────\n`;

    return msg.reply(r);
  }
};
