export default {
  command: ['gerarqrcode', 'qrcode2', 'qrgen'],
  category: 'utilidades',
  description: 'Gera um QR Code a partir de um texto ou link.',
  run: async ({ msg, sock, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`❌ O que queres transformar em QR Code?\n\nExemplo: *${usedPrefix + command} https://manus.im*`);

    await msg.react('🔳');
    try {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(text)}`;
      
      await sock.sendMessage(msg.chat, {
        image: { url: qrUrl },
        caption: `🔳 *QR CODE GERADO*\n\n📝 *Conteúdo:* ${text}\n\n> _Nel-Aviso-Bot-Moz_`
      }, { quoted: msg });
      
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar QR Code: ${e.message}`);
    }
  }
};
