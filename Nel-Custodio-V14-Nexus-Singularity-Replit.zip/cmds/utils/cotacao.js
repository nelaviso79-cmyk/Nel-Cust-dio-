export default {
  command: ['cotacao', 'moeda', 'taxa'],
  category: 'utilidades',
  description: 'Ver a cotação de moedas em relação ao Metical moçambicano.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args.length) {
      return msg.reply(
        `❧ *Cotação de Moedas* 💱\n\n` +
        `✎ Exemplos:\n` +
        `> *${usedPrefix + command} USD* - Dólar americano\n` +
        `> *${usedPrefix + command} EUR* - Euro\n` +
        `> *${usedPrefix + command} ZAR* - Rand sul-africano\n` +
        `> *${usedPrefix + command} BRL* - Real brasileiro`
      );
    }

    const currency = args[0].toUpperCase();
    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${currency}`);
      
      if (!response.ok) throw new Error('Moeda não encontrada');
      const data = await response.json();
      
      const mzn = data.rates?.MZN;
      if (!mzn) throw new Error('Sem dados para MZN');

      const popular = ['USD', 'EUR', 'ZAR', 'BRL', 'GBP', 'JPY', 'CNY', 'AOA', 'BWP', 'TZS'];
      let text = `❧ *Cotação de Moedas* 💱\n\n▸ Base: *1 ${currency}* = *${mzn.toFixed(2)} MZN*\n\n`;
      
      if (currency !== 'MZN') {
        text += `▸ Outras cotações:\n`;
        for (const code of popular) {
          if (code !== currency && data.rates[code]) {
            text += `  • 1 ${currency} = ${data.rates[code].toFixed(4)} ${code}\n`;
          }
        }
      }

      text += `\n▸ Actualizado: ${new Date().toLocaleDateString('pt-BR')}`;
      return msg.reply(text);
    } catch (e) {
      return msg.reply(`❧ Não foi possível obter a cotação para *${currency}*.\n▸ Verifica o código da moeda (ex: USD, EUR, ZAR, BRL).`);
    }
  },
};
