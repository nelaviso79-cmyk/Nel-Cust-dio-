export default {
  command: ['piada', 'charada', 'adivinha'],
  category: 'diversao',
  description: 'Receber uma charada ou adivinha para pensar!',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const charadas = [
      { q: 'O que é, o que é: tem coroa mas não é rei, tem escamas mas não é peixe?', a: '🤭 O abacaxi!' },
      { q: 'O que é, o que é: cai em pé e corre deitado?', a: '🤭 A chuva!' },
      { q: 'O que é, o que é: quanto mais seca, mais molha?', a: '🤭 A toalha!' },
      { q: 'O que é, o que é: tem dentes mas não come?', a: '🤭 O pente!' },
      { q: 'O que é, o que é: nasce grande e morre pequeno?', a: '🤭 O lápis!' },
      { q: 'O que é, o que é: passa diante do sol e não faz sombra?', a: '🤭 O vento!' },
      { q: 'O que é, o que é: quanto mais tira, mais fica?', a: '🤭 O buraco!' },
      { q: 'O que é, o que é: tem olhos mas não vê, tem boca mas não fala?', a: '🤭 A batata!' },
      { q: 'O que é, o que é: anda com os pés na cabeça?', a: '🤭 O piolho!' },
      { q: 'O que é, o que é: é leve como uma pluma, mas nem um rei consegue segurá-lo por 5 minutos?', a: '🤭 A respiração!' },
      { q: 'O que é, o que é: tem mãos mas não pode aplaudir?', a: '🤭 O relógio!' },
      { q: 'O que é, o que é: quebra sem tocar?', a: '🤭 A promessa!' },
      { q: 'O que é, o que é: quanto mais se tira, mais se torna grande?', a: '🤭 O buraco!' },
      { q: 'O que é, o que é: entra de molhado e sai de seco?', a: '🤭 O café na chaleira!' },
      { q: 'O que é, o que é: está sempre à frente mas nunca atrás?', a: '🤭 O futuro!' },
    ];

    const charada = charadas[Math.floor(Math.random() * charadas.length)];
    return msg.reply(
      `❧ *Charada* 🧩\n\n` +
      `▸ ${charada.q}\n\n` +
      `▸ Resposta: ||${charada.a}||\n\n` +
      `▸ Usa *${usedPrefix + command}* para outra charada!`
    );
  },
};
