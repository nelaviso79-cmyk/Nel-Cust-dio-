export default {
  command: ['moeda', 'coin', 'caraoucoroa', 'coroa'],
  category: 'diversao',
  description: 'Lançar uma moeda - Cara ou Coroa 🪙',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const resultado = Math.random() < 0.5 ? 'cara' : 'coroa';
    const emoji = resultado === 'cara' ? '👑' : '🦅';
    const animacao = ['🪙 Girando...', '🪙 🪙 🪙', '🪙 A moeda caiu!'][Math.floor(Math.random() * 3)];
    
    return msg.reply(
      `🪙 *CARA OU COROA* 🪙\n\n` +
      `${animacao}\n\n` +
      `▸ Resultado: *${emoji} ${resultado.toUpperCase()}* ${emoji}\n\n` +
      `_🪙 Nel-Aviso-Bot_`
    );
  }
};
