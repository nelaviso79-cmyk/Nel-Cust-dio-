import fetch from 'node-fetch';
import axios from 'axios';
import FormData from 'form-data';
import db from '#db';

export default {
  command: ['gemini', 'google', 'geminiai'],
  category: 'ia',
  description: 'Pergunta algo ao Google Gemini AI',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(`❧ Escreva uma *pergunta* para o *Google Gemini* responder.\n\n▸ Exemplo: *${usedPrefix + command} O que é inteligência artificial?*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const user = db.getUser(msg.sender);
    const username = user?.name || 'usuário';
    const botname = settings.botname || 'Bot';
    const basePrompt = `O teu nome é ${botname}. Tu usas o idioma Português (Português de Moçambique). Responde SEMPRE em Português. Sê amigável com ${username}. ${username}`;
    
    try {
      const { key } = await sock.sendMessage(msg.chat, { text: `⏳ *Gemini AI* está a processar...` }, { quoted: msg });
      await msg.react('🔮');
      let responseText = null;
      let imageUrl = null;

      // Verificar se tem imagem citada
      if (msg.quoted && (msg.quoted.message?.imageMessage || msg.quoted.message?.videoMessage)) {
        const media = msg.quoted.message?.imageMessage || msg.quoted.message?.videoMessage;
        const buffer = await sock.downloadMediaMessage(msg.quoted);
        if (buffer) {
          const body = new FormData();
          const extension = media.mimetype.split('/')[1] || 'jpg';
          body.append('files[]', buffer, `file.${extension}`);
          const uploadRes = await fetch('https://uguu.se/upload.php', { method: 'POST', body, headers: body.getHeaders() });
          const uploadJson = await uploadRes.json();
          imageUrl = uploadJson.files?.[0]?.url ?? null;
        }
      }

      // Método 1: API siputzx com modelo gemini
      try {
        const requestBody = { content: text, user: msg.sender, prompt: basePrompt, model: 'gemini' };
        if (imageUrl) requestBody.imageBuffer = imageUrl;
        const res = await axios.post('https://ai.siputzx.my.id', requestBody);
        if (res.data?.result) responseText = res.data.result;
      } catch {}

      // Método 2: API delirius
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.delirius.url}/ia/gemini?text=${encodeURIComponent(text)}&prompt=${encodeURIComponent(basePrompt)}`);
          const json = await res.json();
          if (json?.status && json?.data) responseText = json.data;
        } catch {}
      }

      // Método 3: API yuki
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.yuki.url}/ai/gemini?text=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`);
          const json = await res.json();
          if (json?.result) responseText = typeof json.result === 'string' ? json.result : json.result.text || JSON.stringify(json.result);
        } catch {}
      }

      // Método 4: API zenzxz
      if (!responseText) {
        try {
          const res = await fetch(`${global.APIs.zenzxz.url}/ai/gemini?text=${encodeURIComponent(text)}`);
          const json = await res.json();
          if (json?.result) responseText = json.result;
        } catch {}
      }

      if (!responseText) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível obter resposta do *Gemini AI*.', edit: key }, { quoted: msg });
      }

      await sock.sendMessage(msg.chat, { text: responseText.trim(), edit: key }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Ocorreu um erro ao executar *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`);
    }
  },
};
