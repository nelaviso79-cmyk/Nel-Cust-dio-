export const command = {
  name: 'levelup',
  aliases: ['lvlup', 'subirnivel', 'uplevel', 'subir'],
  description: 'Gera card visual quando subis de nível',
  category: 'perfil',
  usage: '.levelup',
  example: '.levelup'
};

export default async function ({ sock, msg, args, from, sender, config }) {
  await sock.sendMessage(from, { react: { text: '⬆️', key: msg.key } });

  const db = global.db;
  const userData = db?.users?.[sender] || {};
  const name = userData.name || msg.pushName || 'User';
  const level = userData.level || 1;
  const xp = userData.xp || 0;

  // Calcular próximo nível
  const nextLevel = level + 1;
  const xpNeeded = nextLevel * 500;

  try {
    let avatarUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { avatarUrl = await sock.profilePictureUrl(sender, 'image'); } catch (e) { }

    const res = await fetch(`https://api.delirius.store/canvas/levelup?name=${encodeURIComponent(name)}&url=${encodeURIComponent(avatarUrl)}&level=${level}&nextLevel=${nextLevel}`);

    if (res.ok) {
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(from, {
        image: buffer,
        caption: `⬆️ *LEVEL UP!*\n\n🧑 ${name}\n⭐ Level ${level} → ${nextLevel}\n✨ XP: ${xp.toLocaleString()}/${xpNeeded.toLocaleString()}\n\nParabéns! Continua assim! 🎉`
      }, { quoted: msg });
      return;
    }
  } catch (e) { console.log('Levelup canvas failed:', e.message); }

  // Fallback com ship card como base
  try {
    let avatarUrl = 'https://i.ibb.co/4p4NfKx/default-avatar.png';
    try { avatarUrl = await sock.profilePictureUrl(sender, 'image'); } catch (e) { }

    const res = await fetch(`https://api.delirius.store/canvas/balcard?name=${encodeURIComponent(name)}&url=${encodeURIComponent(avatarUrl)}&background=https://i.ibb.co/4p4NfKx/default-avatar.png&level=LEVEL%20UP%20${level}&xp=${xp}&role=⬆️%20LVL%20${nextLevel}`);

    if (res.ok) {
      const buffer = Buffer.from(await res.arrayBuffer());
      await sock.sendMessage(from, {
        image: buffer,
        caption: `⬆️ *LEVEL UP!*\n\n🧑 ${name}\n⭐ Level ${level} → ${nextLevel}\n✨ XP: ${xp.toLocaleString()}/${xpNeeded.toLocaleString()}\n\nParabéns! 🎉`
      }, { quoted: msg });
      return;
    }
  } catch (e) { console.log('Levelup fallback failed:', e.message); }

  // Fallback texto
  await sock.sendMessage(from, {
    text: `⬆️ *LEVEL UP!* ⬆️

━━━━━━━━━━━━━━━━━━━━

🧑 ${name}
⭐ ${level} → ${nextLevel}
✨ XP: ${xp.toLocaleString()}/${xpNeeded.toLocaleString()}

🎉 Parabéns! Continua assim!

━━━━━━━━━━━━━━━━━━━━`
  }, { quoted: msg });
}
