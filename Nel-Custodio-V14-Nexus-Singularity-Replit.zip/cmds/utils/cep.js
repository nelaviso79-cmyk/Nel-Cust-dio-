export default {
  command: ['cep', 'buscarcep', 'endereço', 'endereco'],
  category: 'utilidades',
  description: 'Buscar endereço pelo CEP (Brasil/Moçambique) 🏠',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    if (!text) return await sock.sendMessage(msg.key.remoteJid, { text: `✳️ Use: ${usedPrefix}${command} <CEP>\n\nExemplo: ${usedPrefix}${command} 01001000` }, { quoted: msg });

    const cep = text.replace(/\D/g, '');
    if (cep.length !== 8) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ CEP deve ter 8 dígitos!' }, { quoted: msg });

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();

      if (data.erro) return await sock.sendMessage(msg.key.remoteJid, { text: '❌ CEP não encontrado!' }, { quoted: msg });

      let result = `🏠 *BUSCA DE ENDEREÇO*\n\n`;
      result += `📮 CEP: *${data.cep}*\n`;
      result += `📍 Rua: *${data.logradouro || 'N/A'}*\n`;
      result += `🏘️ Bairro: *${data.bairro || 'N/A'}*\n`;
      result += `🏙️ Cidade: *${data.localidade}*\n`;
      result += `🗺️ Estado: *${data.uf}*\n`;
      if (data.complemento) result += `📋 Complemento: *${data.complemento}*\n`;
      result += `🔢 IBGE: *${data.ibge}*\n`;

      await sock.sendMessage(msg.key.remoteJid, { text: result }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ Erro ao buscar CEP. Tente novamente.' }, { quoted: msg });
    }
  }
};
