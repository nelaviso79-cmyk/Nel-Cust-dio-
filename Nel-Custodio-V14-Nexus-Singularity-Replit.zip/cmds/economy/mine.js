import db from '#db';
export default {
  command: ['mine', 'minerar'],
  category: 'economy',
  description: 'Realizar trabalhos de minería y ganar coins.',
  run: async ({ msg, sock, usedPrefix }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock?.user?.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId);
    const moedas = botSettings?.currency || 'Coins';
    db.setCreate('chat_users', [msg.chat, msg.sender], 'tools', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastmine', 0);    
    let user = db.getChatUser(msg.chat, msg.sender);
    if (user.tools && typeof user.tools === 'string') {
      try { user.tools = JSON.parse(user.tools); } catch { user.tools = {}; }
    }    
    const staminaConsumed = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    if (user.stamina < staminaConsumed) {
      return msg.reply(`ꕥ Não tens suficiente energía para ir a minerar.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    if (!user.tools?.pico) {
      return msg.reply(`ꕥ Precisas um Picareta para minerar.\n> Compra um na loja com: *${usedPrefix}comprar pico*`);
    }    
    if (user.tools.pico.durability <= 10) {
      delete user.tools.pico;
      db.setChatUser(msg.chat, msg.sender, 'tools', user.tools);
      return msg.reply(`ꕥ Tu Pico partiu-se pelo uso e foi removido do teu inventário.\n> Compra um novo com: *${usedPrefix}comprar pico*`);
    }    
    const remaining = user.lastmine - Date.now();
    if (remaining > 0) {
      return msg.reply(`ꕥ Deves esperar *${msToTime(remaining)}* para minerar de nuevo.`);
    }    
    user.stamina -= staminaConsumed;
    db.setChatUser(msg.chat, msg.sender, 'stamina', user.stamina);    
    const durabilityConsumed = Math.floor(Math.random() * (15 - 1 + 1)) + 1;
    user.tools.pico.durability -= durabilityConsumed;    
    if (user.tools.pico.durability <= 10) {
      delete user.tools.pico;
    }
    db.setChatUser(msg.chat, msg.sender, 'tools', user.tools);    
    user.lastmine = Date.now() + 10 * 60 * 1000;
    db.setChatUser(msg.chat, msg.sender, 'lastmine', user.lastmine);    
    let isLegendary = Math.random() < 0.02;
    let reward, narration, bonusMsg = '';    
    if (isLegendary) {
      reward = Math.floor(Math.random() * (13000 - 11000 + 1)) + 11000;
      narration = 'DESCUBRISTE UN TESORO LEGENDARIO!\n\n';
      bonusMsg = '\nꕥ Recompensa ÉPICA obtenida!';
    } else {
      reward = Math.floor(Math.random() * (9500 - 7000 + 1)) + 7000;
      const scenario = pickRandom(escenarios);
      narration = `En ${scenario}, ${pickRandom(mineria)}`;
      if (Math.random() < 0.1) {
        const bonus = Math.floor(Math.random() * (4500 - 2500 + 1)) + 2500;
        reward += bonus;
        bonusMsg = `\n「✿」 Bonus de minería! Ganhaste *${bonus.toLocaleString()}* ${moedas} extra`;
      }
    }    
    user.coins += reward;
    db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);    
    let caption = `「✿」 ${narration} *${reward.toLocaleString()} ${moedas}*`;
    if (bonusMsg) caption += `\n${bonusMsg}`;
    await sock.reply(msg.chat, caption, msg);
  }
};

function msToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60);
  let minutes = Math.floor((duration / (1000 * 60)) % 60);
  minutes = minutes < 10 ? '0' + minutes : minutes;
  seconds = seconds < 10 ? '0' + seconds : seconds;
  if (minutes === '00') return `${seconds} segundo${seconds > 1 ? 's' : ''}`;
  return `${minutes} minuto${minutes > 1 ? 's' : ''}, ${seconds} segundo${seconds > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

const escenarios = [
  'uma caverna escura e húmida',
  'o cume de uma montanha nevada',
  'un bosque misterioso lleno de raíces',
  'un río cristalino y caudaloso',
  'uma mina abandonada de carvão',
  'as ruínas de um antigo castelo',
  'uma praia deserta com areia dourada',
  'un valle escondido entre colinas',
  'un arbusto espinoso al borde del camino',
  'un tronco hueco en medio da floresta',
];

const mineria = [
  'encontraste un antiguo cofre con',
  'encontraste um saco cheio de',
  'descubriste un saco de',
  'desenterraste moedas antiguas que contienen',
  'partiste uma rocha e dentro estava',
  'cavando profundo, hallaste',
  'entre las raíces, encontraste',
  'dentro de uma caixa esquecida, encontraste',
  'bajo unas piedras, descubriste',
  'entre os escombros de um lugar velho, encontraste',
];