import db from '#db';
export default {
  command: ['heal', 'curar', 'pocion', 'potion'],
  category: 'economy',
  description: 'Curar salud para salir de aventuras.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const chatData = db.getChat(msg.chat);
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }    
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const bot = db.getSettings(botId);
    const currency = bot.currency;    
    const who = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    let healer = db.getChatUser(msg.chat, msg.sender);
    let target = healer;
    if (healer.inventory && typeof healer.inventory === 'string') {
      try { healer.inventory = JSON.parse(healer.inventory); } catch { healer.inventory = {}; }
    }    
    if (who) {
      target = db.getChatUser(msg.chat, who);
      if (!target) {
        return msg.reply(`「✎」 O usuário mencionado não está registado no bot.`);
      }
    }    
    const targetUser = who ? db.getUser(who) : null;
    const cmd = command.toLowerCase();
    if (cmd === 'pocion' || cmd === 'potion') {
      if (!healer.inventory?.pocion || healer.inventory.pocion <= 0) {
        return msg.reply(`ꕥ Não tens poção no teu inventário.\n> Compra uma na loja: ${usedPrefix}shop`);
      }      
      const magiaActual = target.magic || 0;
      const magiaFaltante = 100 - magiaActual;
      if (magiaFaltante <= 0) {
        const maximo = who ? `ꕥ A magia de *${targetUser?.name || who.split('@')[0]}* já está no máximo, Magia atual: ${magiaActual}/100` : `ꕥ Tu magia já está no máximo, Magia atual: ${magiaActual}/100`;
        return msg.reply(maximo);
      }      
      healer.inventory.pocion -= 1;
      if (healer.inventory.pocion <= 0) {
        delete healer.inventory.pocion;
      }
      db.setChatUser(msg.chat, msg.sender, 'inventory', healer.inventory);      
      const magiaRestaurada = Math.min(magiaFaltante, 100);
      target.magic = magiaActual + magiaRestaurada;
      if (who) {
        db.setChatUser(msg.chat, who, 'magic', target.magic);
      } else {
        db.setChatUser(msg.chat, msg.sender, 'magic', target.magic);
      }      
      const info = who ? `ꕥ Usaste uma poção em *${targetUser?.name || who.split('@')[0]}* e restauraste *${magiaRestaurada}* pontos de magia.\n> Magia atual: ${target.magic}/100` : `ꕥ Usaste uma poção e restauraste *${magiaRestaurada}* pontos de magia.\n> Magia atual: ${target.magic}/100`;
      return msg.reply(info);
    }    
    const saludActual = target.health || 0;
    const staminaActual = target.stamina || 0;
    const faltanteSaúde = 100 - saludActual;
    const faltanteStamina = 100 - staminaActual;
    const necesitaCuracion = saludActual < 100 || staminaActual < 100;   
    if (!necesitaCuracion) {
      const maximo = who ? `ꕥ A saúde e stamina de *${targetUser?.name || who.split('@')[0]}* já estão no máximo.\n> Saúde: ${saludActual}/100 | Stamina: ${staminaActual}/100` : `ꕥ Tu salud y stamina já estão no máximo.\n> Saúde: ${saludActual}/100 | Stamina: ${staminaActual}/100`;
      return msg.reply(maximo);
    }    
    const bloquesSaúde = Math.ceil(faltanteSaúde > 0 ? faltanteSaúde / 10 : 0);
    const blocosStamina = Math.ceil(faltanteStamina > 0 ? faltanteStamina / 10 : 0);    
    const custoS = bloquesSaúde * 500;
    const custoSt = blocosStamina * 300;
    const costoTotal = custoS + custoSt;
    const totalFondos = (healer.coins || 0) + (healer.bank || 0);    
    if (totalFondos < costoTotal) {
      const mensajeCostos = [];
      if (faltanteSaúde > 0) mensajeCostos.push(`Saúde: *¥${custoS.toLocaleString()}*`);
      if (faltanteStamina > 0) mensajeCostos.push(`Stamina: *¥${custoSt.toLocaleString()}*`);      
      const fondos = who ? `ꕥ Não tens suficientes ${currency} para curar a *${targetUser?.name || who.split('@')[0]}*.\n> Costos:\n> ${mensajeCostos.join('\n> ')}\n> Total necesario: *¥${costoTotal.toLocaleString()} ${currency}*` : `ꕥ Não tens suficientes ${currency} para curarte.\n> Costos:\n> ${mensajeCostos.join('\n> ')}\n> Total necesario: *¥${costoTotal.toLocaleString()} ${currency}*`;
      return msg.reply(fondos);
    }    
    if ((healer.coins || 0) >= costoTotal) {
      healer.coins -= costoTotal;
      db.setChatUser(msg.chat, msg.sender, 'coins', healer.coins);
    } else {
      const restante = costoTotal - (healer.coins || 0);
      healer.coins = 0;
      healer.bank = Math.max(0, (healer.bank || 0) - restante);
      db.setChatUser(msg.chat, msg.sender, 'coins', 0);
      db.setChatUser(msg.chat, msg.sender, 'bank', healer.bank);
    }    
    const curaciones = [];
    if (faltanteSaúde > 0) {
      target.health = 100;
      if (who) {
        db.setChatUser(msg.chat, who, 'health', 100);
      } else {
        db.setChatUser(msg.chat, msg.sender, 'health', 100);
      }
      curaciones.push(`salud`);
    }
    if (faltanteStamina > 0) {
      target.stamina = 100;
      if (who) {
        db.setChatUser(msg.chat, who, 'stamina', 100);
      } else {
        db.setChatUser(msg.chat, msg.sender, 'stamina', 100);
      }
      curaciones.push(`stamina`);
    }    
    const curadoStr = curaciones.length === 1 ? curaciones[0] : `salud y stamina`;
    const info = who ? `ꕥ Has curado a *${targetUser?.name || who.split('@')[0]}* hasta el máximo nivel de ${curadoStr}.` : `ꕥ Te has curado hasta el máximo nivel de ${curadoStr}.`;    
    let detallesCosto = '';
    if (faltanteSaúde > 0 && faltanteStamina > 0) {
      detallesCosto = `\n> Costo salud: *¥${custoS.toLocaleString()}*\n> Costo stamina: *¥${custoSt.toLocaleString()}*`;
    } else if (faltanteSaúde > 0) {
      detallesCosto = `\n> Costo salud: *¥${custoS.toLocaleString()}*`;
    } else if (faltanteStamina > 0) {
      detallesCosto = `\n> Costo stamina: *¥${custoSt.toLocaleString()}*`;
    }    
    msg.reply(info + detallesCosto + `\n> Saúde actual: ${target.health}/100\n> Stamina atual: ${target.stamina}/100`);
  }
};