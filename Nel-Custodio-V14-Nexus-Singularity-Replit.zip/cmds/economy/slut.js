import db from '#db';
export default {
  command: ['slut', 'prostituirse'],
  category: 'economy',
  description: 'Ganar coins con trabalhos de riesgo.',
  run: async ({ msg, sock, usedPrefix, text }) => {
    const chatId = msg.chat;
    const senderId = msg.sender;    
    const chatData = db.getChat(chatId);
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';    
    const botSettings = db.getSettings(botId);
    db.setCreate('chat_users', [chatId, senderId], 'lastslut', 0);    
    const user = db.getChatUser(chatId, senderId);    
    const cooldown = 5 * 60 * 1000;
    const now = Date.now();
    const remaining = (user.lastslut || 0) - now;
    const currency = botSettings.currency    
    if (remaining > 0) {
      return msg.reply(`✿ Deves esperar *${msToTime(remaining)}* antes de tentar nuevamente.`);
    }    
    const success = Math.random() < 0.5;
    const amount = success ? 
      Math.floor(Math.random() * (6000 - 3500 + 1)) + 3500 : 
      Math.floor(Math.random() * (4000 - 2000 + 1)) + 2000;    
    db.setChatUser(chatId, senderId, 'lastslut', now + cooldown);    
    const winMessages = [
      `Le acaricias el pene a um cliente habitual y ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `El admin se viene en tu boca, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `O admin apalpa-te os peitos, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Te vistieron de neko kwai en publico, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Te haces la Loli do admin por un día, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Te dejas manosear por un extraño por dinheiro, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Eres la maid do admin por un día, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Um gay paga-te para fazeres com ele, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Tu SuggarMommy muere, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Tu SuggarDaddy muere, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Dejaste que un extraño te toque el culo por dinheiro, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Alguém te põe uma coleira e és o seu animal de estimação sexual por uma hora, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Te vistieron de colegiala em público, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Vestiram-te de milf em público, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Los integrantes do grupo te usaron como saco de cum, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Eres la perra de os admins por un día, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Unos Aliens te secuestraron y te usaron cómo objeto sexual, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
      `Un enano se culio tu pierna, ganhou *¥${amount.toLocaleString()} ${currency}*!`,
    ];
    const loseMessages = [
      `Tu energía se fue y no brillaste, perdiendo *¥${amount.toLocaleString()} ${currency}*.`,
      `Cometeste um erro na tua atuação y perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Un cliente malhumorado te causó problemas y perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Tu atuendo no fue bien recibido y perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `O som falhou no meio da tua atuação y perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Um mau dia no clube resultou numa perda de *¥${amount.toLocaleString()} ${currency}*.`,
      `Intentaste cobrarle al cliente equivocado y te denunciaron, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `El admin te bloqueó después do serviço, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Te disfrazaste sin que nadie te pagara, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `A SuggarMommy deixou-te por uma waifu nova, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Un extraño te robó el cosplay antes del evento, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Te manosearon sin pagar nada, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `O gay arrependeu-se no último segundo, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
      `Los Aliens te devolvieron con trauma, perdeu *¥${amount.toLocaleString()} ${currency}*.`,
    ];
    const message = success ? winMessages[Math.floor(Math.random() * winMessages.length)] : loseMessages[Math.floor(Math.random() * loseMessages.length)];
    if (success) {
      db.setChatUser(chatId, senderId, 'coins', (user.coins || 0) + amount);
    } else {
      const total = (user.coins || 0) + (user.bank || 0);
      if (total >= amount) {
        if (user.coins >= amount) {
          db.setChatUser(chatId, senderId, 'coins', (user.coins || 0) - amount);
        } else {
          const remainingLoss = amount - (user.coins || 0);
          db.setChatUser(chatId, senderId, 'coins', 0);
          db.setChatUser(chatId, senderId, 'bank', (user.bank || 0) - remainingLoss);
        }
      } else {
        db.setChatUser(chatId, senderId, 'coins', 0);
        db.setChatUser(chatId, senderId, 'bank', 0);
      }
    }   
    await sock.sendMessage(chatId, { text: `「✿」 ${message}`, mentions: [senderId] }, { quoted: msg });
  }
};

const msToTime = (duration) => {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const pad = (n) => n.toString().padStart(2, '0');  
  if (minutes === 0) {
    return `${pad(seconds)} segundo${seconds !== 1 ? 's' : ''}`;
  }
  return `${pad(minutes)} minuto${minutes !== 1 ? 's' : ''}, ${pad(seconds)} segundo${seconds !== 1 ? 's' : ''}`;
};