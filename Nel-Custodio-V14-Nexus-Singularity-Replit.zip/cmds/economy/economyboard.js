import db from '#db';
export default {
  command: ['economyboard', 'eboard', 'baltop'],
  category: 'economy',
  description: 'Ver o ranking de utilizadores com mais coins.',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const chatId = msg.chat;
    const chatData = db.getChat(chatId);
    if (chatData.adminonly || !chatData.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId);
    const moedas = botSettings.currency;
    try {
      const chatUsers = db.getChatUser(chatId, null, { limit: 1000 });
      const users = [];
      for (const userData of chatUsers || []) {
        const total = (userData.coins || 0) + (userData.bank || 0);
        if (total >= 1000) {
          const userInfo = db.getUser(userData.user_id);
          users.push({ ...userData, jid: userData.user_id, name: userInfo?.name || 'Usuário' });
        }
      }      
      if (users.length === 0) {
        return msg.reply(`ꕥ Não há usuarios no grupo con más de 1,000 ${moedas}.`);
      }      
      const sorted = users.sort((a, b) => ((b.coins || 0) + (b.bank || 0)) - ((a.coins || 0) + (a.bank || 0)));
      const page = parseInt(args[0]) || 1;
      const pageSize = 10;
      const totalPages = Math.ceil(sorted.length / pageSize);      
      if (isNaN(page) || page < 1 || page > totalPages) {
        return msg.reply(`《✧》 La página *${page}* no existe. Hay *${totalPages}* páginas.`);
      }      
      const start = (page - 1) * pageSize;
      const end = start + pageSize;      
      let text = `*✩ EconomyBoard (✿◡‿◡)*\n\n`;
      text += sorted.slice(start, end).map(({ name, coins, bank }, i) => {
        const total = (coins || 0) + (bank || 0);
        return `✩ ${start + i + 1} › *${name}*\n     Total → *¥${total.toLocaleString()} ${moedas}*`;
      }).join('\n');      
      text += `\n\n> ⌦ Página *${page}* de *${totalPages}*`;
      if (page < totalPages) {
        text += `\n> Para ver a próxima página › *${usedPrefix + command} ${page + 1}*`;
      }      
      await sock.sendMessage(chatId, { text }, { quoted: msg });
    } catch (e) {
      await msg.reply(`> An unexpected error occurred ao executar o comando *${usedPrefix + command}*. Please try again or contact support if the issue persists.\n> [Erro: *${e.message}*]`);
    }
  }
};