import db from '#db';
export default {
  command: ['crime', 'crime'],
  category: 'economy',
  description: 'Ganar coins rápido.',
  run: async ({ msg, sock, usedPrefix, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const moedas = (db.getSettings(botId)).currency;
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastcrime', 0);   
    const user = db.getChatUser(msg.chat, msg.sender);
    const remainingTime = user.lastcrime - Date.now();
    if (remainingTime > 0) {
      return msg.reply(`ꕥ Deves esperar *${msToTime(remainingTime)}* antes de tentar nuevamente.`);
    }
    const éxito = Math.random() < 0.4;
    let cantidad;
    if (éxito) {
      cantidad = Math.floor(Math.random() * (7500 - 5500 + 1)) + 5500;
      db.setChatUser(msg.chat, msg.sender, 'coins', (user.coins || 0) + cantidad);
    } else {
      cantidad = Math.floor(Math.random() * (6000 - 4000 + 1)) + 4000;
      const total = (user.coins || 0) + (user.bank || 0);
      if (total >= cantidad) {
        if (user.coins >= cantidad) {
          db.setChatUser(msg.chat, msg.sender, 'coins', (user.coins || 0) - cantidad);
        } else {
          const restante = cantidad - (user.coins || 0);
          db.setChatUser(msg.chat, msg.sender, 'coins', 0);
          db.setChatUser(msg.chat, msg.sender, 'bank', (user.bank || 0) - restante);
        }
      } else {
        cantidad = total;
        db.setChatUser(msg.chat, msg.sender, 'coins', 0);
        db.setChatUser(msg.chat, msg.sender, 'bank', 0);
      }
    }        
    db.setChatUser(msg.chat, msg.sender, 'lastcrime', Date.now() + 7 * 60 * 1000);
    const successMessages = [
      `Hackeaste um caixa automático usando un exploit do sistema y levantaste dinheiro sin alertas, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Te infiltraste como técnico en uma mansão y robaste joyas mientras inspecionavas a rede, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Simulaste uma transferência bancária falsa e obtiveste fundos antes de cancelarem a operação, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Interceptaste um pacote de luxo numa receção corporativa e revendeste-o, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Vaciaste uma carteira esquecida num restaurante sem que ninguém notasse, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Accediste al servidor de uma loja digital y aplicaste descuentos fraudulentos para obtener productos gratis, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Fingiste-te entregador e subtraíste um pacote de coleção sem levantar suspeitas, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Copiaste a chave-mestra de uma galeria de arte e vendeste uma escultura sem registo, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Creaste un sitio falso de caridad y lograste que cientos de personas doaran, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Manipulaste un lector de tarjetas en uma loja local y vaciaste cuentas privadas, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Falsificaste entradas VIP para um evento y accediste a un área con objetos exclusivos, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Enganaste um colecionador vendendo-lhe uma réplica como peça original, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Capturaste a senha de um empresário num café e transferiste fundos para a tua conta, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`,
      `Convenciste um idoso a participar num investimento falso e levantaste as suas poupanças, ganhou *¥${cantidad.toLocaleString()} ${moedas}*!`
    ];
    const failMessages = [
      `Tentaste vender um relógio falso, mas o comprador notou o engano e denunciou-te, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Hackeaste uma conta bancária, mas esqueceste-te de ocultar o teu IP e foste rastreado, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Robaste uma mochila num evento, mas uma câmara oculta capturou todo o ato, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Te infiltraste en uma loja de luxo, pero o sistema silencioso activó o alarme, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Simulaste técnico numa mansão, mas o dono reconheceu-te e chamou a segurança, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Intentaste vender documentos secretos, pero eran falsos y nadie quiso comprarlos, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Planeaste um roubo numa joalharia, mas o guarda nocturno descobriu-te, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Hackeaste um servidor corporativo, mas a tua conexão caiu e rastrearam a tua localização, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Intentaste roubar um carro de luxo, mas o GPS alertou a polícia, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Enganaste um cliente com um contrato falso, mas ele revisou e processou-te, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Trataste de escapar con mercancía robada, pero tropezaste y te atraparon, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`,
      `Hackeaste um cartão de crédito, pero o banco bloqueó a transação, perdeu *¥${cantidad.toLocaleString()} ${moedas}*.`
    ];
    const message = éxito ? pickRandom(successMessages) : pickRandom(failMessages);
    await sock.sendMessage(msg.chat, { text: `「✿」 ${message}` }, { quoted: msg });
  }
};

function msToTime(duration) {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const min = minutes < 10 ? '0' + minutes : minutes;
  const sec = seconds < 10 ? '0' + seconds : seconds;
  return min === '00' ? `${sec} segundo${sec > 1 ? 's' : ''}` : `${min} minuto${min > 1 ? 's' : ''}, ${sec} segundo${sec > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}