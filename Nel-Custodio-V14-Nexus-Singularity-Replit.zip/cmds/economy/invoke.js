import db from '#db';
export default {
  command: ['ritual', 'invoke', 'invocar'],
  category: 'economy',
  description: 'Fazer rituais de invocação.',
  run: async ({ msg, sock, usedPrefix }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }
    const botId = sock?.user?.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId);
    const moedas = botSettings?.currency || 'Coins';
    db.setCreate('chat_users', [msg.chat, msg.sender], 'inventory', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'lastinvoke', 0);    
    let user = db.getChatUser(msg.chat, msg.sender);
    if (user.inventory && typeof user.inventory === 'string') {
      try { user.inventory = JSON.parse(user.inventory); } catch { user.inventory = {}; }
    }    
    const staminaConsumed = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
    if (user.stamina < 10) {
      return msg.reply(`ꕥ Não tens suficiente stamina para realizar un ritual.\n> Usa *${usedPrefix}heal* para curarte.`);
    }    
    const magicConsumed = Math.floor(Math.random() * (12 - 1 + 1)) + 1;
    if (user.magic < 10) {
      return msg.reply(`ꕥ Não tens suficiente magia para realizar un ritual.\n> Usa *${usedPrefix}pocion* para recuperarte.`);
    }    
    const saludConsumed = Math.floor(Math.random() * (15 - 1 + 1)) + 1;
    if (user.health < 10) {
      return msg.reply(`ꕥ Não tens suficiente salud para realizar el ritual.\nUsa *${usedPrefix}heal* para curarte.`);
    }    
    if (!user.inventory?.totem || user.inventory.totem <= 0) {
      return msg.reply(`ꕥ Precisas um Totem de Invocación para realizar el ritual.\n> Compra na loja com: *${usedPrefix}comprar totem*`);
    }    
    const remaining = user.lastinvoke - Date.now();
    if (remaining > 0) {
      return msg.reply(`ꕥ Deves esperar *${msToTime(remaining)}* para invocar otro ritual.`);
    }    
    user.stamina -= staminaConsumed;
    user.magic -= magicConsumed;
    user.health -= saludConsumed;
    user.inventory.totem -= 1;   
    db.setChatUser(msg.chat, msg.sender, 'stamina', user.stamina);
    db.setChatUser(msg.chat, msg.sender, 'magic', user.magic);
    db.setChatUser(msg.chat, msg.sender, 'health', user.health);
    db.setChatUser(msg.chat, msg.sender, 'inventory', user.inventory);    
    user.lastinvoke = Date.now() + 12 * 60 * 1000;
    db.setChatUser(msg.chat, msg.sender, 'lastinvoke', user.lastinvoke);    
    const roll = Math.random();
    let reward = 0;
    let narration = '';
    let bonusMsg = '';    
    if (roll < 0.05) {
      reward = Math.floor(Math.random() * (13000 - 11000 + 1)) + 11000;
      narration = pickRandom(legendaryInvocations);
      bonusMsg = '\nꕥ Recompensa LEGENDARIA obtenida!';
    } else {
      reward = Math.floor(Math.random() * (11000 - 8000 + 1)) + 8000;
      narration = pickRandom(normalInvocations);
      if (Math.random() < 0.15) {
        const bonus = Math.floor(Math.random() * (4500 - 2500 + 1)) + 2500;
        reward += bonus;
        bonusMsg = `\n「✿」 Energía extra! Ganhaste *${bonus.toLocaleString()}* ${moedas} adicionales`;
      }
    }    
    user.coins += reward;
    db.setChatUser(msg.chat, msg.sender, 'coins', user.coins);    
    let caption = `「✿」 ${narration}\nGanhaste *${reward.toLocaleString()} ${moedas}*`;
    if (bonusMsg) caption += `\n${bonusMsg}`;
    await sock.reply(msg.chat, caption, msg);
  }
};

function msToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60);
  let minutes = Math.floor((duration / (1000 * 60)) % 60);
  minutes = minutes < 10 ? '0' + minutes : minutes;
  seconds = seconds < 10 ? '0' + seconds : seconds;
  if (minutes === '00') return `${seconds} segundo${seconds > 1 ? 's' : ''}`;
  return `${minutes} minuto${minutes > 1 ? 's' : ''}, ${seconds} segundo${seconds > 1 ? 's' : ''}`;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

const normalInvocations = [
  'Tu ritual abre un portal y caen riquezas ardientes del vacío',
  'Las velas se consumen y revelan un cofre lleno de moedas antiguas',
  'O círculo de invocação brilha e aparecem gemas reluzentes',
  'Um espírito menor entrega-te um saco de ouro como oferenda',
  'Os cânticos atraem um espectro que deixa riquezas aos teus pés',
  'A lua ilumina o teu altar e revela um tesouro escondido',
  'Un demonio amistoso surge y te paga por tu invocación',
  'El humo del incienso se transforma en moedas brillantes',
  'Los símbolos arcanos vibran y materializan riquezas inesperadas',
  'Un guardián espiritual aparece y te recompensa por tu fe'
];

const legendaryInvocations = [
  'Invocaste um espírito ancestral que te entrega um tesouro lendário!',
  'Un dragón cósmico emerge del ritual y te concede riquezas infinitas',
  'Los dioses antiguos responden y derraman oro celestial sobre ti',
  'Um anjo guardião desce e coloca um cofre sagrado nas tuas mãos',
  'El portal diz-mensional se abre y un tesoro prohibido cae ante ti',
  'La tierra tiembla y un espíritu titánico te entrega riquezas ocultas',
  'Un fénix resucitado deja joyas ardientes como recompensa',
  'Los astros se alinean y un tesoro cósmico aparece en tu altar'
];