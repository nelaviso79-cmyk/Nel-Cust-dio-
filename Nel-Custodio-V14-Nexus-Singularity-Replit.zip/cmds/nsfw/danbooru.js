import fetch from 'node-fetch'
import db from '#db';

export default {
  command: ['danbooru', 'dbooru'],
  category: 'nsfw',
  description: 'Pesquisar imagems en Danbooru.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (!chat.nsfw) return msg.reply(`ꕥ O conteúdo *NSFW* está desativado neste grupo.\n\nUn *administrador* pode ativá-lo com o comando:\n» *${usedPrefix}nsfw on*`)
      if (!args[0]) return sock.reply(msg.chat, `《✧》 Deve especificar tags para buscar\n> Exemplo » *${usedPrefix + command} neko*`, msg)
      await msg.react('🕒')
      const tag = args[0].replace(/\s+/g, '_')
      const url = `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag)}`
      const res = await fetch(url)
      const json = await res.json()
      const mediaList = json.map(p => p?.file_url).filter(u => typeof u === 'string' && /\.(jpe?g|png|gif)$/.test(u))
      if (!mediaList.length) return sock.reply(msg.chat, `《✧》 Nenhum resultado encontrado para ${tag}`, msg)
      const media = mediaList[Math.floor(Math.random() * mediaList.length)]
      const caption = `ꕥ Resultados para » ${tag}`
      await sock.sendMessage(msg.chat, { image: { url: media }, caption, mentions: [msg.sender] })
      await msg.react('✔️')
    } catch (e) {
      await msg.react('✖️')
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`)
    }
  }
}