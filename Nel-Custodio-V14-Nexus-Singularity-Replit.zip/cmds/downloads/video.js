import yts from 'yt-search'
import fetch from 'node-fetch'

const cmd = {
  command: ['video', 'vid', 'ytvideo2', 'baixarvideo'],
  category: 'downloads',
  description: 'Baixar qualquer vídeo do YouTube pelo nome. Não precisa de URL!',

  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      if (!args[0]) {
        return msg.reply(`◈ Escreve o nome do vídeo que queres baixar.\n✎ Exemplo: *${usedPrefix + command} Nelson Freitas*`)
      }

      const query = args.join(' ').trim()
      const { key } = await sock.sendMessage(msg.chat, { text: `⏳ A procurar vídeo: *${query}*...` }, { quoted: msg })

      // Search YouTube
      let search
      try {
        search = await yts(query)
      } catch {
        return sock.sendMessage(msg.chat, { text: '❌ Não foi possível pesquisar no YouTube. Tenta novamente.', edit: key }, { quoted: msg })
      }

      const video = search.videos?.[0] || search.all?.find(v => v.type === 'video')
      if (!video) {
        return sock.sendMessage(msg.chat, { text: `❌ Nenhum vídeo encontrado para: *${query}*`, edit: key }, { quoted: msg })
      }

      const url = video.url
      const title = video.title
      const thumbnail = video.thumbnail || video.image
      const channel = video.author?.name || 'Desconhecido'
      const duration = video.timestamp || video.duration?.seconds ? formatDuration(video.duration.seconds) : 'Desconhecido'
      const views = Number(video.views || 0).toLocaleString('pt-MZ')

      await sock.sendMessage(msg.chat, { text: `⬇️ A baixar: *${title}*\n▸ Canal: ${channel}\n▸ Duração: ${duration}\n▸ Visualizações: ${views}`, edit: key }, { quoted: msg })

      // Try downloading via API
      let videoUrl = null
      let quality = '360p'

      // Method 1: siputzx API
      try {
        const res = await fetch(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(url)}&quality=360`)
        const json = await res.json()
        if (json?.status && json?.data?.dl) {
          videoUrl = json.data.dl
          quality = json.data.quality || quality
        }
      } catch {}

      // Method 2: delirius API
      if (!videoUrl) {
        try {
          const res = await fetch(`https://api.delirius.me/download/ytmp4?url=${encodeURIComponent(url)}&quality=360`)
          const json = await res.json()
          if (json?.status && json?.data?.download) {
            videoUrl = json.data.download
            quality = json.data.quality || quality
          }
        } catch {}
      }

      // Method 3: Yuki API
      if (!videoUrl) {
        try {
          const res = await fetch(`${global.APIs?.yuki?.url || 'https://api.yukio.xyz'}/download/ytmp4?url=${encodeURIComponent(url)}&quality=360&key=${global.APIs?.yuki?.key || ''}`)
          const json = await res.json()
          if (json?.result?.url) {
            videoUrl = json.result.url
            quality = json.result.quality || quality
          }
        } catch {}
      }

      if (!videoUrl) {
        return sock.sendMessage(msg.chat, { text: '❌ Não foi possível obter o link de download. Tenta novamente mais tarde.', edit: key }, { quoted: msg })
      }

      const caption = `◈ *Vídeo Baixado*\n\n▸ Título: *${title}*\n▸ Canal: ${channel}\n▸ Duração: ${duration}\n▸ Qualidade: ${quality}\n▸ Visualizações: ${views}`

      try {
        await sock.sendMessage(msg.chat, {
          video: { url: videoUrl },
          fileName: `${title.replace(/[^\w\s]/g, '')}.mp4`,
          mimetype: 'video/mp4',
          caption,
          contextInfo: {
            externalAdReply: {
              title: title,
              body: channel,
              mediaType: 2,
              thumbnailUrl: thumbnail,
              sourceUrl: url
            }
          }
        }, { quoted: msg })
      } catch {
        // If video too large, send as document
        await sock.sendMessage(msg.chat, {
          document: { url: videoUrl },
          fileName: `${title.replace(/[^\w\s]/g, '')}.mp4`,
          mimetype: 'video/mp4',
          caption
        }, { quoted: msg })
      }

      await msg.react('✅')
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*.\n> [Erro: *${e.message}*]`)
    }
  }
}

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${m}:${String(s).padStart(2, '0')}`
}

export default cmd
