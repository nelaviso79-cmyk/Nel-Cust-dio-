import fetch from 'node-fetch';

export default {
  command: ['kwai', 'kawaii', 'kwaidl'],
  category: 'downloads',
  description: 'Baixar vídeos do Kwai 🟡',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url) {
      return msg.reply(
        `🟡 *KWAI DOWNLOAD* 🟡\n\n` +
        `▸ Baixe vídeos do Kwai!\n\n` +
        `✏️ *Exemplo:*\n` +
        `▸ *${usedPrefix + command} https://www.kwai.com/video/...*`
      );
    }

    if (!/kwai\.com|kuaishou/i.test(url)) {
      return msg.reply('❧ O link não parece ser do Kwai.');
    }

    try {
      await msg.react('🟡');
      const { key } = await sock.sendMessage(msg.chat, { text: '🟡 A baixar do Kwai...' }, { quoted: msg });

      let result = null;
      const apis = [
        `${global.APIs.delirius.url}/download/kwai?url=${encodeURIComponent(url)}`,
      ];

      for (const endpoint of apis) {
        try {
          const res = await fetch(endpoint);
          const json = await res.json();
          if (json.status) {
            const data = json.data || json.result;
            result = {
              title: data?.title || data?.caption || 'Kwai Video',
              url: data?.download || data?.dl || data?.url || data?.video,
              thumbnail: data?.thumbnail || data?.cover || null,
              author: data?.author || data?.user || 'Desconhecido'
            };
            break;
          }
        } catch { continue; }
      }

      if (!result?.url) {
        // Fallback: tentar obter o vídeo diretamente da página
        try {
          const res = await fetch(url, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
          });
          const html = await res.text();
          const videoMatch = html.match(/"src":"(https?:\/\/[^"]+\.mp4[^"]*)"/);
          if (videoMatch) {
            result = {
              title: 'Kwai Video',
              url: videoMatch[1].replace(/\\u002F/g, '/'),
              author: 'Desconhecido'
            };
          }
        } catch {}
      }

      if (!result?.url) {
        return sock.sendMessage(msg.chat, { text: '❧ Não foi possível baixar do Kwai.', edit: key }, { quoted: msg });
      }

      const caption = `🟡 *Kwai Download*\n\n▸ Título: *${result.title}*\n▸ Autor: ${result.author}`;

      await sock.sendMessage(msg.chat, {
        video: { url: result.url },
        fileName: 'kwai.mp4',
        mimetype: 'video/mp4',
        caption
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};
