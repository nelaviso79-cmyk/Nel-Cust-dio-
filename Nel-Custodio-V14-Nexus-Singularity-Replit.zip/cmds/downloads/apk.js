import { search, download } from 'aptoide-scraper'
import { getBuffer } from "#serialize"

export default {
  command: ['apk', 'aptoide', 'apkdl'],
  category: 'downloads',
  description: 'Pesquisar e baixar aplicações do Aptoide.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {    if (!args || !args.length) {
      return msg.reply('《✧》 Por favor, escreve o nome da aplicação.')
    }
    const query = args.join(' ').trim()
    try {
      const searchA = await search(query)
      if (!searchA || searchA.length === 0) {
        return msg.reply('《✧》 Nenhum resultado encontrado.')
      }
      const apkInfo = await download(searchA[0].id)
      if (!apkInfo) {
        return msg.reply('《✧》 Não foi possível obter informações da aplicação.')
      }
      const { name, package: id, size, icon, dllink: downloadUrl, lastup } = apkInfo
      const caption = `✰ ᩧ　𓈒　ׄ　Aptoide 　ׅ　✿\n\n➩ *Nome ›* ${name}\n❖ *Pacote ›* ${id}\n✿ *Última atualização ›* ${lastup}\n☆ *Tamanho ›* ${size}`
      const sizeBytes = parseSize(size)
      if (sizeBytes > 524288000) {
        return msg.reply(`《✧》 O ficheiro é demasiado grande (${size}).\n> Baixe diretamente daqui:\n${downloadUrl}`)
      }
      await sock.sendMessage(msg.chat, { document: { url: downloadUrl }, mimetype: 'application/vnd.android.package-archive', fileName: `${name}.apk`, caption }, { quoted: msg })
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`)
    }
  },
}

function parseSize(sizeStr) {
  if (!sizeStr) return 0
  const parts = sizeStr.trim().toUpperCase().split(' ')
  const value = parseFloat(parts[0])
  const unit = parts[1] || 'B'
  switch (unit) {
    case 'KB': return value * 1024
    case 'MB': return value * 1024 * 1024
    case 'GB': return value * 1024 * 1024 * 1024
    default: return value
  }
}