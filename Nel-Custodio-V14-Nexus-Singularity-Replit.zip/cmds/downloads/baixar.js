import fetch from 'node-fetch'
import { spawn } from 'child_process'
import { Readable } from 'stream'

export default {
  command: ['baixar', 'download', 'dl', 'pegar'],
  category: 'downloads',
  description: 'Baixar música da lista de busca (use buscarmusica primeiro) ⬇️',
  run: async ({ msg, sock, args, usedPrefix, command, text, sender }) => {
    const numero = parseInt(text) - 1;

    if (isNaN(numero) || numero < 0) {
      return msg.reply(
        `⬇️ *BAIXAR MÚSICA* ⬇️\n\n` +
        `◈ Primeiro use *${usedPrefix}buscarmusica* para buscar!\n` +
        `◈ Depois escolha o número:\n\n` +
        `✎ Exemplo: *${usedPrefix}baixar 1*\n` +
        `✎ Exemplo: *${usedPrefix}baixar 3*\n\n` +
        `Ou baixe diretamente pelo nome:\n` +
        `▸ *${usedPrefix}musica nome da música*`
      );
    }

    // Verificar se há busca anterior
    global._musicSearch = global._musicSearch || {};
    const results = global._musicSearch[sender];

    if (!results || !results.length) {
      return msg.reply(
        `◈ Nenhuma busca anterior encontrada!\n\n` +
        `▸ Use *${usedPrefix}buscarmusica nome* primeiro\n` +
        `▸ Ou baixe direto: *${usedPrefix}musica nome da música*`
      );
    }

    if (numero >= results.length) {
      return msg.reply(`◈ Número inválido! Escolha entre 1 e ${results.length}.`);
    }

    const video = results[numero];
    await msg.react('⬇️');

    try {
      // Info do vídeo
      await msg.reply(
        `⬇️ *BAIXANDO...*\n\n` +
        `▸ Título: *${video.title}*\n` +
        `▸ Artista: *${video.channel}*\n` +
        `▸ Duração: *${video.duration}*\n\n` +
        `⏳ Aguarde...`
      );

      const audio = await getAudioFromYoutubei(video.url);

      if (!audio?.buffer?.length) {
        await msg.react('❌');
        return msg.reply('◈ Não foi possível baixar. Tente outro número.');
      }

      // Enviar como documento (para salvar no telefone)
      await sock.sendMessage(msg.chat, {
        document: audio.buffer,
        fileName: audio.name || `${sanitizeFileName(video.title)}.mp3`,
        mimetype: 'audio/mpeg',
        caption: `🎵 *${video.title}*\n▸ Artista: ${video.channel}\n▸ Duração: ${video.duration}\n\n_Nel-Aviso-Bot-Moz_ 🇲🇿`
      }, { quoted: msg });

      // Se menor que 15MB, enviar como áudio também
      if (audio.buffer.length < 15 * 1024 * 1024) {
        await sock.sendMessage(msg.chat, {
          audio: audio.buffer,
          fileName: audio.name || `${sanitizeFileName(video.title)}.mp3`,
          mimetype: 'audio/mpeg'
        }, { quoted: msg });
      }

      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro ao baixar: ${e.message}`);
    }
  }
};

// ─── Funções auxiliares ───

const youtubei = {
  endpoint: 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false',
  visitor_id: 'Cgs4ZmxfcDk4Vnk0VSjLvdrQBjIKCgJJRBIEGgAgXmLfAgrcAjE4LllUPWNsWWh5eHVVeE04N1AzV0tnZzZJeFpkV3lGOEVRNnJaei1DQ3hRTkdHV1NFcjg1MmpVQmZ6UzMtOE5zTVVSZ3EzbHFXUHFRZERyV0M3a2g2TlFEdUZybmJRbjkyc1JGVGxVd3MyZG5RMmFmVG95TlJnTXJReTdMNlRTOEVqcTFhaW5OQnJhOU9uRnJRa01IOGpVTzdiR3UwQVpqdjI0UURqNkdmeE1VcWVZc184cGxfOUNNVExVRG9HQ09sa1NPOUVHZG5CcWdUVzVRZ080OGRyQWxDeVRHUF9MRnhBNjVYZVVRR1FBeGxmU0ZSckhhRHI0cDROLWV2cmp0VDdEc3pKU3Q1clhSYkNmWWQ0YjJqbFN5NVh0ejMyajk5NWdkSGhLU1htcTcydHNGeDNUOW5xZXQ3UlZvV2JNbmNGWDBKTldqbXZyQzg0VHhqY1hCVFlnQ2dLQQ==',
  client_name: 'ANDROID_VR',
  client_version: '1.65.10',
  itag: 18
};

function sanitizeFileName(name = 'audio') {
  return String(name || 'audio')
    .replace(/\.(mp3|m4a|opus|ogg|wav|flac|mp4|webm|mkv)$/i, '')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120) || 'audio';
}

function getVideoId(text = '') {
  const raw = String(text || '').trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(raw)) return raw;
  const patterns = [
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/live\/([a-zA-Z0-9_-]{11})/
  ];
  for (const p of patterns) {
    const m = raw.match(p);
    if (m?.[1]) return m[1];
  }
  return null;
}

async function getYoutubeiStream(video_id) {
  const response = await fetch(youtubei.endpoint, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'X-Goog-Visitor-Id': youtubei.visitor_id
    },
    body: JSON.stringify({
      context: { client: { clientName: youtubei.client_name, clientVersion: youtubei.client_version } },
      videoId: video_id
    })
  });
  const text = await response.text();
  if (!response.ok) throw new Error(`YouTube HTTP ${response.status}`);
  let json;
  try { json = JSON.parse(text); } catch { throw new Error('Resposta inválida'); }
  const formats = json?.streamingData?.formats || [];
  const stream = formats.find(item => Number(item?.itag) === youtubei.itag && item?.url);
  if (!stream?.url) throw new Error('Stream não disponível');
  return {
    url: stream.url,
    title: json?.videoDetails?.title || video_id,
    channel: json?.videoDetails?.author || null,
    duration: json?.videoDetails?.lengthSeconds ? formatDuration(Number(json.videoDetails.lengthSeconds)) : null,
    quality: stream.qualityLabel || '360p'
  };
}

async function getAudioFromYoutubei(url) {
  const video_id = getVideoId(url);
  if (!video_id) throw new Error('ID do vídeo não encontrado');
  const stream = await getYoutubeiStream(video_id);
  const buffer = await convertStreamToMp3(stream.url);
  return {
    buffer, url: stream.url,
    name: `${sanitizeFileName(stream.title || video_id)}.mp3`,
    title: stream.title, channel: stream.channel, duration: stream.duration, quality: stream.quality,
    size: formatBytes(buffer.length), size_bytes: buffer.length, source: `https://youtu.be/${video_id}`
  };
}

async function convertStreamToMp3(streamUrl) {
  const response = await fetch(streamUrl, {
    headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
  });
  if (!response.ok) throw new Error(`Erro: HTTP ${response.status}`);
  if (!response.body) throw new Error('Stream vazio');
  const input_stream = typeof response.body.pipe === 'function' ? response.body : Readable.fromWeb(response.body);
  return new Promise((resolve, reject) => {
    const chunks = [], errors = [];
    let done = false;
    const ffmpeg = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-vn', '-map', 'a:0', '-acodec', 'libmp3lame', '-b:a', '128k', '-ar', '44100', '-f', 'mp3', 'pipe:1'], { stdio: ['pipe', 'pipe', 'pipe'] });
    const fail = error => { if (done) return; done = true; try { input_stream.destroy?.(); } catch {} try { ffmpeg.kill('SIGKILL'); } catch {} reject(error); };
    ffmpeg.stdout.on('data', chunk => chunks.push(chunk));
    ffmpeg.stderr.on('data', chunk => errors.push(chunk));
    ffmpeg.on('error', fail);
    ffmpeg.on('close', code => { if (done) return; done = true; if (code !== 0) { reject(new Error(Buffer.concat(errors).toString().trim() || `FFmpeg código ${code}`)); return; } const buffer = Buffer.concat(chunks); if (!buffer.length) { reject(new Error('Sem áudio')); return; } resolve(buffer); });
    input_stream.on('error', fail);
    ffmpeg.stdin.on('error', error => { if (error?.code !== 'EPIPE') fail(error); });
    input_stream.pipe(ffmpeg.stdin);
  });
}

function formatDuration(seconds = 0) {
  seconds = Math.floor(Number(seconds) || 0);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function formatBytes(bytes = 0) {
  if (!bytes || Number.isNaN(bytes)) return 'Desconhecido';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = Number(bytes), unit = 0;
  while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit++; }
  return `${size.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
}
