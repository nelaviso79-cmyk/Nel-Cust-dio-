import yts from 'yt-search'
import fetch from 'node-fetch'
import { spawn } from 'child_process'
import { Readable } from 'stream'

export default {
  command: ['buscarmusica', 'searchmusic', 'procurarmusica', 'listamusica', 'buscarsom'],
  category: 'downloads',
  description: 'Buscar músicas por nome e escolher qual baixar 🎶',
  run: async ({ msg, sock, args, usedPrefix, command, text, sender }) => {
    if (!text) {
      return msg.reply(
        `🎶 *BUSCAR MÚSICAS* 🎶\n\n` +
        `◈ Escreva o nome da música para ver as opções!\n\n` +
        `✎ Exemplo: *${usedPrefix + command} Burna Boy*\n\n` +
        `◈ Depois escolha com: *${usedPrefix}baixar 1*`
      );
    }

    await msg.react('🔍');

    try {
      const search = await yts(text);
      const videos = search.videos.filter(v => v && v.videoId).slice(0, 10);

      if (!videos.length) {
        await msg.react('❌');
        return msg.reply('◈ Nenhuma música encontrada! Tente outro nome.');
      }

      let resultMsg = `🎶 *RESULTADOS PARA:* "${text}" 🎶\n\n`;
      
      videos.forEach((v, i) => {
        const duration = v.timestamp || '??:??';
        const channel = v.author?.name || 'Desconhecido';
        const views = Number(v.views || 0).toLocaleString('pt-MZ');
        resultMsg += 
          `▸ *${i + 1}.* ${v.title}\n` +
          `   ⏱ ${duration} | 👤 ${channel} | 👁 ${views}\n\n`;
      });

      resultMsg += 
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `◈ Para baixar, use:\n` +
        `▸ *${usedPrefix}baixar 1* (primeira música)\n` +
        `▸ *${usedPrefix}baixar 3* (terceira música)\n\n` +
        `_🎶 Nel-Aviso-Bot-Moz_`;

      // Guardar resultados temporariamente
      global._musicSearch = global._musicSearch || {};
      global._musicSearch[sender] = videos.map(v => ({
        videoId: v.videoId,
        title: v.title,
        url: `https://youtu.be/${v.videoId}`,
        channel: v.author?.name || 'Desconhecido',
        duration: v.timestamp || 'Desconhecido',
        thumbnail: v.thumbnail || v.image || null
      }));

      // Enviar com thumbnail do primeiro resultado
      if (videos[0]?.thumbnail || videos[0]?.image) {
        await sock.sendMessage(msg.chat, {
          image: { url: videos[0].thumbnail || videos[0].image },
          caption: resultMsg
        }, { quoted: msg });
      } else {
        await msg.reply(resultMsg);
      }

      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`◈ Erro na busca: ${e.message}`);
    }
  }
};
