import fetch from 'node-fetch';

export default {
  command: ['spotify', 'sp', 'spotifysearch'],
  category: 'downloads',
  description: 'Pesquisar e baixar músicas do Spotify 🟢',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(
        `🟢 *SPOTIFY DOWNLOAD* 🟢\n\n` +
        `▸ Pesquise e baixe músicas do Spotify!\n▸ Com URL ou pelo nome!\n\n` +
        `🔹 *Com URL:*\n` +
        `▸ *${usedPrefix + command} https://open.spotify.com/track/...*\n\n` +
        `🔹 *Sem URL (busca pelo nome):*\n` +
        `▸ *${usedPrefix + command} Burna Boy Last Last*\n` +
        `▸ *${usedPrefix + command} Eminem Lose Yourself*`
      );
    }

    const isSpotifyUrl = /spotify\.com\/track\//i.test(text);

    try {
      await msg.react('🟢');

      if (isSpotifyUrl) {
        // Baixar por URL
        const { key } = await sock.sendMessage(msg.chat, { text: '🟢 A baixar do Spotify...' }, { quoted: msg });
        
        let result = null;
        const apis = [
          `${global.APIs.delirius.url}/download/spotify?url=${encodeURIComponent(text)}`,
          `${global.APIs.yuki.url}/dl/spotify?url=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`
        ];

        for (const endpoint of apis) {
          try {
            const res = await fetch(endpoint);
            const json = await res.json();
            if (json.status) {
              const data = json.data || json.result;
              result = {
                title: data?.title || data?.name || 'Spotify Track',
                artist: data?.artist || data?.artists || 'Desconhecido',
                album: data?.album || 'N/A',
                duration: data?.duration || 'N/A',
                url: data?.download || data?.dl || data?.url,
                cover: data?.cover || data?.thumbnail || data?.image || null
              };
              break;
            }
          } catch { continue; }
        }

        if (!result?.url) {
          return sock.sendMessage(msg.chat, { text: '❧ Não foi possível baixar do Spotify.', edit: key }, { quoted: msg });
        }

        const caption = `🟢 *Spotify Download*\n\n▸ Título: *${result.title}*\n▸ Artista: *${result.artist}*\n▸ Álbum: ${result.album}\n▸ Duração: ${result.duration}`;

        await sock.sendMessage(msg.chat, {
          audio: { url: result.url },
          fileName: `${result.title.replace(/[^\\w\\s]/g, '')}.mp3`,
          mimetype: 'audio/mpeg',
          contextInfo: result.cover ? {
            externalAdReply: {
              title: result.title,
              body: result.artist,
              mediaType: 2,
              thumbnailUrl: result.cover,
              sourceUrl: text
            }
          } : undefined
        }, { quoted: msg });

        // Enviar como documento também
        await sock.sendMessage(msg.chat, {
          document: { url: result.url },
          fileName: `${result.title.replace(/[^\\w\\s]/g, '')}.mp3`,
          mimetype: 'audio/mpeg',
          caption
        }, { quoted: msg });

      } else {
        // Buscar pelo nome
        const { key } = await sock.sendMessage(msg.chat, { text: `🔍 A procurar no Spotify: *${text}*...` }, { quoted: msg });
        
        let searchResults = null;
        const apis = [
          `${global.APIs.delirius.url}/search/spotify?text=${encodeURIComponent(text)}`,
          `${global.APIs.yuki.url}/search/spotify?query=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`
        ];

        for (const endpoint of apis) {
          try {
            const res = await fetch(endpoint);
            const json = await res.json();
            if (json.status) {
              searchResults = json.data || json.result;
              break;
            }
          } catch { continue; }
        }

        if (!searchResults || (Array.isArray(searchResults) && searchResults.length === 0)) {
          return sock.sendMessage(msg.chat, { text: `❧ Nenhum resultado no Spotify para *${text}*.`, edit: key }, { quoted: msg });
        }

        const tracks = (Array.isArray(searchResults) ? searchResults : [searchResults]).slice(0, 5);
        let listText = `🟢 *RESULTADOS SPOTIFY* 🟢\n\n▸ Busca: *${text}*\n\n`;

        for (let i = 0; i < tracks.length; i++) {
          const t = tracks[i];
          listText += `${i + 1}. 🎵 *${t.title || t.name}*\n`;
          listText += `   ▸ Artista: ${t.artist || t.artists || 'N/A'}\n`;
          listText += `   ▸ Álbum: ${t.album || 'N/A'}\n`;
          listText += `   ▸ Duração: ${t.duration || 'N/A'}\n`;
          if (t.url) listText += `   ▸ 🔗 ${t.url}\n`;
          listText += `\n`;
        }

        listText += `\n💡 Para baixar, use:\n▸ *${usedPrefix}dl <link_do_spotify>*\n▸ *${usedPrefix}musica ${text}*`;

        await sock.sendMessage(msg.chat, { text: listText, edit: key }, { quoted: msg });
      }

      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};
