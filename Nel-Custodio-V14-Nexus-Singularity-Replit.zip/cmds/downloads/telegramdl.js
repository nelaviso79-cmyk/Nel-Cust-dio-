import fetch from 'node-fetch';

export default {
  command: ['telegramdl', 'tgdl', 'telegram'],
  category: 'downloads',
  description: 'Baixar vídeos/ficheiros de canais do Telegram ✈️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url) {
      return msg.reply(
        `✈️ *TELEGRAM DOWNLOAD* ✈️\n\n` +
        `▸ Baixe conteúdo de canais públicos do Telegram!\n\n` +
        `✏️ *Exemplo:*\n` +
        `▸ *${usedPrefix + command} https://t.me/canal/123*\n\n` +
        `⚠️ Apenas canais públicos!`
      );
    }

    if (!/t\.me|telegram\./i.test(url)) {
      return msg.reply('❧ O link não parece ser do Telegram.');
    }

    try {
      await msg.react('✈️');
      const { key } = await sock.sendMessage(msg.chat, { text: '✈️ A baixar do Telegram...' }, { quoted: msg });

      let result = null;

      // Método 1: API delirius
      try {
        const res = await fetch(`${global.APIs.delirius.url}/download/telegram?url=${encodeURIComponent(url)}`);
        const json = await res.json();
        if (json.status) {
          const data = json.data || json.result;
          result = {
            title: data?.title || 'Telegram Content',
            url: data?.download || data?.dl || data?.url,
            type: data?.type || 'document',
            filename: data?.filename || 'telegram_file',
            mimetype: data?.mimetype || 'application/octet-stream'
          };
        }
      } catch {}

      // Método 2: Obter embed do Telegram
      if (!result) {
        try {
          const embedUrl = url.replace(/t\.me/, 't.me') + '?embed=1';
          const res = await fetch(embedUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
          });
          const html = await res.text();

          // Extrair vídeo
          const videoMatch = html.match(/og:video:secure_url" content="([^"]+)"/) || html.match(/og:video" content="([^"]+)"/);
          if (videoMatch) {
            result = {
              title: 'Telegram Video',
              url: videoMatch[1],
              type: 'video',
              filename: 'telegram.mp4',
              mimetype: 'video/mp4'
            };
          }

          // Extrair imagem
          if (!result) {
            const imgMatch = html.match(/og:image" content="([^"]+)"/);
            if (imgMatch) {
              result = {
                title: 'Telegram Image',
                url: imgMatch[1],
                type: 'image',
                filename: 'telegram.jpg',
                mimetype: 'image/jpeg'
              };
            }
          }
        } catch {}
      }

      if (!result?.url) {
        return sock.sendMessage(msg.chat, {
          text: '❧ Não foi possível baixar do Telegram.\n▸ Apenas canais públicos são suportados.',
          edit: key
        }, { quoted: msg });
      }

      const caption = `✈️ *Telegram Download*\n\n▸ Tipo: *${result.type}*`;

      if (result.type === 'video') {
        await sock.sendMessage(msg.chat, {
          video: { url: result.url },
          fileName: result.filename,
          mimetype: 'video/mp4',
          caption
        }, { quoted: msg });
      } else if (result.type === 'image') {
        await sock.sendMessage(msg.chat, {
          image: { url: result.url },
          caption
        }, { quoted: msg });
      } else {
        await sock.sendMessage(msg.chat, {
          document: { url: result.url },
          fileName: result.filename,
          mimetype: result.mimetype,
          caption
        }, { quoted: msg });
      }

      await msg.react('✅');
    } catch (e) {
      await msg.reply(`> Erro: *${e.message}*`);
    }
  },
};
