export default {
  command: ['antiraid', 'protecao', 'escudo'],
  category: 'moderacao',
  description: 'Ativa o escudo inteligente contra ataques e invasores.',
  admin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const action = args[0]?.toLowerCase();
    
    if (!action || !['on', 'off'].includes(action)) {
      return msg.reply(`🛡️ *SISTEMA ANTI-RAID* 🛡️\n\n▸ Estado Atual: *${global.db.data.chats[msg.chat]?.antiraid ? '✅ ATIVO' : '❌ INATIVO'}*\n\n▸ Para ativar: *${usedPrefix + command} on*\n▸ Para desativar: *${usedPrefix + command} off*\n\n💡 O Anti-Raid bloqueia a entrada de bots invasores e expulsa automaticamente quem enviar links de forma massiva.`);
    }

    if (!global.db.data.chats[msg.chat]) global.db.data.chats[msg.chat] = {};
    
    if (action === 'on') {
      global.db.data.chats[msg.chat].antiraid = true;
      await msg.reply('🛡️ *ESCUDO ANTI-RAID ATIVADO!* O grupo agora está sob proteção máxima do Nel-Aviso-Bot.');
    } else {
      global.db.data.chats[msg.chat].antiraid = false;
      await msg.reply('🔓 *ESCUDO ANTI-RAID DESATIVADO.* O grupo está agora vulnerável.');
    }
    
    await msg.react('🛡️');
  }
};
