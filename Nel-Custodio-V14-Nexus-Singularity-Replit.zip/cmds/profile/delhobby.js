import db from '#db';
export default {
  command: ['delpasatiempo', 'removehobby'],
  category: 'perfil',
  description: 'Eliminerar o seu passatempo do perfil.',
  run: async ({ msg }) => {
    const user = db.getUser(msg.sender);    
    if (!user.pasatiempo || user.pasatiempo === 'Não definido') {
      return msg.reply('《✧》 Não tem nenhum passatempo definido.');
    }
    db.setUser(msg.sender, 'pasatiempo', '');
    return msg.reply(`✎ Foi eliminado seu passatempo.`);
  },
};