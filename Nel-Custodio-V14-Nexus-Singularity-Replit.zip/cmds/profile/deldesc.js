import db from '#db';
export default {
  command: ['deldescription', 'deldesc'],
  category: 'perfil',
  description: 'Eliminerar a sua descrição de perfil.',
  run: async ({ msg }) => {
    const user = db.getUser(msg.sender);
    if (!user.description) {
      return msg.reply(`《✧》 Não tem uma descrição definida.`);
    }    
    db.setUser(msg.sender, 'description', '');
    return msg.reply(`✎ Sua descrição foi eliminada.`);
  },
};