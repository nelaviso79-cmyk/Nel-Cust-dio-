import moment from 'moment';
import db from '#db';
moment.locale('es');

export default {
  command: ['setbirth'],
  category: 'perfil',
  description: 'Definir sua data de aniversário.',
  run: async ({ msg, args, usedPrefix, command, text }) => {
    const user = db.getUser(msg.sender);
    const currentYear = new Date().getFullYear();
    const input = args.join(' ');    
    if (!input) return msg.reply(`《✧》 Deve inserir uma data válida para tu aniversário.\n✐ Exemplos:\n> ${usedPrefix + command} *01/01/2000* (dia/mes/año)\n> ${usedPrefix + command} *01/01* (dia/mes/año)`);
    const birth = validarDataNacimiento(input, currentYear, usedPrefix, command);
    if (typeof birth === 'string' && birth.startsWith('✦'))
      return msg.reply(birth);
    if (!birth)
      return msg.reply(`《✧》 Data inválida. Usa › *${usedPrefix + command} 01/01/2000*`);
    db.setUser(msg.sender, 'birth', birth);
    return msg.reply(`✎ Foi definido sua data de nascimento como: *${birth}*`);
  },
};

function validarDataNacimiento(text, currentYear, usedPrefix, command) {
  const formatos = ['DD/MM/YYYY', 'DD/MM', 'D MMM', 'D MMM YYYY'];
  let fecha = null;
  for (const formato of formatos) {
    const f = moment(text, formato, true);
    if (f.isValid()) {
      fecha = f;
      break;
    }
  }
  if (!fecha) return null;
  if (!/\d{4}/.test(text)) {
    fecha.year(currentYear);
  }
  const año = fecha.year();
  const edad = currentYear - año;
  if (año > currentYear) {
    return `✦ O ano não pode ser maior que ${currentYear}. Exemplo: ${usedPrefix + command} 01/12/${currentYear}`;
  }
  if (edad > 120) {
    return `✦ A data definida é inválida.`;
  }
  if (!fecha.isValid()) return null;
  const diaSemana = fecha.format('dddd');
  const dia = fecha.date();
  const mes = fecha.format('MMMM');
  return `${diaSemana}, ${dia} de ${mes} de ${año}`;
}