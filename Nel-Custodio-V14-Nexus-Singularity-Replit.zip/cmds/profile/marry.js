import db from '#db';

let proposals = {};

export default {
  command: ['marry', 'casar'],
  category: 'perfil',
  description: 'Casar com alguém.',
  run: async ({ msg, sock, usedPrefix, command, text }) => {
    const chatId = msg.chat;
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const proposer = msg.sender;
    const proposee = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
    const proposerUser = db.getUser(proposer);
    const proposeeUser = db.getUser(proposee);
    if (!proposee) return sock.reply(msg.chat, `《✧》 Deve mencionar a alguém para aceitar ou propor casamento.\n> Exemplo » *${usedPrefix + command}* @${idBot.split('@')[0]}`, msg, { mentions: [idBot] });
    if (proposer === proposee) return msg.reply(`《✧》 Não podes propor casamento a ti ${proposerUser.genre === 'Mulher' ? 'mesma' : proposerUser.genre === 'Homem' ? 'mesmo' : 'mesmx'}`);      
    if (!proposerUser || !proposeeUser) {
      return msg.reply('《✧》 Uno de os usuários não está registado no bot.');
    }    
    if (proposerUser?.marry) {
      const partner = db.getUser(proposerUser.marry);
      return msg.reply(`《✧》 Já estás ${partner.genre === 'Mulher' ? 'casada' : partner.genre === 'Homem' ? 'casado' : 'casadx'} com *${partner?.name || 'alguém'}*.`);
    }    
    if (proposeeUser?.marry) {
      const partner = db.getUser(proposeeUser.marry);
      return msg.reply(`《✧》 *${proposeeUser.name || proposee.split('@')[0]}* já está ${partner.genre === 'Mulher' ? 'casada' : partner.genre === 'Homem' ? 'casado' : 'casadx'} com *${partner?.name || 'alguém'}*.`);
    }    
    setTimeout(() => {
      delete proposals[proposer];
    }, 120000);    
    if (proposals[proposee] === proposer) {
      delete proposals[proposee];
      db.setUser(proposer, 'marry', proposee);
      db.setUser(proposee, 'marry', proposer);
      return msg.reply(`✩.･:｡≻───── ⋆♡⋆ ─────.•:｡✩\nCasaram-se! ฅ^•ﻌ•^ฅ*:･ﾟ✧\n\n*•.¸♡ ${proposerUser.genre === 'Mulher' ? 'Esposa' : proposerUser.genre === 'Homem' ? 'Esposo' : 'Esposx'} ${proposerUser.name || proposer.split('@')[0]} ♡¸.•*\n*•.¸♡ ${proposeeUser.genre === 'Mulher' ? 'Esposa' : proposeeUser.genre === 'Homem' ? 'Esposo' : 'Esposx'} ${proposeeUser.name || proposee.split('@')[0]} ♡¸.•*\n\n\`Desfrutem da lua de mel\`\n\n✩.･:｡≻───── ⋆♡⋆ ─────.•:｡✩`);
    } else {
      proposals[proposer] = proposee;
      return sock.sendMessage(chatId, { text: `♡ ${proposeeUser.name || proposee.split('@')[0]}, o usuário ${proposerUser.name || proposer.split('@')[0]} enviou-lhe uma proposta de casamento, aceita? •(=^●ω●^=)•\n\n⚘ *Responde com:*\n> ● *_${usedPrefix + command} ${proposerUser.name || proposer.split('@')[0]}_* para confirmar.\n> ● A proposta expirará em 2 minutos.`, mentions: [proposer, proposee] }, { quoted: msg });
    }
  }
};
