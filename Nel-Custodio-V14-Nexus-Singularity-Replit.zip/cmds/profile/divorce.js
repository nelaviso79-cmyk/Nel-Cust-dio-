import db from '#db';
export default {
  command: ['divorce'],
  category: 'perfil',
  description: 'Divorciar-se do seu parceiro.',
  run: async ({ msg }) => {
    const user = db.getUser(msg.sender);
    const partnerId = user?.marry;    
    if (!partnerId) {
      return msg.reply(`《✧》 Você não está ${user.genre === 'Mulher' ? 'casada' : user.genre === 'Homem' ? 'casado' : 'casadx'} com ninguém.`);
    }    
    const partner = db.getUser(partnerId);
    db.setUser(msg.sender, 'marry', '');
    db.setUser(partnerId, 'marry', '');    
    return msg.reply(`✎ *${user?.name || msg.sender.split('@')[0]}* te has divorciado de *${partner?.name || partnerId.split('@')[0]}*.`);
  },
};
