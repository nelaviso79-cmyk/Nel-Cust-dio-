import db from '#db';
export default {
  command: ['afk'],
  category: 'perfil',
  description: 'Activar o modo ausente (AFK).',
  run: async ({ msg, sock, args }) => {
    db.setChatUser(msg.chat, msg.sender, 'afk', Date.now());
    db.setChatUser(msg.chat, msg.sender, 'afkReason', args.join(' '));    
    const userData = db.getUser(msg.sender);
    const nombre = userData?.name || 'Usuário';
    const motivo = args.length ? `${args.join(' ')}` : 'Sin Especificar!';    
    return await sock.reply(msg.chat, `ꕥ O Usuário *${nombre}* estará AFK.\n> ○ Motivo » *${motivo}*`, msg);
  }
};