import { normalizeJid, resolveParticipantJid, resolveJidSync, deleteCachedMeta, getCachedMeta, setCachedMeta } from '#serialize';
import chalk from 'chalk';
import moment from 'moment-timezone';
import db from '#db';

function getGroupAdmins(participants) {
  return (participants ?? []).filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.id).filter(Boolean);
}

function resolveEventParticipant(p, sock) {
  if (typeof p === 'string') return resolveJidSync(p, sock) || p;
  return resolveParticipantJid(p, sock) || normalizeJid(p.id || p.phoneNumber || p.jid || p.lid || '') || '';
}

export default async (sock, msg) => {
  sock.ev.on('group-participants.update', async (anu) => {
    try {
      if (['add', 'remove', 'leave', 'promote', 'demote'].includes(anu.action)) {
        deleteCachedMeta(anu.id);
      }
      const metadata = await (async () => {
        const cached = getCachedMeta(anu.id);
        if (cached) return cached;
        for (let i = 0; i < 3; i++) {
          const m = await sock.groupMetadata(anu.id).catch(() => null);
          if (m) { setCachedMeta(anu.id, m); return m; }
          await new Promise(r => setTimeout(r, 1500));
        }
        return null;
      })();
      const groupAdmins = metadata ? getGroupAdmins(metadata.participants) : [];
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const chat = db.getChat(anu.id) || {};
      const settings = db.getSettings(botId) || {};
      const primaryBotId = chat?.primaryBot;
      const now = new Date();
      const maputoTime = new Date(now.toLocaleString('en-US', { timeZone: 'Africa/Maputo' }));
      const tiempo = maputoTime.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/,/g, '');
      const tiempo2 = moment.tz('Africa/Maputo').format('hh:mm A');
      const memberCount = metadata?.participants?.length || 0;
      const isSelf = (settings.self ?? false) || (chat.isMute ?? false);
      if (isSelf) return;
      for (const p of anu.participants) {
        const jid = resolveEventParticipant(p, sock);
        if (!jid) continue;
        const phone = jid.split('@')[0];
        const pp = await sock.profilePictureUrl(jid, 'image').catch(() => 'https://files.yuki-wabot.my.id/cdn/2PVh.jpeg');
        if (anu.action === 'add' && (!primaryBotId || primaryBotId === botId)) {
          // Anti-fake check
          if (chat?.antifake && groupAdmins.includes(botId)) {
            const codes = chat.antifakeCodes || ['1', '44', '91', '92', '61'];
            const countryCode = phone.replace(/[^0-9]/g, '').replace(/^0+/, '').slice(0, -9);
            if (codes.includes(countryCode)) {
              await sock.groupParticipantsUpdate(anu.id, [jid], 'remove');
              await sock.sendMessage(anu.id, { text: `☡ Número *+${countryCode}* removido pelo sistema Anti-Fake.` });
              continue;
            }
          }
          // Anti-estrangeiro check
          if (chat?.antiarabe && groupAdmins.includes(botId)) {
            const countryCode = phone.replace(/[^0-9]/g, '').replace(/^0+/, '').slice(0, -9);
            if (chat.antiarabeMode === 'onlymz') {
              if (countryCode !== '258') {
                await sock.groupParticipantsUpdate(anu.id, [jid], 'remove');
                await sock.sendMessage(anu.id, { text: `🛡 Número *+${countryCode}* removido. Apenas números moçambicanos (+258) são permitidos.` });
                continue;
              }
            } else if (chat.antiarabeCodes?.length) {
              if (chat.antiarabeCodes.includes(countryCode)) {
                await sock.groupParticipantsUpdate(anu.id, [jid], 'remove');
                await sock.sendMessage(anu.id, { text: `🛡 Número *+${countryCode}* removido pelo sistema Anti-Estrangeiro.` });
                continue;
              }
            }
          }
          // Welcome message
          if (chat?.welcome) {
          if (!metadata) continue;
          let caption;
          if (chat.sWelcome && chat.sWelcome.trim() !== '') {
            caption = chat.sWelcome.replace(/@user/g, `@${phone}`).replace(/@group/g, metadata.subject).replace(/@desc/g, metadata.desc || 'Sem descrição').replace(/@members/g, memberCount).replace(/@time/g, `${tiempo} ${tiempo2}`);
          } else {
            caption = `🌐 *BEM-VINDO(A) À NEL NET EXPRESS* 🌐\n\nOlá @${phone}, seja bem-vindo(a) ao *${metadata.subject}*! 👋\n\n👥 *Somos ${memberCount} membros agora*\n\nAqui tens os melhores pacotes Vodacom \ncom preço justo e activação rápida ⚡\n\n💳 *Pagamento:* M-Pesa | E-Mola\n🛍️ *Comprar:* Paga → Envia comprovativo → Envia número\n\n📖 *Regra:* Só mensagens de compra/venda aqui\n\n👇 Comandos rápidos:\nmegas = Ver pacotes e preços\npagar = Ver como pagar\n\n❓ Dúvida? Fala com suporte: wa.me/878038315\nActivamos em 1-2 minutos. Confia! 💚`
          }
          await sock.sendMessage(anu.id, { image: { url: pp }, caption, mentions: [jid] });
          }
        }
        if ((anu.action === 'remove' || anu.action === 'leave') && chat?.goodbye && (!primaryBotId || primaryBotId === botId)) {
          if (!metadata) continue;
          let caption;
          if (chat.sGoodbye && chat.sGoodbye.trim() !== '') {
            caption = chat.sGoodbye.replace(/@user/g, `@${phone}`).replace(/@group/g, metadata.subject).replace(/@desc/g, metadata.desc || 'Sem descrição').replace(/@members/g, memberCount).replace(/@time/g, `${tiempo} ${tiempo2}`);
          } else {
            caption = `╭┈──━────━─┈๏\n┊ ❴ *Até breve (⁠◔⁠‿⁠◔)* ❵\n┊🚫🚫🚫🚫🚫🚫🚫🚫🚫🚫🚫\n┊  *Nome ›* @${phone}\n┊  *Grupo ›* ${metadata.subject}\n┊┈──━────━─┈๏\n┊➤ *Espero que volte logo.*\n┊➤ *Agora somos ${memberCount} membros.*\n┊ 🚫🚫🚫🚫🚫🚫🚫🚫🚫🚫🚫\n╰──────────────╯`;
          }
          await sock.sendMessage(anu.id, { image: { url: pp }, caption, mentions: [jid] });
        }
        if (anu.action === 'remove' || anu.action === 'leave') {
          const user = db.getChatUser(anu.id, jid);
          if (user && typeof user.afk === 'number' && user.afk > -1) {
            db.setChatUser(anu.id, jid, 'afk', -1);
            db.setChatUser(anu.id, jid, 'afkReason', '');
          }
        }
        if (anu.action === 'promote' && chat?.alerts && (!primaryBotId || primaryBotId === botId)) {
          const authorJid = normalizeJid(anu.author) || anu.author;
          await sock.sendMessage(anu.id, { text: `❴✎❵ *@${phone}* foi promovido a Administrador por *@${authorJid.split('@')[0]}.*`, mentions: [jid, authorJid, ...groupAdmins] });
        }
        if (anu.action === 'demote' && chat?.alerts && (!primaryBotId || primaryBotId === botId)) {
          const authorJid = normalizeJid(anu.author) || anu.author;
          await sock.sendMessage(anu.id, { text: `❴✎❵ *@${phone}* foi rebaixado de Administrador por *@${authorJid.split('@')[0]}.*`, mentions: [jid, authorJid, ...groupAdmins] });
        }
      }
    } catch (err) {
      console.log(chalk.gray(`[ ERRO DE EVENTO ]  → ${err}`));
    }
  });
};
