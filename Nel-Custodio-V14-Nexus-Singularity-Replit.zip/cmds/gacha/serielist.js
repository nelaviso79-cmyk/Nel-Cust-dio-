import { promises as fs } from 'fs';
import db from '#db';

const charactersFilePath = './core/characters.json';

async function loadCharacters() {
  const data = await fs.readFile(charactersFilePath, 'utf-8');
  return JSON.parse(data);
}

export default {
  command: ['sérielist', 'slist', 'animelist'],
  category: 'gacha',
  description: 'Listar séries do bot.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
      }      
      const structure = await loadCharacters();
      const sériesKeys = Object.keys(structure);
      const totalSeries = sériesKeys.length;
      const page = parseInt(args[0]) || 1;
      const perPage = 20;
      const totalPages = Math.max(1, Math.ceil(totalSeries / perPage));      
      if (page < 1 || page > totalPages) {
        return msg.reply(`ꕥ Página no válida. Hay un total de *${totalPages}* páginas.`);
      }      
      const start = (page - 1) * perPage;
      const end = Math.min(start + perPage, totalSeries);
      const sériesPage = sériesKeys.slice(start, end);      
      let replyText = `*❏ Lista de séries (${totalSeries}):*\n\n`;     
      for (const key of sériesPage) {
        const série = structure[key];
        const name = typeof série.name === 'string' ? série.name : key;
        const characters = Array.isArray(série.characters) ? série.characters.length : 0;
        replyText += `» *${name}* (${characters})\n`;
      }      
      replyText += `
> • _Página ${page}/${totalPages}_`;
      await msg.reply(replyText.trim());      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};