import db from '#db';
export default {
  command: ['sell', 'vender'],
  category: 'gacha',
  description: 'Poner um personagem a a venda.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    const userId = msg.sender;
    db.setCreate('chats', chatId, 'sales', {});
    const chat = db.getChat(chatId);
    if (chat.adminonly || !chat.gacha) {
      return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
    }
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings?.currency;
    try {
      if (args.length < 2) {
        return msg.reply(`❀ Deve especificar un precio para subastar o personagem.\n> Exemplo » *${usedPrefix + command} 5000 Nel-Aviso Bot*`);
      }
      const price = parseInt(args[0]);
      if (isNaN(price) || price < 2000) {
        return msg.reply(`ꕥ O preço mínimo para leiloar um personagem é de *¥2,000 ${currency}*.`);
      }
      if (price > 100_000_000) {
        return msg.reply(`ꕥ O preço máximo permitido para leiloar um personagem é de *¥100,000,000 ${currency}*.`);
      }
      const name = args.slice(1).join(' ').toLowerCase();
      const chatUserData = db.getChatUser(chatId, userId);
      const ownedIds = Array.isArray(chatUserData?.characters) ? chatUserData.characters : [];
      let idSell = null;
      let charSell = null;
      for (const cid of ownedIds) {
        const chatKey = chatId + '__' + cid;
        const chatChar = db.getCharacter(chatKey);
        if (chatChar?.name?.toLowerCase() === name && chatChar.user === userId) {
          idSell = cid;
          charSell = chatChar;
          break;
        }
      }
      if (!idSell || !charSell) return msg.reply(`ꕥ Não foi encontrado ao personagem *${args.slice(1).join(' ')}* reivindicado por si.`);
      if (!chat.sales) chat.sales = {};
      if (typeof chat.sales === 'string') {
        try { chat.sales = JSON.parse(chat.sales); } catch { chat.sales = {}; }
      }
      chat.sales[idSell] = { name: charSell.name, user: userId, price, time: Date.now() };
      db.setChat(chatId, 'sales', chat.sales);
      const sellerGlobal = db.getUser(userId);
      let sellerName = sellerGlobal?.name?.trim() || userId.split('@')[0];
      msg.reply(`✎ *${charSell.name}* foi posto à venda!\n❀ Vendedor » *${sellerName}*\n⛁ Valor » *¥${price.toLocaleString()} ${currency}*\nⴵ Expira en » *3 dias*\n> Podes ver as personagens à venda usando *${usedPrefix}wshop*`);
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};