import db from '#db';
export default {
  command: ['setclaim', 'setclaimmsg'],
  category: 'gacha',
  description: 'Modificar a mensagem ao reivindicar um personagem.',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
      }      
      if (!args[0]) {
        return msg.reply(`❀ Deve especificar uma mensagem para reivindicar um personagem.\n> Exemplos:\n> ${usedPrefix + command} €user ha reclamado o personagem €character!\n> ${usedPrefix + command} €character foi reivindicado por €user`);
      }
      const customMsg = args.join(' ');
      if (!customMsg.includes('€user') || !customMsg.includes('€character')) {
        return msg.reply(`ꕥ Tu mensagem debe incluir *€user* y *€character* para que funcione corretamente.`);
      }      
      db.setUser(msg.sender, 'claimMessage', customMsg);
      msg.reply('❀ Mensagem de reclamação modificado.');      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};