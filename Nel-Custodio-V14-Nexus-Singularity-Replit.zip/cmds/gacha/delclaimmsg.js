import db from '#db';
export default {
  command: ['delclaimmsg', 'resetclaimmsg'],
  category: 'gacha',
  description: 'Restabelecer a mensagem ao reivindicar um personagem.',
  run: async ({ msg, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
      }
      const user = db.getUser(msg.sender);
      if (user.claimMessage) {
        db.setUser(msg.sender, 'claimMessage', '');
      }      
      msg.reply('❀ Mensagem de reclamação rdefinido.');      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};