import db from '#db';
export default {
  command: ['comprarc', 'comprarcharacter', 'comprarchar'],
  category: 'gacha',
  description: 'Comprar um personagem à venda.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const chatId = msg.chat;
    const userId = msg.sender;
    db.setCreate('chats', chatId, 'sales', {});
    let chat = db.getChat(chatId);
    if (chat.adminonly || !chat.gacha) {
      return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com:\n» *${usedPrefix}gacha on*`);
    }
    if (chat.sales && typeof chat.sales === 'string') {
      try { chat.sales = JSON.parse(chat.sales); } catch { chat.sales = {}; }
    }    
    try {
      if (!args.length) {
        return msg.reply(`❀ Deve especificar um personagem para comprar.\n> Exemplo » *${usedPrefix + command} Nel-Aviso Bot*`);
      }      
      const queryComprar = args.join(' ').toLowerCase();
      const idComprar = Object.keys(chat.sales).find(id => (chat.sales[id]?.name || '').toLowerCase() === queryComprar);
      if (!idComprar) return msg.reply(`ꕥ Não foi encontrado ao personagem *${args.join(' ')}* à venda.`);     
      const venta = chat.sales[idComprar];
      if (venta.user === userId) return msg.reply(`ꕥ No podes comprar tu propio personagem.`);     
      const ahora = Date.now();
      if (ahora - venta.time >= 3 * 864e5) {
        delete chat.sales[idComprar];
        db.setChat(chatId, 'sales', chat.sales);
        return msg.reply(`ꕥ A venda de *${venta.name}* expirou.`);
      }
      let comprarer = db.getChatUser(chatId, userId);
      const saldo = comprarer.coins || 0;
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const settings = db.getSettings(botId);
      const currency = settings?.currency;
      if (saldo < venta.price) {
        return msg.reply(`ꕥ Não tem suficientes *${currency}* para comprar a *${venta.name}*.\n> Precisas *¥${venta.price.toLocaleString()} ${currency}*`);
      }
      db.setCreate('chat_users', [chatId, venta.user], 'favorite', '');
      let seller = db.getChatUser(chatId, venta.user);
      comprarer.coins -= venta.price;
      seller.coins += venta.price;
      db.setChatUser(chatId, userId, 'coins', comprarer.coins);
      db.setChatUser(chatId, venta.user, 'coins', seller.coins);
      const comprarKey = chatId + '__' + idComprar;
      db.setCreate('characters', comprarKey, 'name', venta.name);
      let character = db.getCharacter(comprarKey);
      if (!character) character = { name: venta.name, value: 0, votes: 0 };
      character.user = userId;
      character.claimedAt = ahora;
      db.setCharacter(comprarKey, character);
      if (!comprarer.characters.includes(idComprar)) {
        comprarer.characters.push(idComprar);
        db.setChatUser(chatId, userId, 'characters', comprarer.characters);
      }
      seller.characters = seller.characters.filter(id => id !== idComprar);
      db.setChatUser(chatId, venta.user, 'characters', seller.characters);
      if (seller.favorite === idComprar) {
        db.setChatUser(chatId, venta.user, 'favorite', '');
        db.setUser(venta.user, 'favorite', '');
      }
      delete chat.sales[idComprar];
      db.setChat(chatId, 'sales', chat.sales);
      const vendedorGlobal = db.getUser(venta.user);
      const compradorGlobal = db.getUser(userId);
      let vendedorNome = vendedorGlobal?.name?.trim() || venta.user.split('@')[0];
      let compradorNome = compradorGlobal?.name?.trim() || userId.split('@')[0];
      msg.reply(`❀ *${venta.name}* foi comprado por *${compradorNome}*!\n> Foram transferidos *¥${venta.price.toLocaleString()} ${currency}* a *${vendedorNome}*`);
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};