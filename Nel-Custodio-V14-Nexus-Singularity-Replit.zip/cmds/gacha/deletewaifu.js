import { promises as fs } from 'fs';
import db from '#db';

const charactersFilePath = './core/characters.json';

async function loadCharacters() {
  const data = await fs.readFile(charactersFilePath, 'utf-8');
  return JSON.parse(data);
}

function flattenCharacters(structure) {
  return Object.values(structure).flatMap(s => Array.isArray(s.characters) ? s.characters : []);
}

export default {
  command: ['delchar', 'deletewaifu', 'delwaifu'],
  category: 'gacha',
  description: 'Eliminerar um personagem reclamado.',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
      }
      db.setCreate('chat_users', [msg.chat, msg.sender], 'favorite', '');
      let user = db.getChatUser(msg.chat, msg.sender);
      if (!Array.isArray(user.characters) || !user.characters.length) {
        return msg.reply(`❀ Não tem personagems reclamados en tu harem.`);
      }      
      if (!args.length) {
        return msg.reply(`❀ Deve especificar um personagem para remover.\n> Exemplo » *${usedPrefix + command} Nel-Aviso Bot*`);
      }      
      const inputName = args.join(' ').toLowerCase().trim();
      const structure = await loadCharacters();
      const allCharacters = flattenCharacters(structure);
      const character = allCharacters.find(c => c.name.toLowerCase() === inputName);
      if (!character) {
        return msg.reply(`ꕥ Não foi encontrado ningún personagem com o nome *${inputName}*\n> Pode sugerir usando *${usedPrefix}suggest personagem ${inputName}*`);
      }      
      if (!user.characters.includes(character.id)) {
        return msg.reply(`ꕥ *${character.name}* não está reivindicado por si.`);
      }
      const charKey = msg.chat + '__' + character.id;
      let characterData = db.getCharacter(charKey);
      if (characterData && characterData.user === msg.sender) {
        delete characterData.user;
        delete characterData.claimedAt;
        db.setCharacter(charKey, characterData);
      }
      user.characters = user.characters.filter(id => id !== character.id);
      db.setChatUser(msg.chat, msg.sender, 'characters', user.characters);
      if (user.favorite === character.id) {
        db.setChatUser(msg.chat, msg.sender, 'favorite', '');
        db.setUser(msg.sender, 'favorite', '');
      }
      await sock.sendMessage(msg.chat, { text: `❀ *${character.name}* foi eliminado de tu lista de reclamados.` }, { quoted: msg });      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};