import { promises as fs } from 'fs';
import db from '#db';

const charactersFilePath = './core/characters.json';

async function loadCharacters() {
  const data = await fs.readFile(charactersFilePath, 'utf-8');
  return JSON.parse(data);
}

function flattenCharacters(structure) {
  return Object.values(structure).flatMap(s => Array.isArray(s.characters) ? s.characters : []);
}

export default {
  command: ['setfav', 'setfavourite'],
  category: 'gacha',
  description: 'Definir tu claim favorito.',
  run: async ({ msg, args, usedPrefix, command }) => {
    const chat = db.getChat(msg.chat);    
    if (chat.adminonly || !chat.gacha) {
      return msg.reply(`ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\nUn *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`);
    }    
    if (!args.length) {
      return msg.reply(`❀ Deve especificar um personagem.\n> Exemplo » *${usedPrefix + command} Nel-Aviso Bot*`);
    }
    db.setCreate('chat_users', [msg.chat, msg.sender], 'favorite', '');
    db.setCreate('users', msg.sender, 'favorite', '');    
    let user = db.getChatUser(msg.chat, msg.sender);    
    if (!Array.isArray(user.characters)) user.characters = [];    
    try {
      const structure = await loadCharacters();
      const allCharacters = flattenCharacters(structure);
      const name = args.join(' ').toLowerCase().trim();      
      const character = allCharacters.find(c => String(c.name).toLowerCase() === name) || allCharacters.find(c => String(c.name).toLowerCase().includes(name) || (Array.isArray(c.tags) && c.tags.some(tag => tag.toLowerCase().includes(name)))) || allCharacters.find(c => name.split(' ').some(q => String(c.name).toLowerCase().includes(q) || (Array.isArray(c.tags) && c.tags.some(tag => tag.toLowerCase().includes(q)))));      
      if (!character) return msg.reply(`ꕥ Não foi encontrado o personagem *${name}*.`);      
      const isClaimed = user.characters.includes(character.id);
      if (!isClaimed) return msg.reply(`ꕥ O personagem *${character.name}* não está reivindicado por si.`);
      const previousId = user.favorite;
      db.setChatUser(msg.chat, msg.sender, 'favorite', character.id);
      db.setUser(msg.sender, 'favorite', character.id);
      if (previousId && previousId !== character.id) {
        const prevChar = db.getCharacter(previousId);
        const prevName = prevChar?.name || 'personagem anterior';
        return msg.reply(`❀ Foi substituído o seu favorito *${prevName}* por *${character.name}*!`);
      }      
      return msg.reply(`❀ Ahora *${character.name}* es tu personagem favorito!`);      
    } catch (e) {
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  },
};