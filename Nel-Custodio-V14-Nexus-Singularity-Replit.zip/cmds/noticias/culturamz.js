export default {
  command: ['giriasmz', 'dicasmz', 'culturamz', 'bro'],
  category: 'noticias',
  description: 'Dicionário de gírias e cultura moçambicana.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const girias = [
      { termo: "Txilar", def: "Relaxar, curtir um momento calmo." },
      { termo: "Mambo", def: "Coisa, assunto, situação ou objeto." },
      { termo: "Xiconhoca", def: "Pessoa traidora ou de má conduta." },
      { termo: "Maningue", def: "Muito, em grande quantidade." },
      { termo: "Caniço", def: "Bairros suburbanos ou populares." },
      { termo: "Palar", def: "Falar, conversar ou convencer alguém." },
      { termo: "Djobar", def: "Trabalhar (vem do inglês 'job')." },
      { termo: "Estalar", def: "Comer maningue bem." }
    ];

    const dicas = [
      "🇲🇿 *Dica MZ:* Sempre que fores ao mercado, prepara-te para a 'mola' (negociação).",
      "🇲🇿 *Dica MZ:* O melhor frango à zambeziana encontras na Beira ou Quelimane!",
      "🇲🇿 *Dica MZ:* Se fores à Catembe, não esqueças de apreciar a vista de Maputo.",
      "🇲🇿 *Dica MZ:* Badjia com pão é o pequeno-almoço dos campeões!"
    ];

    await msg.react('🇲🇿');
    
    let resposta = `🇲🇿 *DNA MOÇAMBICANO - NEL-AVISO* 🇲🇿\n\n`;
    
    resposta += `📖 *GÍRIAS DO DIA:*\n`;
    const sorteadas = girias.sort(() => 0.5 - Math.random()).slice(0, 3);
    sorteadas.forEach(g => {
      resposta += `▸ *${g.termo}:* ${g.def}\n`;
    });

    resposta += `\n💡 *CURIOSIDADE/DICA:*\n`;
    resposta += `${dicas[Math.floor(Math.random() * dicas.length)]}\n\n`;
    
    resposta += `> 👑 _Nel Custódio: Valorizando a nossa terra._`;

    await msg.reply(resposta);
    await msg.react('✅');
  }
};
