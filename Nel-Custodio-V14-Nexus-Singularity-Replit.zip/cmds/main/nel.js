/**
 * 👤 QUEM SOU EU — Informações sobre o criador Nel Custódio
 */

export default {
  command: ['quemsoueu', 'nel', 'dono', 'criadorinfo'],
  category: 'main',
  description: 'Conheça o criador do Nel-Aviso-Bot 👤',
  run: async ({ msg, sock, usedPrefix, command }) => {
    let result = `👤 *QUEM SOU EU?* 👤\n\n`;
    result += `Meu nome é *Nel Custódio*, tenho *19 anos* e sou o criador deste bot.\n\n`;
    result += `🚀 *Minha Paixão:* Sou um jovem entusiasta da programação e dos códigos. Acredito no poder da tecnologia para transformar realidades e adoro passar o tempo explorando novas linguagens e criando soluções digitais.\n\n`;
    result += `🎯 *Objetivo:* Quero continuar a evoluir no mundo da programação e tornar este bot uma referência em Moçambique, ajudando as pessoas a navegarem sem limites.\n\n`;
    result += `🇲🇿 *Orgulho:* Sou Moçambicano e este projeto foi feito com muito amor e dedicação para todos vocês!\n\n`;
    result += `━━━━━━━━━━━━━━━━━━━━\n`;
    result += `💡 *Mensagem:* "A programação não é apenas sobre código, é sobre resolver problemas e criar o futuro."\n\n`;
    result += `_🇲🇿 Nel-Aviso-Bot-Moz — Feito por Nel Custódio_`;

    await msg.reply(result);
  }
};
