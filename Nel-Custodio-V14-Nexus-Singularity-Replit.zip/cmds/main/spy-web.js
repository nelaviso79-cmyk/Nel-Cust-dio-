import axios from 'axios';

export default {
  command: ['spy-web', 'link-info', 'resumir-link'],
  category: 'ia',
  description: 'Extrair e resumir informações de qualquer link (VIP Elite) 🔍',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🔍 *SPY-WEB: ANÁLISE DE LINKS*\n\nEnvie um link para eu analisar.\nExemplo: *${usedPrefix + command} https://exemplo.com/noticia*`);
    
    await msg.react('🔍');
    try {
      const res = await axios.get(`https://api.vreden.web.id/api/tools/web-extract?url=${encodeURIComponent(text)}`);
      if (!res.data.status) throw new Error();
      
      const prompt = `Resuma o seguinte conteúdo de forma executiva e profissional:\n\n${res.data.result}`;
      const aiRes = await axios.get(`https://api.vreden.web.id/api/ai/chatgpt?text=${encodeURIComponent(prompt)}`);
      
      await msg.reply(`🔍 *ANÁLISE SPY-WEB:*\n\n${aiRes.data.result}\n\n> 💎 _Omni-Nexus Intelligence_`);
      await msg.react('✅');
    } catch (e) {
      await msg.reply('❌ Não consegui infiltrar-me nesse link. Verifique se a URL está correta.');
    }
  }
};
