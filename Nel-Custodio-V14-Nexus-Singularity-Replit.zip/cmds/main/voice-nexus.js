import axios from 'axios';

export default {
  command: ['voice-nexus', 'falar-elite', 'tts'],
  category: 'ia',
  description: 'Transformar texto em voz neural profissional (VIP Elite) 🎙️',
  run: async ({ msg, text, usedPrefix, command }) => {
    if (!text) return msg.reply(`🎙️ *VOICE-NEXUS: VOZ NEURAL*\n\nEscreva o texto para eu narrar.\nExemplo: *${usedPrefix + command} Bem-vindo ao império Omni-Nexus.*`);
    
    await msg.react('🎙️');
    try {
      const url = `https://api.vreden.web.id/api/tools/tts?text=${encodeURIComponent(text)}&voice=pt-BR-AntonioNeural`;
      await msg.sock.sendMessage(msg.chat, { 
        audio: { url }, 
        mimetype: 'audio/mp4', 
        ptt: true 
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.reply('❌ Falha ao sintetizar voz Nexus.');
    }
  }
};
