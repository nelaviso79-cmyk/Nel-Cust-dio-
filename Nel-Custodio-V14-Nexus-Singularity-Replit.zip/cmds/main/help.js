import moment from 'moment-timezone';
import db from '#db';
import { bodyMenu, menuObject } from '#system/commands';

function normalize(text = '') {
  text = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  return text.endsWith('s') ? text.slice(0, -1) : text;
}

function formatarMs(ms) {
  const segundos = Math.floor(ms / 1000);
  const minutos = Math.floor(segundos / 60);
  const horas = Math.floor(minutos / 60);
  const dias = Math.floor(horas / 24);
  return [dias && `${dias}d`, `${horas % 24}h`, `${minutos % 60}m`, `${segundos % 60}s`].filter(Boolean).join(" ");
}

export default {
  command: ['allmenu', 'help', 'menu', 'ayuda'],
  category: 'main',
  description: 'Ver o menu de comandos Nexus Singularity.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const botSettings = db.getSettings(botId) || {};
      const users = db.getUser();
      const usersCount = users?.length || 0;
      const userGlobal = db.getUser(msg.sender);
      const senderName = userGlobal?.name || msg.pushName || 'Usuário';
      const uptime = sock.uptime ? formatarMs(Date.now() - sock.uptime) : "Ativo";

      // Imagens Aleatórias V14
      const images = [
        'https://files.catbox.moe/u8o8yq.png', // Substituir pelos caminhos locais ou URLs finais
        'https://files.catbox.moe/7x9z2j.png',
        'https://files.catbox.moe/k3m9w1.png'
      ];
      // Nota: No ambiente real, usaremos os ficheiros locais ou URLs enviadas
      const randomImg = images[Math.floor(Math.random() * images.length)];

      const alias = {
        singularity: ['singularity', 'v14', 'avancado'],
        elite: ['elite', 'premium', 'vip'],
        economia: ['economia', 'eco', 'money'],
        gacha: ['gacha', 'jogos', 'waifu'],
        downloads: ['downloads', 'download', 'baixar'],
        perfil: ['perfil', 'profile', 'me'],
        sockets: ['sockets', 'sessao', 'bot'],
        stickers: ['stickers', 'figurinhas', 's'],
        utilidades: ['utilidades', 'utils', 'ferramentas'],
        grupos: ['grupos', 'grupo', 'gp'],
        nsfw: ['nsfw', '+18'],
        anime: ['anime', 'otaku'],
        moderacao: ['moderacao', 'mod'],
        diversao: ['diversao', 'brincar'],
        ia: ['ia', 'ai', 'brain'],
        noticias: ['noticias', 'news'],
        pagamentos: ['pagamentos', 'mpesa'],
        nexus: ['nexus', 'novidades', 'v13']
      };

      const input = normalize(args[0] || '');
      const cat = Object.keys(alias).find(k => alias[k].map(normalize).includes(input));
      
      if (args[0] && !cat) {
        return msg.reply(`《✧》 A categoria *${args[0]}* não existe.\n> Use *.menu* para ver a lista.`);
      }

      const content = cat ? (menuObject[cat] || '') : bodyMenu;
      let menu = content;

      menu = menu.replace(/\$prefix/g, usedPrefix)
                 .replace(/\$sender/g, senderName)
                 .replace(/\$botname/g, 'Nel Custódio')
                 .replace(/\$users/g, usersCount)
                 .replace(/\$uptime/g, uptime)
                 .replace(/\$link/g, botSettings.link || 'https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N');

      await sock.sendMessage(msg.chat, {
        image: { url: randomImg },
        caption: menu.trim(),
        contextInfo: { mentionedJid: [msg.sender] }
      }, { quoted: msg });

    } catch (e) {
      console.error(e);
      await msg.reply(`❌ Erro no menu Singularity: ${e.message}`);
    }
  }
};
