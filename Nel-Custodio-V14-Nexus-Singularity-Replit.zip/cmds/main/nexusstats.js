import db from '#db';
import moment from 'moment-timezone';

export default {
  command: ['nexusstats', 'stats', 'imperio'],
  category: 'main',
  description: 'Dashboard de Performance Nexus Intelligence 📊',
  run: async ({ msg, sock, isOwner }) => {
    if (!isOwner) return msg.reply(`❌ Apenas o imperador Nel Custódio pode aceder a este painel.`);

    await msg.react('📊');
    
    const users = db.getUser();
    const chats = db.getChat();
    const today = moment().tz('Africa/Maputo').format('DDMMYY');
    
    let totalCmds = 0;
    let dailyCmds = 0;
    users.forEach(u => {
      totalCmds += (u.usedcommands || 0);
      const stats = u.metadatos ? (typeof u.metadatos === 'string' ? JSON.parse(u.metadatos) : u.metadatos) : {};
      if (stats[today]) dailyCmds += (stats[today].cmds || 0);
    });

    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    
    const dashboard = `
╔══════════════════════════════════════╗
   🧠 *NEXUS INTELLIGENCE DASHBOARD*
╚══════════════════════════════════════╝

┌─ ░ *PERFORMANCE DO IMPÉRIO* ░
│ 👑 *Dono:* Nel Custódio
│ 👥 *Cidadãos:* ${users.length}
│ 🏰 *Territórios:* ${chats.length}
│ ⚡ *Uptime:* ${hours}h ativos
└───────────────────

┌─ ░ *ATIVIDADE DE HOJE* ░
│ 🚀 *Comandos:* ${dailyCmds}
│ 📈 *Total Acumulado:* ${totalCmds}
│ 🛡️ *Status:* 100% Estável
└───────────────────

┌─ ░ *SAÚDE DO NÚCLEO* ░
│ 🔋 *Anti-Sleep:* ✅ Ativo
│ 🧠 *IA Engine:* V12 Nexus
│ 🇲🇿 *Região:* Moçambique
└───────────────────

> _"O controlo total do seu império na palma da mão."_
> 💎 *Nexus Intelligence V12*
    `;

    // Tentar gerar imagem via API se possível, senão enviar texto
    try {
      const bannerUrl = `https://api.vreden.web.id/api/canvas/welcome?name=${encodeURIComponent('NEL CUSTÓDIO')}&msg=${encodeURIComponent('NEXUS PERFORMANCE')}&avatar=https://telegra.ph/file/241d9774659970966952e.jpg&groupname=${encodeURIComponent('NEXUS IMPÉRIO')}`;
      await sock.sendMessage(msg.chat, {
        image: { url: bannerUrl },
        caption: dashboard.trim()
      }, { quoted: msg });
    } catch {
      await msg.reply(dashboard.trim());
    }
    
    await msg.react('✅');
  }
};
