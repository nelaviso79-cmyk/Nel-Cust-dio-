import db from '#db';
export default {
  command: ['join', 'unir'],
  category: 'sockets',
  description: 'Unir o bot a um grupo.',
  run: async ({ msg, sock, args }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    if (!args[0]) return msg.reply('《✧》 Insira o link do grupo para adicionar o bot.');
    const linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
    const match = args[0].match(linkRegex);
    if (!match || !match[1]) {
      return msg.reply('《✧》 O link inserido não é válido ou está incompleto.');
    }
    try {
      const inviteCode = match[1];
      await sock.groupAcceptInvite(inviteCode);
      await sock.reply(msg.chat, `❀ ${config.botname || 'Bot'} entrou com sucesso no grupo.`, msg);
    } catch (e) {
      const errMsg = String(e.message || e);
      if (errMsg.includes('not-authorized') || errMsg.includes('requires-admin')) {
        await msg.reply('《✧》 A entrada requer aprovação de administrador. Aguarde até que aceitem o seu pedido.');
      } else if (errMsg.includes('not-in-group') || errMsg.includes('removed')) {
        await msg.reply('《✧》 Não foi possível entrar no grupo porque o bot fue eliminado recientemente.');
      } else {
        await msg.reply('《✧》 Não foi possível entrar no grupo, verifica o link o los permisos.');
      }
    }
  },
};