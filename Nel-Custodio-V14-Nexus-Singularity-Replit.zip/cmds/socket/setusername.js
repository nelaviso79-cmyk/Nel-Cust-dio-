import db from '#db';
export default {
  command: ['setusername'],
  category: 'sockets',
  description: 'Alterar o nome de usuário do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    const value = args.join(' ').trim();
    if (!value) return msg.reply(`✎ Deve escrever um nome de usuário valido.\n> Exemplo: *${usedPrefix + command} Nel-Aviso Bot*`);
    await sock.updateProfileName(value);
    return msg.reply(`✿ O nome de usuário do bot foi atualizado para *${value}*!`);
  },
};