import db from '#db';

export default {
  command: ['lockbot', 'soeu', 'privado', 'lock'],
  category: 'sockets',
  description: 'Bloqueia o bot para responder apenas ao dono em segundos.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const config = db.getSettings(idBot) || {};
    
    // Verificar se é dono
    const isOwner = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner) return msg.reply(global.mess.owner);

    const action = args[0]?.toLowerCase();
    
    if (action === 'on' || action === 'ativar') {
      db.setSettings(idBot, 'self', true);
      return msg.reply(`🔒 *MODO SÓ EU ATIVADO!*\n\nO bot agora só responderá aos seus comandos. Útil para testes e manutenção rápida.\n\n> Para desbloquear: *${usedPrefix + command} off*`);
    }

    if (action === 'off' || action === 'desativar') {
      db.setSettings(idBot, 'self', false);
      return msg.reply(`🔓 *MODO PÚBLICO ATIVADO!*\n\nO bot voltou a responder a todos os utilizadores.`);
    }

    const status = config.self ? '🔒 BLOQUEADO (Só Eu)' : '🔓 ABERTO (Público)';
    return msg.reply(
      `🤖 *CONTROLO DE ACESSO*\n\n` +
      `Estado atual: *${status}*\n\n` +
      `Use:\n` +
      `> *${usedPrefix + command} on* — Bloquear bot\n` +
      `> *${usedPrefix + command} off* — Desbloquear bot`
    );
  }
};
