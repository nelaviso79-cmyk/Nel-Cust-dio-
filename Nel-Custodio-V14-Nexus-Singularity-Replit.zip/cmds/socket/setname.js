import db from '#db';
export default {
  command: ['setbotname', 'setname'],
  category: 'sockets',
  description: 'Alterar o nome do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    let config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    const value = args.join(' ').trim();
    if (!value) return msg.reply(`✐ Deve escrever um nome corto y un nombre largo valido.\n> Exemplo: *${usedPrefix + command} Nel-Aviso / Nel-Aviso Bot*`);
    const formatted = value.replace(/\s*\/\s*/g, '/');
    let [short, long] = formatted.includes('/') ? formatted.split('/') : [value, value];
    if (!short || !long) return msg.reply('✎ Usa o formato: Nome Curto / Nome Completo');
    if (/\s/.test(short)) return msg.reply('❖ O nome curto no pode contener espacios.');
    db.setSettings(idBot, 'namebot', short.trim());
    db.setSettings(idBot, 'botname', long.trim());
    return msg.reply(`✿ O nome do bot foi atualizado!\n\n❒ Nome curto: *${short.trim()}*\n❒ Nome longo: *${long.trim()}*`);
  },
};