import db from '#db';
export default {
  command: ['setstatus'],
  category: 'sockets',
  description: 'Mudar o estado do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return msg.reply(global.mess.socket);
    const value = args.join(' ').trim();
    if (!value) return msg.reply(`✐ Deve escrever um estado válido.\n> Exemplo: *${usedPrefix + command} Olá! soy Nel-Aviso Bot*`);
    await sock.updateProfileStatus(value);
    return msg.reply(`✿ Foi atualizado o estado do bot para *${value}*!`);
  },
};