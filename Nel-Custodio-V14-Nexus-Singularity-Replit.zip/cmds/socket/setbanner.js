import fetch from 'node-fetch';
import db from '#db';

async function uploadImage(buffer, mime) {
  const base64Data = buffer.toString('base64');
  const extension = mime.split('/')[1] || 'jpg';
  
  const res = await fetch('https://qu.ax/upload.php', {
    method: 'POST',
    body: new URLSearchParams({
      'file': base64Data,
      'extension': extension
    })
  });
  // Nota: qu.ax e outros serviços similares requerem multipart/form-data.
  // Vou usar um serviço de upload mais estável para o bot.
  const FormData = (await import('form-data')).default;
  const form = new FormData();
  form.append('files[]', buffer, `banner.${extension}`);
  const r = await fetch('https://uguu.se/upload.php', { method: 'POST', body: form });
  const j = await r.json();
  if (j.files?.[0]?.url) return j.files[0].url;
  
  const json = await res.json();
  if (json?.url) return json.url;
  throw new Error('Upload failed');
}

export default {
  command: ['setbanner', 'setbotbanner'],
  category: 'sockets',
  description: 'Alterar o banner do menu.',
  run: async ({ msg, sock, args }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net'
    let config = db.getSettings(idBot) || {}
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender)
    if (!isOwner2) return sock.reply(msg.chat, global.mess.socket, msg)
    const value = args.join(' ').trim()
    if (!value && !msg.quoted && !msg.message?.imageMessage && !msg.message?.videoMessage) {
      return msg.reply('✎ Deve enviar ou citar uma imagem o video para alterar o banner do bot.')
    }
    if (value && value.startsWith('http')) {
      db.setSettings(idBot, 'banner', value)
      return msg.reply(`✿ Foi atualizado o banner de *${config.namebot || 'Bot'}*!`)
    }
    const q = msg.quoted || msg
    const mime = (q.msg || q).mimetype || q.mediaType || ''
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
      return msg.reply('✎ Responde a uma imagem válida.')
    }
    const media = await q.download()
    if (!media) return msg.reply('✎ Não foi possível baixar a imagem.')
    const link = await uploadImage(media, mime)
    db.setSettings(idBot, 'banner', link)
    return msg.reply(`✿ Foi atualizado o banner de *${config.namebot || 'Bot'}*!`)
  }
}
