import GraphemeSplitter from 'grapheme-splitter';
import db from '#db';

export default {
  command: ['setprefix', 'setbotprefix'],
  category: 'sockets',
  description: 'Alterar o prefixo do bot.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const idBot = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    let config = db.getSettings(idBot) || {};
    const isOwner2 = [idBot, ...(config.owner ? [config.owner] : []), ...global.owner.map(num => num + '@s.whatsapp.net')].includes(msg.sender);
    if (!isOwner2) return sock.reply(msg.chat, global.mess.socket, msg);
    const value = args.join(' ').trim();
    const defaultPrefix = ["#", "/", "!", "."];
    if (!value) {
      const lista = config.prefix === 1 ? '`sem prefixos`' : (Array.isArray(config.prefix) ? config.prefix : [config.prefix || '/']).map(p => `\`${p}\``).join(', ');
      return msg.reply(`❀ Por favor, escolhe qualquer um dos seguintes métodos de prefixos.\n\n> *○ Only-Prefix* » ${usedPrefix + command} *.*\n> *○ Multi-Prefix* » ${usedPrefix + command} *!/.#*\n> *○ No-Prefix* » ${usedPrefix + command} *noprefix*\n\nꕥ Actualmente se está usando: ${lista}`);
    }
    if (value.toLowerCase() === 'reset') {
      db.setSettings(idBot, 'prefix', defaultPrefix);
      return sock.reply(msg.chat, `❀ Foram restaurados os prefixos predeterminados: *${defaultPrefix.join(' ')}*`, msg);
    }
    if (value.toLowerCase() === 'noprefix') {
      db.setSettings(idBot, 'prefix', 1);
      return msg.reply(`❀ Mudou para o modo sem prefixo para o Socket corretamente\n> Agora o bot responderá a comandos *sem prefixos*.`);
    }
    const splitter = new GraphemeSplitter();
    const graphemes = splitter.splitGraphemes(value);
    const lista = [];
    for (const g of graphemes) {
      if (/^[a-zA-Z]+$/.test(g)) continue;
      if (!lista.includes(g)) lista.push(g);
    }
    if (lista.length === 0) return sock.reply(msg.chat, 'ꕥ Não foram detectados prefixos válidos. Deve incluir al menos um símbolo ou emoji.', msg);
    if (lista.length > 6) return sock.reply(msg.chat, 'ꕥ Máximo 6 prefixos permitidos.', msg);
    db.setSettings(idBot, 'prefix', lista);
    return sock.reply(msg.chat, `❀ Foi alterado o prefixo do Socket a *${lista.join(' ')}* corretamente.`, msg);
  },
};