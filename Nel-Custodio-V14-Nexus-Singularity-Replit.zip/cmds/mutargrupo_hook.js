import db from '#db';

export async function before({ msg, sock, groupMetadata, isAdmins, isBotAdmins, isOwner }) {
  if (!msg.isGroup) return;
  if (msg.isBot) return;
  if (isAdmins || isOwner) return;
  if (!isBotAdmins) return;

  const chat = db.getChat(msg.chat) || {};
  if (!chat?.muteUntil) return;
  if (Date.now() > chat.muteUntil) {
    // Mute expired, clear it
    db.updateChatSetting(msg.chat, 'muteUntil', 0);
    try {
      await sock.groupSettingUpdate(msg.chat, 'not_announcement');
    } catch {}
    return;
  }

  // Group is muted - delete the message
  try {
    await sock.sendMessage(msg.chat, { delete: { remoteJid: msg.chat, fromMe: false, id: msg.key.id, participant: msg.key.participant }});
  } catch {}

  return true; // Stop further processing
}
