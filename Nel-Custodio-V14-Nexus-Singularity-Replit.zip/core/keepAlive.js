import http from 'http';
import fetch from 'node-fetch';
import db from './system/database.js';

let serverInstance = null;
let selfPingInterval = null;
let pingCount = 0;
let lastExternalPing = null;
const startTime = Date.now();

export function startKeepAlive() {
  if (serverInstance) return;

  // Replit usa frequentemente a porta 3000 ou 8080
  const KEEP_ALIVE_PORT = process.env.PORT || 3000;
  const KEEP_ALIVE_HOST = '0.0.0.0';

  const server = http.createServer((req, res) => {
    // Rota do Dashboard
    if (req.url === '/dashboard' || req.url === '/admin') {
      try {
        const users = db.getUser() || [];
        const chats = db.getChat() || [];
        const sales = db.getSales(10) || [];
        const dailyTotal = db.getDailySales()?.total || 0;

        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(\`
          <!DOCTYPE html>
          <html lang="pt">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Omni-Nexus V13.1 - Replit Dashboard</title>
            <style>
              :root { --primary: #00ffcc; --bg: #0a0a0a; --card: #1a1a1a; --text: #cccccc; }
              body { font-family: 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 20px; }
              .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--primary); padding-bottom: 10px; margin-bottom: 20px; }
              h1 { color: var(--primary); text-transform: uppercase; margin: 0; font-size: 1.5rem; }
              .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
              .card { background: var(--card); padding: 20px; border-radius: 10px; border: 1px solid #333; }
              .card h3 { margin: 0; color: var(--primary); font-size: 0.9rem; }
              .card p { font-size: 1.8rem; font-weight: bold; margin: 10px 0 0; color: #fff; }
              .table-container { margin-top: 30px; background: var(--card); padding: 20px; border-radius: 10px; overflow-x: auto; }
              table { width: 100%; border-collapse: collapse; margin-top: 10px; min-width: 500px; }
              th, td { text-align: left; padding: 12px; border-bottom: 1px solid #333; }
              th { color: var(--primary); font-size: 0.8rem; text-transform: uppercase; }
              .status-online { color: #00ff00; font-weight: bold; animation: blink 1.5s infinite; }
              @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>🧠 Omni-Nexus V13.1</h1>
              <div class="status-online">● NÚCLEO ATIVO</div>
            </div>
            <div class="grid">
              <div class="card"><h3>👥 Cidadãos</h3><p>\${users.length}</p></div>
              <div class="card"><h3>🏰 Territórios</h3><p>\${chats.length}</p></div>
              <div class="card"><h3>💰 Vendas Hoje</h3><p>\${dailyTotal} MT</p></div>
              <div class="card"><h3>⏱️ Uptime</h3><p>\${Math.floor((Date.now() - startTime) / 3600000)}h \${Math.floor(((Date.now() - startTime) % 3600000) / 60000)}m</p></div>
            </div>
            <div class="table-container">
              <h3>📊 Últimas Transações</h3>
              <table>
                <thead><tr><th>Usuário</th><th>Valor</th><th>Descrição</th><th>Data</th></tr></thead>
                <tbody>
                  \${sales.map(s => \`<tr><td>\${s.userId.split('@')[0]}</td><td>\${s.amount} MT</td><td>\${s.description}</td><td>\${new Date(s.date).toLocaleString('pt-MZ')}</td></tr>\`).join('')}
                </tbody>
              </table>
            </div>
          </body>
          </html>
        \`);
      } catch (e) {
        res.writeHead(500);
        res.end('Erro no Dashboard Nexus');
      }
      return;
    }

    // Rota de Keep Alive para o UptimeRobot ou similar
    if (req.url === '/keepalive' || req.url === '/') {
      pingCount++;
      lastExternalPing = new Date().toISOString();
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('Nexus Core V13.1 is running 24/7');
      return;
    }

    res.writeHead(404);
    res.end();
  });

  server.listen(KEEP_ALIVE_PORT, KEEP_ALIVE_HOST, () => {
    console.log(\`🔋 [ Replit-Nexus ] Núcleo ativo em http://0.0.0.0:\${KEEP_ALIVE_PORT}\`);
  });

  serverInstance = server;
  startSelfPing();
}

function startSelfPing() {
  const SELF_PING_INTERVAL = 30 * 1000; // 30 segundos para Replit ser agressivo
  selfPingInterval = setInterval(async () => {
    try {
      const PORT = process.env.PORT || 3000;
      // Replit permite localhost para auto-ping
      await fetch(\`http://127.0.0.1:\${PORT}/keepalive\`, { method: 'GET' });
    } catch (e) {}
  }, SELF_PING_INTERVAL);
}

export function stopKeepAlive() {
  if (serverInstance) serverInstance.close();
  if (selfPingInterval) clearInterval(selfPingInterval);
}

export function getKeepAliveStats() {
  return {
    isRunning: !!serverInstance,
    uptime: Date.now() - startTime,
    pings: pingCount,
    lastPing: lastExternalPing
  };
}

export default { startKeepAlive, stopKeepAlive, getKeepAliveStats };
