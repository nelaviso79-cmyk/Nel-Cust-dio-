// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · core/system/commands.js
//   V13.1 OMNI-NEXUS LEGACY EDITION - REPLIT OPTIMIZED
// ╚═══════════════════════════════════════════════════════════════╝

export const bodyMenu = `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃   🧠 *OMNI-NEXUS* · V13.1   ┃
┃   _Legacy & Elite Fusion_      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👋 Olá *@$sender*! O núcleo *Omni* está estável.
O bot mais completo de Moçambique 🇲🇿 à tua disposição.

┌─ ░ *OMNI-CORE STATS* ░
│ 👑 *Dono:* Nel Custódio
│ 👥 *Cidadãos:* $users
│ 💎 *VIPs:* Ativo
│ 🔋 *Uptime:* $uptime
└───────────────────

┏━━━━━━ 📋 *CATEGORIAS* ━━━━━━┓
┃
┃ 💎 ░ .menu elite (VIP Only)
┃ 💰 ░ .menu economia
┃ 🎲 ░ .menu gacha
┃ ⬇️ ░ .menu downloads
┃ 👤 ░ .menu perfil
┃ 🤖 ░ .menu sockets
┃ 🖼️ ░ .menu stickers
┃ 🛠️ ░ .menu utilidades
┃ 👥 ░ .menu grupos
┃ 🔞 ░ .menu nsfw
┃ 🌸 ░ .menu anime
┃ 🛡️ ░ .menu moderacao
┃ 🎮 ░ .menu diversao
┃ 🤖 ░ .menu ia
┃ 📰 ░ .menu noticias
┃ 💳 ░ .menu pagamentos
┃ 🚀 ░ .menu nexus (Novidades)
┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📢 *Dashboard:* $link/dashboard
💡 *Dica:* Torne-se VIP para desbloquear o Nexus-AI!
> 🏆 _Omni-Nexus - Domínio Total_`;

export const menuObject = {
  elite: `
╔══════════════════════════════════════╗
║  💎 *NEXUS ELITE* · V13.1 Exclusive  ║
╚══════════════════════════════════════╝
┌─ ░ COMANDOS ELITE ░──────────────┐
│ .nexus-ai » .img  Gerar Arte 🎨    │
│ .spy-web » .spy   Analisar Link 🔍 │
│ .voice-nexus » .tts Voz Neural 🎙️   │
│ .vip » .premium  Info Subscrição 💎 │
│ .resumir » .resumo IA Ilimitada 📝 │
│ .brain » .nel    Nexus-Brain V13 🧠 │
└──────────────────────────────────┘`,

  economia: `
╔══════════════════════════════════════╗
║  💰 *ECONOMIA GLOBAL* · Nel-Aviso  ║
╚══════════════════════════════════════╝
┌─ ░ MEU PERFIL ░──────────────────┐
│ .perfil » .level  Minhas Stats    │
│ .xp » .level     Ver XP atual     │
│ .money » .saldo  Ver Carteira     │
└──────────────────────────────────┘
┌─ ░ RANKING ░─────────────────────┐
│ .topxp » .toplv  Líderes XP       │
│ .topmoney       Mais Ricos        │
└──────────────────────────────────┘`,

  gacha: `
╔══════════════════════════════════════╗
║  🎲 *GACHA* · Nel-Aviso          ║
╚══════════════════════════════════════╝
┌─ ░ REIVINDICAR ░─────────────────┐
│ .roll » .rw      Aleatório    │
│ .claim » .c      Reivindicar  │
│ .setclaim        Editar msg   │
│ .delclaim        Resetar msg  │
│ .delwaifu        Deletar      │
└──────────────────────────────────┘
┌─ ░ COLECÇÃO ░────────────────────┐
│ .harem » .waifus  Harém       │
│ .ginfo           Info gacha   │
│ .favtop          Top favoritos│
│ .wtop            Top valor    │
└──────────────────────────────────┘
┌─ ░ LOJA ░────────────────────────┐
│ .wshop           Loja         │
│ .comprarchar     Comprar      │
│ .vender          Vender       │
│ .removesale      Remover venda│
└──────────────────────────────────┘
┌─ ░ TROCA ░───────────────────────┐
│ .give » .givewaifu  Dar       │
│ .giveall         Dar tudo     │
│ .trade » .trocar  Trocar      │
│ .vote            Votar        │
└──────────────────────────────────┘
┌─ ░ INFO ░────────────────────────┐
│ .wimage » .cimage  Imagem     │
│ .winfo » .charinfo  Detalhes  │
│ .serie » .animeinfo  Anime    │
│ .serielist       Listar       │
└──────────────────────────────────┘`,

  downloads: `
╔══════════════════════════════════════╗
║  ⬇️ *DOWNLOADS* · Nel-Aviso      ║
╚══════════════════════════════════════╝
┌─ ░ VÍDEO ░───────────────────────┐
│ .play2 » .ytmp4   YT URL     │
│ .video » .vid    YT Nome     │
│ .tt » .tiktok    TikTok      │
│ .ig » .instagram Instagram   │
│ .fb » .facebook  Facebook    │
│ .x » .twitter    Twitter/X   │
│ .smartdl » .baixartudo       │
│         Universal (auto)     │
│ .kwai » .kwaidl  Kwai        │
│ .telegramdl » .tgdl Telegram │
└──────────────────────────────────┘
┌─ ░ MÚSICA ░──────────────────────┐
│ .play » .ytmp3   YT URL      │
│ .musica » .tocar YT Nome     │
│ .buscarmusica    Buscar lista │
│ .baixar         Baixar da lista│
│ .topmusica      Top momento  │
│ .spotify » .sp  Spotify      │
│ .spotifysearch  Buscar faixas│
└──────────────────────────────────┘
┌─ ░ IMAGEM ░──────────────────────┐
│ .img » .imagem   Google      │
│ .pin » .pinterest Pinterest  │
│ .pintest  Pinterest Search   │
│ .unplash Unsplash Pro        │
│ .wallpaper » .wall  Wallpapers│
└──────────────────────────────────┘
┌─ ░ ARQUIVOS ░────────────────────┐
│ .mf » .mediafire  MediaFire  │
│ .drive » .gdrive  GDrive     │
│ .apk » .aptoide   APK        │
│ .git » .gitclone  GitHub     │
└──────────────────────────────────┘
┌─ ░ BUSCA ░───────────────────────┐
│ .ytsearch » .ys  Buscar YT   │
│ .letra » .lyrics  Letra      │
│ .lyricssearch  Letra detalhe │
└──────────────────────────────────┘`,

  perfil: `
╔══════════════════════════════════════╗
║  👤 *PERFIL* · Nel-Aviso         ║
╚══════════════════════════════════════╝
┌─ ░ VER ░─────────────────────────┐
│ .perfil » .profile  Perfil    │
│ .lvl » .level       Nível     │
│ .lb » .leaderboard  Ranking   │
│ .perfilfoto        Foto       │
│ .perfilcard » .card Card visual│
└──────────────────────────────────┘
┌─ ░ CONFIGURAR ░─────────────────┐
│ .setgen » .setgenre  Género   │
│ .setbirth        Aniversário  │
│ .setdesc         Descrição    │
│ .sethobby        Passatempo  │
│ .setfav          Favorita     │
└──────────────────────────────────┘
┌─ ░ DELETAR ░────────────────────┐
│ .delgen .delbirth .deldesc   │
│ .delhobby .delfav            │
└──────────────────────────────────┘
┌─ ░ RELACIONAMENTO ░─────────────┐
│ .casar » .marry   Casar      │
│ .divorcio        Divorciar   │
│ .casal .matrimonio           │
│ .ship  Compatibilidade card  │
└──────────────────────────────────┘`,

  sockets: `
╔══════════════════════════════════════╗
║  🤖 *SOCKETS* · Nel-Aviso        ║
╚══════════════════════════════════════╝
┌─ ░ SESSÃO ░──────────────────────┐
│ .qr » .code      Criar Sub   │
│ .botinfo » .infobot  Info    │
│ .reload          Recarregar  │
│ .logout          Encerrar    │
└──────────────────────────────────┘
┌─ ░ GRUPOS ░──────────────────────┐
│ .join            Entrar       │
│ .leave » .sair   Sair        │
│ .self            Privado/Púb  │
└──────────────────────────────────┘
┌─ ░ APARÊNCIA ░───────────────────┐
│ .setname .setpfp .setbanner  │
│ .seticon .setstatus          │
│ .setuser .setchannel         │
└──────────────────────────────────┘
┌─ ░ CONFIG ░──────────────────────┐
│ .setprefix .setmoeda         │
│ .setowner .setlink           │
└──────────────────────────────────┘`,

  stickers: `
╔══════════════════════════════════════╗
║  🖼️ *STICKERS* · Nel-Aviso       ║
╚══════════════════════════════════════╝
┌─ ░ CRIAR ░───────────────────────┐
│ .s » .sticker    Converter   │
│ .autofig » .fig  Rápido      │
│ .brat » .bratv   Com texto   │
│ .toimg » .toimage  Sticker→Img│
│ .stickeremoji    Emoji→Sticker│
│ .emojimix        Misturar    │
└──────────────────────────────────┘
┌─ ░ PACOTES ░─────────────────────┐
│ .packs » .packlist  Listar   │
│ .newpack .delpack .getpack   │
│ .privpack .pubpack           │
└──────────────────────────────────┘
┌─ ░ GERENCIAR ░──────────────────┐
│ .addsticker .delsticker      │
│ .setmeta .delmeta            │
│ .setnamepack .setdescpack    │
└──────────────────────────────────┘`,

  utilidades: `
╔══════════════════════════════════════╗
║  🛠️ *UTILIDADES* · Nel-Aviso     ║
╚══════════════════════════════════════╝
┌─ ░ BOT ░─────────────────────────┐
│ .ping » .speed    Latência    │
│ .status » .estado  Estado     │
│ .menu             Menu        │
│ .criador » .dev   Criador     │
│ .bugreport        Reportar    │
│ .sysinfo » .sistema  Sistema  │
│ .speedtest        Velocidade  │
└──────────────────────────────────┘
┌─ ░ MÍDIA & FOTO ░───────────────┐
│ .pfp » .getpic    Foto perf   │
│ .hd » .enhance    Melhorar    │
│ .imghd » .upscale  IA Upscale │
│ .tourl            Mídia→Link  │
│ .read             View-once   │
│ .blur .filtro .circulo       │
│ .espelhar .rotacionar        │
│ .removebg » .semfundo  Fundo │
│ .redimensionar    Redimensionar│
│ .ssweb  Screenshot site       │
│ .ocr » .extrairtexto  Ler Imagem │
│ .topdf » .pdf  Imagem para PDF   │
│ .noticiasmz  Notícias MZ 🇲🇿   │
│ .nsfwcheck  Verificar NSFW   │
│ .age » .idadedetect  IA Face │
│ .celebridade  Reconhecer celeb│
└──────────────────────────────────┘
┌─ ░ TEXTO & CÓDIGO ░─────────────┐
│ .trad » .translate  Traduzir  │
│ .say » .falar     Repetir     │
│ .textoespecial    10 estilos  │
│ .textocontrário   Inverter    │
│ .tradutor         Alternativo │
│ .contar           Contar      │
│ .ascii .morse .binario       │
└──────────────────────────────────┘
┌─ ░ FERRAMENTAS ░────────────────┐
│ .calc » .calculadora  Calc    │
│ .gerarsenha » .senha  Senha   │
│ .gerarqrcode » .qrgen QR Code │
│ .conversormoeda » .cambio2    │
│ .codigocores » .cor  HEX      │
│ .clima » .tempo    Previsão   │
│ .weather           Detalhado  │
│ .cotacao » .moeda  Cotação    │
│ .crypto » .cripto  Cripto     │
│ .filme » .movie    Filme      │
│ .letra » .lyrics   Letra      │
│ .lyricssearch  Letra detalhada│
│ .qrcode » .qr      QR Code   │
│ .codigobarras      Barras     │
│ .lembrete          Lembrete   │
│ .cep .idade .checknumero     │
│ .tempo » .quehoras  Hora      │
│ .degoogle » .pesquisar  Busca │
│ .encurtar » .short  URL curta │
│ .resolver » .unshort  URL long│
│ .ss » .screenshot  Captura    │
│ .audio2text » .transcrever    │
│ .tts » .voz        Texto→Voz  │
│ .wikipedia » .wiki  Wiki      │
│ .noticias » .news   Notícias  │
│ .technews  Tech News          │
│ .pixabay          Imagens     │
│ .unplash  Unsplash Pro       │
│ .fakeinfo » .fakeid  Fake ID  │
│ .insultar » .insulto  Insulto │
│ .horoscopo » .horosc  Horósc. │
│ .gravar » .notavoz  Nota voz  │
│ .dicionario » .dict  Dicion.  │
│ .buscar » .web      Web busca │
│ .traduzir » .tradl  Traduzir  │
│ .logotipo » .logo   Logo est. │
│ .comparar » .celular Specs    │
│ .rastrear » .rastro  Rastrear│
│ .curiosidade » .curio  Fato   │
│ .ipinfo » .ip  IP Geolocalizar│
│ .checar » .checkurl  Analisar │
│ .cfcheck » .cloudflare  CF    │
│ .stalk  Stalker redes sociais │
│ .receita » .cozinhar  Receitas│
│ .pokemon » .pokedex  Pokédex  │
│ .proverbio  Provérbio        │
│ .versiculo  Versículo        │
│ .destino  Destino            │
│ .sorteio  Sorteio            │
│ .ideia   Ideia               │
│ .horoscopo  Horóscopo        │
│ .quem   Quem é?              │
│ .sinaleiro  Sinaleiro        │
│ .avaliar  Avaliar            │
│ .fakechat  Chat falso        │
│ .palavra  Palavra            │
│ .insultar  Insulto cómico    │
└──────────────────────────────────┘`,

  grupos: `
╔══════════════════════════════════════╗
║  👥 *GRUPOS* · Nel-Aviso         ║
╚══════════════════════════════════════╝
┌─ ░ MEMBROS ░─────────────────────┐
│ .kick .promote .demote        │
│ .tagall » .hidetag  Marcar    │
│ .marcar » .marcartodos        │
│ .poll » .enquete   Enquete    │
└──────────────────────────────────┘
┌─ ░ ADVERTÊNCIAS ░───────────────┐
│ .warn .warns .delwarn         │
│ .warnlimit » .setwarnlimit   │
└──────────────────────────────────┘
┌─ ░ CONTROLE ░───────────────────┐
│ .close » .open  Fechar/Abrir │
│ .bot + on|off   Ativar/Desat  │
│ .antilink .adminonly .alerts  │
│ .clear           Limpar       │
└──────────────────────────────────┘
┌─ ░ BOAS-VINDAS ░───────────────┐
│ .welcome .bye                 │
│ .setwelcome .setbye           │
└──────────────────────────────────┘
┌─ ░ INFO & STATS ░──────────────┐
│ .gpinfo .topmsg .topinativo  │
│ .msgcount .link .listaradmins│
│ .top             Top ativos  │
│ .adms            ADMs        │
└──────────────────────────────────┘
┌─ ░ APARÊNCIA ░─────────────────┐
│ .setgpname .setgpdesc        │
│ .setgpimg » .setgpbaner      │
└──────────────────────────────────┘
┌─ ░ MÓDULOS ░───────────────────┐
│ .economy .gacha .nsfw        │
│ .setprimary     Bot primário │
└──────────────────────────────────┘`,

  moderacao: `
╔══════════════════════════════════════╗
║  🛡️ *MODERAÇÃO* · Nel-Aviso      ║
╚══════════════════════════════════════╝
┌─ ░ SILENCIAR ░───────────────────┐
│ .mute » .mutar    Mutar       │
│ .unmute » .desmutar           │
│ .mutargrupo      Grupo temp   │
└──────────────────────────────────┘
┌─ ░ PROTECÇÃO ░─────────────────┐
│ .antilink2       Anti-link+   │
│ .antiraid » .escudo  Anti-Raid   │
│ .antifake        Anti-fake    │
│ .antispam        Anti-flood   │
│ .antitoxic       Anti-palavrão│
│ .antiarabe       Anti-estrange│
│ .antimidia       Anti-mídia   │
└──────────────────────────────────┘
┌─ ░ TRAVAR ░─────────────────────┐
│ .lockname .lockdesc           │
└──────────────────────────────────┘`,

  anime: `
╔══════════════════════════════════════╗
║  🌸 *ANIME* · Nel-Aviso          ║
╚══════════════════════════════════════╝
┌─ ░ PERSONAGENS ░───────────────┐
│ .waifu » .neko    Aleatória   │
│ .ppcp » .ppcouple  Casal      │
│ .carta » .pokecard  PokéCard  │
└──────────────────────────────────┘
┌─ ░ INFO ░───────────────────────┐
│ .animinfo  Info Anime/Manga   │
│ .manga  Info Manga            │
└──────────────────────────────────┘
┌─ ░ CARINHO ░───────────────────┐
│ .hug .kiss .pat .cuddle .lick│
└──────────────────────────────────┘
┌─ ░ DIVERSÃO ░──────────────────┐
│ .slap .bonk .bite .kill      │
└──────────────────────────────────┘
┌─ ░ EXPRESSÕES ░───────────────┐
│ .cry .blush .smile .sad      │
│ .happy .angry .shy           │
└──────────────────────────────────┘`,

  diversao: `
╔══════════════════════════════════════╗
║  🎮 *DIVERSÃO* · Nel-Aviso       ║
╚══════════════════════════════════════╝
┌─ ░ JOGOS ░───────────────────────┐
│ .tictactoe » .velha          │
│ .chess » .xadrez             │
│ .connect4 » .ligar4          │
│ .wordle » .termo             │
│ .hangman » .forca            │
└──────────────────────────────────┘
┌─ ░ INTERAÇÃO ░─────────────────┐
│ .love » .amor    % de amor   │
│ .gay » .medidorgay           │
│ .corno » .medidorcorno       │
│ .fakechat » .fake            │
└──────────────────────────────────┘`,

  ia: `
╔══════════════════════════════════════╗
║  🤖 *IA* · Nel-Aviso             ║
╚══════════════════════════════════════╝
┌─ ░ CHAT IA ░─────────────────────┐
│ .ia » .chatgpt    ChatGPT    │
│ .brain » .nel    Nel-Brain 🧠  │
│ .vision » .ver   IA Vision 📸  │
│ .deepsearch      Deep Search 🔍│
│ .gemini » .google  Gemini    │
│ .blackbox » .bb   Blackbox   │
│ .copilot » .bing  Copilot    │
│ .claude » .anthropic Claude  │
│ .pergunta » .ask  Perguntar  │
│ .simi  SimSimi Chat          │
└──────────────────────────────────┘
┌─ ░ IMAGEM IA ░──────────────────┐
│ .gerarimg » .imgia  Gerar img│
│ .buscariart » .lexica Busca IA   │
└──────────────────────────────────┘`,

  noticias: `
╔══════════════════════════════════════╗
║  📰 *NOTÍCIAS* · Nel-Aviso        ║
╚══════════════════════════════════════╝
┌─ ░ INFORMAÇÃO ░──────────────────┐
│ .noticias » .news Notícias Mundo 🌐 │
│ .noticiasmz      Notícias MZ 🇲🇿   │
│ .giriasmz » .bro  Cultura MZ 🇲🇿  │
│ .technews        Tecnologia      │
└──────────────────────────────────┘`,

  pagamentos: `
╔══════════════════════════════════════╗
║  💳 *PAGAMENTOS* · Nel-Aviso     ║
╚══════════════════════════════════════╝
┌─ ░ DETECÇÃO AUTO ░──────────────┐
│ ✅ Comprovativos detectados  │
│   automaticamente (texto+foto│
│   OCR) com verificação e     │
│   registo de compra auto     │
└──────────────────────────────────┘
┌─ ░ COMPROVATIVO ░───────────────┐
│ .mpesa » .comprovativo       │
│   .mpesa texto + <texto>     │
│   .mpesa foto (citar img)    │
│   .mpesa verificar (citar)   │
│   .mpesa ajuda               │
└──────────────────────────────────┘
┌─ ░ COMPRAS ░────────────────────┐
│ .comprar + <valorMT>         │
│ .comprar confirmar <v> <@>   │
│ .minhascompras » .meusdados  │
│ .ranking » .topcompras       │
└──────────────────────────────────┘
┌─ ░ INFO ░───────────────────────┐
│ .pagamento » .pagar          │
│ .megas » .planos  Pacotes    │
└──────────────────────────────────┘`,

  nexus: `
╔══════════════════════════════════════╗
║  🚀 *NEXUS CORE* · V13.1 Features    ║
╚══════════════════════════════════════╝
┌─ ░ NOVIDADES OMNI ░──────────────┐
│ .nexusstats » .imperio Dashboard 📊 │
│ .agenda » .notas Notas Cloud 📝    │
│ .traduzir-doc    Traduzir Doc 📄  │
│ .excel-tool » .excel Gerar Tabela 📊│
│ .imc » .peso    Calculadora IMC ⚖️ │
│ .agua » .beber   Lembrete Água 💧  │
│ .converter » .unid Conversor 📏    │
└──────────────────────────────────┘`
};

export default { bodyMenu, menuObject };
