let handler = async (m, { conn, text }) => {
  let body = (m.text || '').toLowerCase().trim()
  
  if (body === 'megas' || body === 'net' || body === 'tabela') {
    let msg = `Tabela Actualizada

MEGAS VODACOM
ACTUALIZADA | Ativacao Imediata | M-Pesa/E-Mola

PACOTES DIARIOS (24H)
5MT -> 200MB
10MT -> 400MB
15MT -> 600MB
20MT -> 800MB
22MT -> 850MB
25MT -> 1024MB
30MT -> 1200MB
35MT -> 1400MB
45MT -> 1850MB
50MT -> 2048MB
55MT -> 2150MB
65MT -> 2800MB
75MT -> 3072MB
80MT -> 3300MB
100MT -> 4096MB
130MT -> 5120MB
255MT -> 10240MB

PACOTES MENSAIS (30 DIAS)
185MT -> 5.9GB
190MT -> 6GB
220MT -> 7GB
280MT -> 10.5GB
450MT -> 17.2GB
870MT -> 35.6GB
1800MT -> 71.5GB MAX

NEL NET Express - Ativa agora, navega sem limites.`
    
    return conn.reply(m.chat, msg, m)
  }
}
handler.customPrefix = /^(megas|net|tabela)$/i
handler.command = new RegExp
export default handler
