# 🚀 Guia Completo de Deployment - Nel-Aviso-Bot V12 Nexus Intelligence

## 📌 Índice
1. [Opções de Hosting](#opções-de-hosting)
2. [Configuração por Plataforma](#configuração-por-plataforma)
3. [Monitoramento 24/7](#monitoramento-247)
4. [Troubleshooting](#troubleshooting)

---

## 🌐 Opções de Hosting

### 1. **Railway** ⭐ (Recomendado - Melhor Custo-Benefício)
**Preço:** Gratuito com $5/mês de créditos (suficiente para sempre)  
**Uptime:** 99.9%  
**Vantagens:** Fácil deploy, auto-restart, logs em tempo real

#### Passos:
```bash
# 1. Cria conta em https://railway.app
# 2. Conecta GitHub ou faz upload direto
# 3. Cria variáveis de ambiente (.env)
# 4. Deploy automático
```

**Ficheiro `railway.json`:**
```json
{
  "build": {
    "builder": "nixpacks"
  },
  "deploy": {
    "startCommand": "npm start",
    "restartPolicyType": "on_failure",
    "restartPolicyMaxRetries": 5
  }
}
```

---

### 2. **Render** (Alternativa Gratuita)
**Preço:** Gratuito (com limitações)  
**Uptime:** 99.9%  
**Vantagens:** Sem cartão de crédito, auto-deploy

#### Passos:
```bash
# 1. Vai a https://render.com
# 2. Conecta GitHub
# 3. Cria novo Web Service
# 4. Build Command: npm install
# 5. Start Command: npm start
```

---

### 3. **Heroku Alternativas**
**Preço:** Pago ($7-50/mês)  
**Uptime:** 99.95%  
**Vantagens:** Mais estável, melhor performance

#### Alternativas a Heroku (descontinuado):
- **Fly.io** - https://fly.io (Recomendado)
- **Koyeb** - https://koyeb.com
- **Cyclic** - https://cyclic.sh

---

### 4. **VPS Próprio** (Controlo Total)
**Preço:** $3-10/mês  
**Uptime:** 99.99%  
**Vantagens:** Controlo total, sem limitações

#### Provedores:
- **DigitalOcean** - https://digitalocean.com ($5/mês)
- **Linode** - https://linode.com ($5/mês)
- **Vultr** - https://vultr.com ($2.50/mês)
- **Hetzner** - https://hetzner.com (Mais barato na EU)

---

## ⚙️ Configuração por Plataforma

### Railway (Passo-a-Passo Completo)

#### 1. Preparar o Repositório
```bash
# Cria ficheiro .env.example (sem valores sensíveis)
OWNER_NUMBER=258878464656
MPESA_NUMERO=8XXXXXXXX
MPESA_NOME=Seu Nome
EMOLA_NUMERO=8XXXXXXXX
EMOLA_NOME=Seu Nome
OWNER_GMAIL=seuemail@gmail.com
API_LINK=https://github.com/nelioaviso-arch
CHANNEL_LINK=https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N
GITHUB_LINK=https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
```

#### 2. Ficheiro `package.json` (Verificar)
```json
{
  "name": "nel-aviso-bot-moz",
  "version": "12.0.0",
  "description": "O melhor bot de WhatsApp de Moçambique",
  "main": "index.js",
  "type": "module",
  "scripts": {
    "start": "node index.js",
    "dev": "node index.js"
  },
  "engines": {
    "node": ">=18.0.0",
    "npm": ">=9.0.0"
  },
  "dependencies": {
    "baileys": "github:this-xys/baileys",
    "chalk": "^4.1.2",
    "express": "^4.18.2",
    "node-fetch": "^3.2.10",
    "qrcode-terminal": "^0.12.0"
  }
}
```

#### 3. Criar `Procfile` (para Heroku-like)
```
worker: npm start
```

#### 4. Deploy no Railway
```bash
# 1. Push para GitHub
git add .
git commit -m "Deploy v12 Nexus Intelligence"
git push origin main

# 2. No Railway:
# - Conecta GitHub
# - Seleciona repositório
# - Adiciona variáveis de .env
# - Deploy automático
```

---

### DigitalOcean VPS (Controlo Total)

#### 1. Criar Droplet
```bash
# Specs recomendadas:
# - OS: Ubuntu 22.04 LTS
# - RAM: 1GB (suficiente)
# - CPU: 1 vCPU
# - Preço: $5/mês
```

#### 2. SSH e Setup Inicial
```bash
# SSH para o VPS
ssh root@seu_ip

# Atualizar sistema
apt update && apt upgrade -y

# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs

# Instalar PM2 (gerenciador de processos)
npm install -g pm2

# Clonar repositório
git clone https://github.com/nelioaviso-arch/Nel-Aviso-Bot-Moz.git
cd Nel-Aviso-Bot-Moz

# Instalar dependências
npm install

# Criar .env com valores reais
nano .env
# Cole as variáveis de ambiente aqui
```

#### 3. Configurar PM2 para Auto-Restart
```bash
# Iniciar bot com PM2
pm2 start index.js --name "nel-aviso-bot"

# Configurar auto-restart em caso de crash
pm2 startup
pm2 save

# Ver logs em tempo real
pm2 logs nel-aviso-bot

# Monitorar
pm2 monit
```

#### 4. Configurar Firewall
```bash
# UFW (Firewall)
ufw allow 22/tcp  # SSH
ufw allow 80/tcp  # HTTP
ufw allow 443/tcp # HTTPS
ufw enable
```

---

## 🔄 Monitoramento 24/7

### Opção 1: PM2 Plus (Recomendado)
```bash
# Registar no PM2 Plus
pm2 link

# Monitorar via dashboard
# https://app.pm2.io

# Alertas automáticos em caso de crash
```

### Opção 2: Uptime Robot (Gratuito)
```
1. Vai a https://uptimerobot.com
2. Cria monitor HTTP
3. URL: http://seu_vps_ip:3000 (ou qualquer endpoint)
4. Intervalo: 5 minutos
5. Recebe alertas por email/SMS
```

### Opção 3: Script de Auto-Restart (Simples)
```bash
# Cria ficheiro restart.sh
#!/bin/bash
while true; do
  npm start
  echo "Bot crashou, reiniciando em 5 segundos..."
  sleep 5
done

# Torna executável
chmod +x restart.sh

# Executa em background
nohup ./restart.sh > bot.log 2>&1 &
```

---

## 🛠️ Troubleshooting

### Problema: Bot desconecta após 1 hora
**Solução:**
```javascript
// Adiciona ao index.js
setInterval(() => {
  console.log('[HEARTBEAT] Bot ainda online');
}, 60000); // A cada 1 minuto
```

### Problema: Erro "EADDRINUSE" (Porta em uso)
**Solução:**
```bash
# Encontra processo na porta 3000
lsof -i :3000

# Mata o processo
kill -9 PID

# Ou muda a porta
PORT=8080 npm start
```

### Problema: Memória insuficiente
**Solução:**
```bash
# Aumenta limite de memória
node --max-old-space-size=512 index.js

# Ou no package.json
"start": "node --max-old-space-size=512 index.js"
```

### Problema: Bot não reconecta após internet cair
**Solução:**
```javascript
// Adiciona ao main.js
sock.ev.on('connection.update', (update) => {
  const { connection, lastDisconnect } = update;
  
  if (connection === 'close') {
    const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
    if (shouldReconnect) {
      console.log('Reconectando...');
      setTimeout(() => startBot(), 3000);
    }
  }
});
```

---

## 📊 Comparação de Plataformas

| Plataforma | Preço | Uptime | Setup | Recomendação |
|-----------|-------|--------|-------|--------------|
| Railway | Gratuito | 99.9% | ⭐⭐⭐ | Melhor para iniciantes |
| Render | Gratuito | 99.9% | ⭐⭐⭐ | Alternativa Railway |
| DigitalOcean | $5/mês | 99.99% | ⭐⭐ | Melhor controlo |
| Fly.io | Gratuito | 99.95% | ⭐⭐ | Boa alternativa |
| Heroku (antigo) | ❌ Descontinuado | - | - | Não use |

---

## ✅ Checklist Final

- [ ] Variáveis de ambiente configuradas (.env)
- [ ] Node.js v18+ instalado
- [ ] Dependências instaladas (npm install)
- [ ] Bot testado localmente
- [ ] Repositório no GitHub
- [ ] Plataforma de hosting escolhida
- [ ] Deploy realizado
- [ ] QR Code escaneado
- [ ] Bot online 24/7
- [ ] Monitoramento ativado

---

## 🎯 Próximos Passos

1. **Escolhe uma plataforma** (Railway recomendado)
2. **Cria conta** na plataforma
3. **Configura variáveis de ambiente**
4. **Faz deploy**
5. **Testa o bot**
6. **Ativa monitoramento**
7. **Aproveita o bot 24/7!** 🎉

---

**Dúvidas?** Contacta Nel Custódio: seuemail@gmail.com
